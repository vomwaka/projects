/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obi.agencynetwork.web.model;

/**
 *
 * @author SAM
 */
public class GetAllAgents {
    
    private String agentId;
    private String agentCode;
    private String agentCreatedBy;
    private String agentDateCreated;
    private String agentDateModified;
    private String agentEmail;
    private String agentModifiedBy;
    private String agentFirstName;
    private String agentPhoneNo;
    private String agentIdNumber;
    private String agentStatus;
    private String agentBusinessName;
    private String agentBusinessNumber;
    private String agentLocation;
    private String agentAddress;
    private String agentCardSerial;
    private String agentType;
    private String agentSecondName;
    private String agentPhoto;
    private String agentSwitchId;
    private String agentSwitchPin;
    private String agentFloatMax;
    private String agentRegion;
    private String agentParentCompany;
    private String agentFloatAccount;
    private String agentCommAccount;
    private String agentThirdName;
    private String agentAlternatePhone;
    private String agentBankAccount;
    private String agentLocationPhoto;
    private String agentBranchCode;
    private String agentBranchName;
    private String agentBankName;

    /**
     * @return the agentId
     */
    public String getAgentId() {
        return agentId;
    }

    /**
     * @param agentId the agentId to set
     */
    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    /**
     * @return the agentCode
     */
    public String getAgentCode() {
        return agentCode;
    }

    /**
     * @param agentCode the agentCode to set
     */
    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }

    /**
     * @return the agentCreatedBy
     */
    public String getAgentCreatedBy() {
        return agentCreatedBy;
    }

    /**
     * @param agentCreatedBy the agentCreatedBy to set
     */
    public void setAgentCreatedBy(String agentCreatedBy) {
        this.agentCreatedBy = agentCreatedBy;
    }

    /**
     * @return the agentDateCreated
     */
    public String getAgentDateCreated() {
        return agentDateCreated;
    }

    /**
     * @param agentDateCreated the agentDateCreated to set
     */
    public void setAgentDateCreated(String agentDateCreated) {
        this.agentDateCreated = agentDateCreated;
    }

    /**
     * @return the agentDateModified
     */
    public String getAgentDateModified() {
        return agentDateModified;
    }

    /**
     * @param agentDateModified the agentDateModified to set
     */
    public void setAgentDateModified(String agentDateModified) {
        this.agentDateModified = agentDateModified;
    }

    /**
     * @return the agentEmail
     */
    public String getAgentEmail() {
        return agentEmail;
    }

    /**
     * @param agentEmail the agentEmail to set
     */
    public void setAgentEmail(String agentEmail) {
        this.agentEmail = agentEmail;
    }

    /**
     * @return the agentModifiedBy
     */
    public String getAgentModifiedBy() {
        return agentModifiedBy;
    }

    /**
     * @param agentModifiedBy the agentModifiedBy to set
     */
    public void setAgentModifiedBy(String agentModifiedBy) {
        this.agentModifiedBy = agentModifiedBy;
    }

    /**
     * @return the agentFirstName
     */
    public String getAgentFirstName() {
        return agentFirstName;
    }

    /**
     * @param agentFirstName the agentFirstName to set
     */
    public void setAgentFirstName(String agentFirstName) {
        this.agentFirstName = agentFirstName;
    }

    /**
     * @return the agentPhoneNo
     */
    public String getAgentPhoneNo() {
        return agentPhoneNo;
    }

    /**
     * @param agentPhoneNo the agentPhoneNo to set
     */
    public void setAgentPhoneNo(String agentPhoneNo) {
        this.agentPhoneNo = agentPhoneNo;
    }

    /**
     * @return the agentIdNumber
     */
    public String getAgentIdNumber() {
        return agentIdNumber;
    }

    /**
     * @param agentIdNumber the agentIdNumber to set
     */
    public void setAgentIdNumber(String agentIdNumber) {
        this.agentIdNumber = agentIdNumber;
    }

    /**
     * @return the agentStatus
     */
    public String getAgentStatus() {
        return agentStatus;
    }

    /**
     * @param agentStatus the agentStatus to set
     */
    public void setAgentStatus(String agentStatus) {
        this.agentStatus = agentStatus;
    }

    /**
     * @return the agentBusinessName
     */
    public String getAgentBusinessName() {
        return agentBusinessName;
    }

    /**
     * @param agentBusinessName the agentBusinessName to set
     */
    public void setAgentBusinessName(String agentBusinessName) {
        this.agentBusinessName = agentBusinessName;
    }

    /**
     * @return the agentBusinessNumber
     */
    public String getAgentBusinessNumber() {
        return agentBusinessNumber;
    }

    /**
     * @param agentBusinessNumber the agentBusinessNumber to set
     */
    public void setAgentBusinessNumber(String agentBusinessNumber) {
        this.agentBusinessNumber = agentBusinessNumber;
    }

    /**
     * @return the agentLocation
     */
    public String getAgentLocation() {
        return agentLocation;
    }

    /**
     * @param agentLocation the agentLocation to set
     */
    public void setAgentLocation(String agentLocation) {
        this.agentLocation = agentLocation;
    }

    /**
     * @return the agentAddress
     */
    public String getAgentAddress() {
        return agentAddress;
    }

    /**
     * @param agentAddress the agentAddress to set
     */
    public void setAgentAddress(String agentAddress) {
        this.agentAddress = agentAddress;
    }

    /**
     * @return the agentCardSerial
     */
    public String getAgentCardSerial() {
        return agentCardSerial;
    }

    /**
     * @param agentCardSerial the agentCardSerial to set
     */
    public void setAgentCardSerial(String agentCardSerial) {
        this.agentCardSerial = agentCardSerial;
    }

    /**
     * @return the agentType
     */
    public String getAgentType() {
        return agentType;
    }

    /**
     * @param agentType the agentType to set
     */
    public void setAgentType(String agentType) {
        this.agentType = agentType;
    }

    /**
     * @return the agentSecondName
     */
    public String getAgentSecondName() {
        return agentSecondName;
    }

    /**
     * @param agentSecondName the agentSecondName to set
     */
    public void setAgentSecondName(String agentSecondName) {
        this.agentSecondName = agentSecondName;
    }

    /**
     * @return the agentPhoto
     */
    public String getAgentPhoto() {
        return agentPhoto;
    }

    /**
     * @param agentPhoto the agentPhoto to set
     */
    public void setAgentPhoto(String agentPhoto) {
        this.agentPhoto = agentPhoto;
    }

    /**
     * @return the agentSwitchId
     */
    public String getAgentSwitchId() {
        return agentSwitchId;
    }

    /**
     * @param agentSwitchId the agentSwitchId to set
     */
    public void setAgentSwitchId(String agentSwitchId) {
        this.agentSwitchId = agentSwitchId;
    }

    /**
     * @return the agentSwitchPin
     */
    public String getAgentSwitchPin() {
        return agentSwitchPin;
    }

    /**
     * @param agentSwitchPin the agentSwitchPin to set
     */
    public void setAgentSwitchPin(String agentSwitchPin) {
        this.agentSwitchPin = agentSwitchPin;
    }

    /**
     * @return the agentFloatMax
     */
    public String getAgentFloatMax() {
        return agentFloatMax;
    }

    /**
     * @param agentFloatMax the agentFloatMax to set
     */
    public void setAgentFloatMax(String agentFloatMax) {
        this.agentFloatMax = agentFloatMax;
    }

    /**
     * @return the agentRegion
     */
    public String getAgentRegion() {
        return agentRegion;
    }

    /**
     * @param agentRegion the agentRegion to set
     */
    public void setAgentRegion(String agentRegion) {
        this.agentRegion = agentRegion;
    }

    /**
     * @return the agentParentCompany
     */
    public String getAgentParentCompany() {
        return agentParentCompany;
    }

    /**
     * @param agentParentCompany the agentParentCompany to set
     */
    public void setAgentParentCompany(String agentParentCompany) {
        this.agentParentCompany = agentParentCompany;
    }

    /**
     * @return the agentFloatAccount
     */
    public String getAgentFloatAccount() {
        return agentFloatAccount;
    }

    /**
     * @param agentFloatAccount the agentFloatAccount to set
     */
    public void setAgentFloatAccount(String agentFloatAccount) {
        this.agentFloatAccount = agentFloatAccount;
    }

    /**
     * @return the agentCommAccount
     */
    public String getAgentCommAccount() {
        return agentCommAccount;
    }

    /**
     * @param agentCommAccount the agentCommAccount to set
     */
    public void setAgentCommAccount(String agentCommAccount) {
        this.agentCommAccount = agentCommAccount;
    }

    /**
     * @return the agentThirdName
     */
    public String getAgentThirdName() {
        return agentThirdName;
    }

    /**
     * @param agentThirdName the agentThirdName to set
     */
    public void setAgentThirdName(String agentThirdName) {
        this.agentThirdName = agentThirdName;
    }

    /**
     * @return the agentAlternatePhone
     */
    public String getAgentAlternatePhone() {
        return agentAlternatePhone;
    }

    /**
     * @param agentAlternatePhone the agentAlternatePhone to set
     */
    public void setAgentAlternatePhone(String agentAlternatePhone) {
        this.agentAlternatePhone = agentAlternatePhone;
    }

    /**
     * @return the agentBankAccount
     */
    public String getAgentBankAccount() {
        return agentBankAccount;
    }

    /**
     * @param agentBankAccount the agentBankAccount to set
     */
    public void setAgentBankAccount(String agentBankAccount) {
        this.agentBankAccount = agentBankAccount;
    }

    /**
     * @return the agentLocationPhoto
     */
    public String getAgentLocationPhoto() {
        return agentLocationPhoto;
    }

    /**
     * @param agentLocationPhoto the agentLocationPhoto to set
     */
    public void setAgentLocationPhoto(String agentLocationPhoto) {
        this.agentLocationPhoto = agentLocationPhoto;
    }

    /**
     * @return the agentBranchCode
     */
    public String getAgentBranchCode() {
        return agentBranchCode;
    }

    /**
     * @param agentBranchCode the agentBranchCode to set
     */
    public void setAgentBranchCode(String agentBranchCode) {
        this.agentBranchCode = agentBranchCode;
    }

    /**
     * @return the agentBranchName
     */
    public String getAgentBranchName() {
        return agentBranchName;
    }

    /**
     * @param agentBranchName the agentBranchName to set
     */
    public void setAgentBranchName(String agentBranchName) {
        this.agentBranchName = agentBranchName;
    }

    /**
     * @return the agentBankName
     */
    public String getAgentBankName() {
        return agentBankName;
    }

    /**
     * @param agentBankName the agentBankName to set
     */
    public void setAgentBankName(String agentBankName) {
        this.agentBankName = agentBankName;
    }
    
}
