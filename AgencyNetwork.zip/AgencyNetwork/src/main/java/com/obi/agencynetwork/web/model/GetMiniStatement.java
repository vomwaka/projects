/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obi.agencynetwork.web.model;

/**
 *
 * @author { VIN }
 */
public class GetMiniStatement {
    
    private String transAgent;
    private String transAmount;
    private String transCreditCard;
    private String transCustCard;
    private String transCustId;
    private Long transDate;
    private String transDebitCard;
    private String transDeviceId;
    private Long transId;
    private String transNumber;
    private String transStatus;
    private String transSwitchRef;
    private String transType;
    private String transUser;

    


/**
     * @return the transAgent
     */
    public String getTransAgent() {
        return transAgent;
    }

    /**
     * @param transAgent the agentId to set
     */
    public void setTransAgent(String transAgent) {
        this.transAgent = transAgent;
    }

    /**
     * @return the transAmount
     */
    public String getTransAmount() {
        return transAmount;
    }

    /**
     * @param transAmount the agentCode to set
     */
    public void setTransAmount(String transAmount) {
        this.transAmount = transAmount;
    }

    /**
     * @return the transCreditCard
     */
    public String getTransCreditCard() {
        return transCreditCard;
    }

    /**
     * @param transCreditCard the agentCreatedBy to set
     */
    public void setTransCreditCard(String transCreditCard) {
        this.transCreditCard = transCreditCard;
    }

    /**
     * @return the transCustCard
     */
    public String getTransCustCard() {
        return transCustCard;
    }

    /**
     * @param transCustCard the agentDateCreated to set
     */
    public void setTransCustCard(String transCustCard) {
        this.transCustCard = transCustCard;
    }

    /**
     * @return the agentDateModified
     */
    public String getTransCustId() {
        return transCustId;
    }

    /**
     * @param transCustId the agentDateModified to set
     */
    public void setTransCustId(String transCustId) {
        this.transCustId = transCustId;
    }

    /**
     * @return the transDate
     */
    public Long getTransDate() {
        return transDate;
    }

    /**
     * @param transDate the agentEmail to set
     */
    public void setTransDate(Long transDate) {
        this.transDate = transDate;
    }

    /**
     * @return the transDebitCard
     */
    public String getTransDebitCard() {
        return transDebitCard;
    }

    /**
     * @param transDebitCard the agentModifiedBy to set
     */
    public void setTransDebitCard(String transDebitCard) {
        this.transDebitCard = transDebitCard;
    }

    /**
     * @return the transDeviceId
     */
    public String getTransDeviceId() {
        return transDeviceId;
    }

    /**
     * @param transDeviceId the agentFirstName to set
     */
    public void setTransDeviceId(String transDeviceId) {
        this.transDeviceId = transDeviceId;
    }

    /**
     * @return the transId
     */
    public Long getTransId() {
        return transId;
    }

    /**
     * @param transId the agentPhoneNo to set
     */
    public void setTransId(Long transId) {
        this.transId = transId;
    }

    /**
     * @return the transNumber
     */
    public String getTransNumber() {
        return transNumber;
    }

    /**
     * @param transNumber the agentIdNumber to set
     */
    public void setTransNumber(String transNumber) {
        this.transNumber = transNumber;
    }

    /**
     * @return the transStatus
     */
    public String getTransStatus() {
        return transStatus;
    }

    /**
     * @param transStatus the agentStatus to set
     */
    public void setTransStatus(String transStatus) {
        this.transStatus = transStatus;
    }

    /**
     * @return the transSwitchRef
     */
    public String getTransSwitchRef() {
        return transSwitchRef;
    }

    /**
     * @param transSwitchRef the agentBusinessName to set
     */
    public void setTransSwitchRef(String transSwitchRef) {
        this.transSwitchRef = transSwitchRef;
    }

    /**
     * @return the transType
     */
    public String getTransType() {
        return transType;
    }

    /**
     * @param transType the agentBusinessNumber to set
     */
    public void setTransType(String transType) {
        this.transType = transType;
    }

    /**
     * @return the transUser
     */
    public String getTransUser() {
        return transUser;
    }

    /**
     * @param transUser the agentLocation to set
     */
    public void setTransUser(String transUser) {
        this.transUser = transUser;
    }
    
}
