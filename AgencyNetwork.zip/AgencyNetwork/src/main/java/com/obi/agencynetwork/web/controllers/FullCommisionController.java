/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obi.agencynetwork.web.controllers;

import com.obi.agencynetwork.web.BusinessLogic;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author { VIN }
 */
@WebServlet(urlPatterns = {"/FullCommision"})
public class FullCommisionController extends HttpServlet {

    BusinessLogic businessLogic;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        businessLogic = new BusinessLogic();
        businessLogic.fullcommisionrequest(request, response);

    }

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);
    }

}
