/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obi.agencynetwork.web.controllers;

import com.obi.agencynetwork.web.BusinessLogic;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author { VIN }
 */
@WebServlet(urlPatterns = {"/Deposit"})
public class DepositController extends HttpServlet{
    
 BusinessLogic businessLogic;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String agent_code = request.getParameter("agent_code");
        String customer_id = request.getParameter("transCustId");
        String amount = request.getParameter("transAmount");
        String password = request.getParameter("password");

        if (!customer_id.isEmpty() && !password.isEmpty() && !amount.isEmpty() && !agent_code.isEmpty()) {
            
            HttpSession session = request.getSession();
			session.setAttribute("agent_code", agent_code);
			//setting session to expiry in 30 mins
			session.setMaxInactiveInterval(30*60);
            
            Cookie loginCookie = new Cookie("agent_code",agent_code);
			//setting cookie to expiry in 30 mins
			loginCookie.setMaxAge(30*60);
			response.addCookie(loginCookie);

            businessLogic = new BusinessLogic();
            //businessLogic.getSingleAgentsRequest(request, response, agent_code);
            businessLogic.getAllTransactionRequest(request, response);

        }
        else{
           response.sendRedirect("index.jsp");
        }

    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);
    }
    
    
    
    
    
}

