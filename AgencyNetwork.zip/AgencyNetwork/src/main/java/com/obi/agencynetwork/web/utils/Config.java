/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obi.agencynetwork.web.utils;

/**
 *
 * @author SAM
 */
public class Config {
    
  public static final String ALL_AGENTS_ENDPOINT = "http://52.91.199.137:8080/obi/rest/agent/allagents";
  public static final String SINGLE_AGENT_ENDPOINT = "http://52.91.199.137:8080/obi/rest/agent/agentdetails?agentcode=";
  public static final String ALL_TRANSACTIONS = "http://52.91.199.137:8080/obi/rest/transaction/all";
  public static final String SINGLE_TRANSACTIONS = "http://52.91.199.137:8080/obi/rest/transaction/details?tranid="; 
  public static final String TRANSACTIONS_DEPOSIT = "http://52.91.199.137:8080/obi/rest/transaction/deposit=";
  public static final String TRANSACTIONS_WITHDRAW = "http://52.91.199.137:8080/obi/rest/transaction/withdraw=";
}
