/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obi.agencynetwork.web.controllers;

import com.obi.agencynetwork.web.BusinessLogic;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author SAM
 */

public class LogoutController extends HttpServlet {

    BusinessLogic businessLogic;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        /**
         * Cookie[] cookies = request.getCookies(); if(cookies != null){
         * for(Cookie cookie : cookies){
         * if(cookie.getName().equals("JSESSIONID")){
         * System.out.println("JSESSIONID="+cookie.getValue()); }
         * cookie.setMaxAge(0); response.addCookie(cookie); } }
         *
         *
         */
        //invalidate the session if exists
        HttpSession session = request.getSession(false);
        if (session != null) {

            System.out.println("Agent_code=" + session.getAttribute("agent_code"));
            if (session != null) {
                session.invalidate();
            }

            System.out.println("Invalidated_Agent_code=" + session.getAttribute("agent_code"));

            response.sendRedirect("index.jsp");
        } else {
            response.sendRedirect("index.jsp");
        }

    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);
    }

}
