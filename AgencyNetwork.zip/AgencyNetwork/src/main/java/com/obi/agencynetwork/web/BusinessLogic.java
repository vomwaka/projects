/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obi.agencynetwork.web;

import com.obi.agencynetwork.web.model.GetAllAgents;
import com.obi.agencynetwork.web.model.GetAllTransaction;
import com.obi.agencynetwork.web.model.GetSingleAgent;
import com.obi.agencynetwork.web.model.GetMiniStatement;
import com.obi.agencynetwork.web.model.GetFullStatement;
import com.obi.agencynetwork.web.model.GetFullCommision;
import com.obi.agencynetwork.web.model.DepositRequest;
import com.obi.agencynetwork.web.model.WithdrawRequest;
import com.obi.agencynetwork.web.utils.Config;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author SAM
 */
public class BusinessLogic {

    /**
     * 1
     */
    /*Post to GET ALL AGENTS Request*/
    public void getAllAgentsRequest(HttpServletRequest request, HttpServletResponse response) {

        String agencyNetworkResponse = "";

        try {
            agencyNetworkResponse = sendRequest(Config.ALL_AGENTS_ENDPOINT);
            JSONParser parser = new JSONParser();

            String response_code = "000";
            String response_sub_code = "000";

            System.out.println("Response Code: " + response_code);

            //  HttpSession session = request.getSession(false);
            //  if (session != null) {
            //  String SESSION_ID = (String) session.getAttribute("session_id");
            if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")) {

                JSONArray jsonarray = (JSONArray) parser.parse(agencyNetworkResponse);

                List<GetAllAgents> lName = new ArrayList<GetAllAgents>();

                Iterator<JSONObject> iterator = jsonarray.iterator();

//                String lName="list"+tr;
                // String agentId = null;
                String agentCode = null;
                String agentCreatedBy = null;
                // String agentDateCreated = null;
                // String agentDateModified = null;
                String agentEmail = null;
                String agentModifiedBy = null;
                String agentFirstName = null;
                String agentPhoneNo = null;
                String agentIdNumber = null;
                String agentStatus = null;
                String agentBusinessName = null;
                String agentBusinessNumber = null;
                String agentLocation = null;
                String agentAddress = null;
                String agentCardSerial = null;
                String agentType = null;
                String agentSecondName = null;
                String agentPhoto = null;
                String agentSwitchId = null;
                String agentSwitchPin = null;
                String agentFloatMax = null;
                String agentRegion = null;
                String agentParentCompany = null;
                String agentFloatAccount = null;
                String agentCommAccount = null;
                String agentThirdName = null;
                String agentAlternatePhone = null;
                String agentBankAccount = null;
                String agentLocationPhoto = null;
                String agentBranchCode = null;
                String agentBranchName = null;
                String agentBankName = null;

                while (iterator.hasNext()) {

                    GetAllAgents getAllAgents = new GetAllAgents();

                    JSONObject respObj = (JSONObject) iterator.next();
                    //agentId = (String)respObj.get("agentId");
                    agentCode = (String) respObj.get("agentCode");
                    agentCreatedBy = (String) respObj.get("agentCreatedBy");
                    //  agentDateCreated = (String)respObj.get("agentDateCreated");
                    // agentDateModified = (String)respObj.get("agentDateModified");
                    agentEmail = (String) respObj.get("agentEmail");
                    agentModifiedBy = (String) respObj.get("agentModifiedBy");
                    agentFirstName = (String) respObj.get("agentFirstName");
                    agentPhoneNo = (String) respObj.get("agentPhoneNo");
                    agentIdNumber = (String) respObj.get("agentIdNumber");
                    agentStatus = (String) respObj.get("agentStatus");
                    agentBusinessName = (String) respObj.get("agentBusinessName");
                    agentBusinessNumber = (String) respObj.get("agentBusinessNumber");
                    agentLocation = (String) respObj.get("agentLocation");
                    agentAddress = (String) respObj.get("agentAddress");
                    agentCardSerial = (String) respObj.get("agentCardSerial");
                    agentType = (String) respObj.get("agentType");
                    agentSecondName = (String) respObj.get("agentSecondName");
                    agentPhoto = (String) respObj.get("agentPhoto");
                    agentSwitchId = (String) respObj.get("agentSwitchId");
                    agentSwitchPin = (String) respObj.get("agentSwitchPin");
                    agentFloatMax = (String) respObj.get("agentFloatMax");
                    agentRegion = (String) respObj.get("agentRegion");
                    agentParentCompany = (String) respObj.get("agentParentCompany");
                    agentFloatAccount = (String) respObj.get("agentFloatAccount");
                    agentCommAccount = (String) respObj.get("agentCommAccount");
                    agentThirdName = (String) respObj.get("agentThirdName");
                    agentAlternatePhone = (String) respObj.get("agentAlternatePhone");
                    agentBankAccount = (String) respObj.get("agentBankAccount");
                    agentLocationPhoto = (String) respObj.get("agentLocationPhoto");
                    agentBranchCode = (String) respObj.get("agentBranchCode");
                    agentBranchName = (String) respObj.get("agentBranchName");
                    agentBankName = (String) respObj.get("agentBankName");

                    //  getAllAgents.setAgentId(agentId);
                    getAllAgents.setAgentCode(agentCode);
                    getAllAgents.setAgentCreatedBy(agentCreatedBy);
                    //  getAllAgents.setAgentDateCreated(agentDateCreated);
                    //  getAllAgents.setAgentDateModified(agentDateModified);
                    getAllAgents.setAgentEmail(agentEmail);
                    getAllAgents.setAgentModifiedBy(agentModifiedBy);
                    getAllAgents.setAgentFirstName(agentFirstName);
                    getAllAgents.setAgentPhoneNo(agentPhoneNo);
                    getAllAgents.setAgentIdNumber(agentIdNumber);
                    getAllAgents.setAgentStatus(agentStatus);
                    getAllAgents.setAgentBusinessName(agentBusinessName);
                    getAllAgents.setAgentBusinessNumber(agentBusinessNumber);
                    getAllAgents.setAgentLocation(agentLocation);
                    getAllAgents.setAgentAddress(agentAddress);
                    getAllAgents.setAgentCardSerial(agentCardSerial);
                    getAllAgents.setAgentType(agentType);
                    getAllAgents.setAgentSecondName(agentSecondName);
                    getAllAgents.setAgentPhoto(agentPhoto);
                    getAllAgents.setAgentSwitchId(agentSwitchId);
                    getAllAgents.setAgentSwitchPin(agentSwitchPin);
                    getAllAgents.setAgentFloatMax(agentFloatMax);
                    getAllAgents.setAgentRegion(agentRegion);
                    getAllAgents.setAgentParentCompany(agentParentCompany);
                    getAllAgents.setAgentFloatAccount(agentFloatAccount);
                    getAllAgents.setAgentCommAccount(agentCommAccount);
                    getAllAgents.setAgentThirdName(agentThirdName);
                    getAllAgents.setAgentAlternatePhone(agentAlternatePhone);
                    getAllAgents.setAgentBankAccount(agentBankAccount);
                    getAllAgents.setAgentLocationPhoto(agentLocationPhoto);
                    getAllAgents.setAgentBranchCode(agentBranchCode);
                    getAllAgents.setAgentBranchName(agentBranchName);
                    getAllAgents.setAgentBankName(agentBankName);

                    lName.add(getAllAgents);

                }
                request.setAttribute("allAgentsDetails", lName);
                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/agentusers.jsp");
                view.forward(request, response);
            } else {

                response.sendRedirect("/error.jsp");
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(agencyNetworkResponse);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());
            e.printStackTrace();

        }

    }

    /**
     * 2
     */
    /*Post to GET SINGLE AGENTS Request*/
    public void getSingleAgentsRequest(HttpServletRequest request, HttpServletResponse response, String agent_id) {

        //String agent_code = "001002";
        String agencyNetworkResponse = "";

        try {
            agencyNetworkResponse = sendRequest(Config.SINGLE_AGENT_ENDPOINT + agent_id);

            System.out.println("RESPONSE: " + agencyNetworkResponse);

            JSONParser parser = new JSONParser();

            String response_code = "000";
            String response_sub_code = "000";

            //System.out.println("Response Code: " + response_code);
            // HttpSession session = request.getSession(false);
            //  if (session != null) {
            //  String SESSION_ID = (String) session.getAttribute("session_id");
            if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")) {

                JSONObject respObj = (JSONObject) parser.parse(agencyNetworkResponse);

                String agentId = null;
                String agentCode = null;
                String agentCreatedBy = null;
                String agentDateCreated = null;
                String agentDateModified = null;
                String agentEmail = null;
                String agentModifiedBy = null;
                String agentFirstName = null;
                String agentPhoneNo = null;
                String agentIdNumber = null;
                String agentStatus = null;
                String agentBusinessName = null;
                String agentBusinessNumber = null;
                String agentLocation = null;
                String agentAddress = null;
                String agentCardSerial = null;
                String agentType = null;
                String agentSecondName = null;
                String agentPhoto = null;
                String agentSwitchId = null;
                String agentSwitchPin = null;
                String agentFloatMax = null;
                String agentRegion = null;
                String agentParentCompany = null;
                String agentFloatAccount = null;
                String agentCommAccount = null;
                String agentThirdName = null;
                String agentAlternatePhone = null;
                String agentBankAccount = null;
                String agentLocationPhoto = null;
                String agentBranchCode = null;
                String agentBranchName = null;
                String agentBankName = null;

                //agentId = (String) respObj.get("agentId");
                agentCode = (String) respObj.get("agentCode");
                agentCreatedBy = (String) respObj.get("agentCreatedBy");
                //agentDateCreated = (String) respObj.get("agentDateCreated");
                // agentDateModified = (String) respObj.get("agentDateModified");
                agentEmail = (String) respObj.get("agentEmail");
                agentModifiedBy = (String) respObj.get("agentModifiedBy");
                agentFirstName = (String) respObj.get("agentFirstName");
                agentPhoneNo = (String) respObj.get("agentPhoneNo");
                agentIdNumber = (String) respObj.get("agentIdNumber");
                agentStatus = (String) respObj.get("agentStatus");
                agentBusinessName = (String) respObj.get("agentBusinessName");
                agentBusinessNumber = (String) respObj.get("agentBusinessNumber");
                agentLocation = (String) respObj.get("agentLocation");
                agentAddress = (String) respObj.get("agentAddress");
                agentCardSerial = (String) respObj.get("agentCardSerial");
                agentType = (String) respObj.get("agentType");
                agentSecondName = (String) respObj.get("agentSecondName");
                agentPhoto = (String) respObj.get("agentPhoto");
                agentSwitchId = (String) respObj.get("agentSwitchId");
                agentSwitchPin = (String) respObj.get("agentSwitchPin");
                agentFloatMax = (String) respObj.get("agentFloatMax");
                agentRegion = (String) respObj.get("agentRegion");
                agentParentCompany = (String) respObj.get("agentParentCompany");
                agentFloatAccount = (String) respObj.get("agentFloatAccount");
                agentCommAccount = (String) respObj.get("agentCommAccount");
                agentThirdName = (String) respObj.get("agentThirdName");
                agentAlternatePhone = (String) respObj.get("agentAlternatePhone");
                agentBankAccount = (String) respObj.get("agentBankAccount");
                agentLocationPhoto = (String) respObj.get("agentLocationPhoto");
                agentBranchCode = (String) respObj.get("agentBranchCode");
                agentBranchName = (String) respObj.get("agentBranchName");
                agentBankName = (String) respObj.get("agentBankName");

                GetSingleAgent getSingleAgent = new GetSingleAgent();
                getSingleAgent.setAgentId(agentId);
                getSingleAgent.setAgentCode(agentCode);
                getSingleAgent.setAgentCreatedBy(agentCreatedBy);
                //getSingleAgent.setAgentDateCreated(String.valueOf(agentDateCreated));
                //getSingleAgent.setAgentDateModified(agentDateModified);
                getSingleAgent.setAgentEmail(agentEmail);
                getSingleAgent.setAgentModifiedBy(agentModifiedBy);
                getSingleAgent.setAgentFirstName(agentFirstName);
                getSingleAgent.setAgentPhoneNo(agentPhoneNo);
                getSingleAgent.setAgentIdNumber(agentIdNumber);
                getSingleAgent.setAgentStatus(agentStatus);
                getSingleAgent.setAgentBusinessName(agentBusinessName);
                getSingleAgent.setAgentBusinessNumber(agentBusinessNumber);
                getSingleAgent.setAgentLocation(agentLocation);
                getSingleAgent.setAgentAddress(agentAddress);
                getSingleAgent.setAgentCardSerial(agentCardSerial);
                getSingleAgent.setAgentType(agentType);
                getSingleAgent.setAgentSecondName(agentSecondName);
                getSingleAgent.setAgentPhoto(agentPhoto);
                getSingleAgent.setAgentSwitchId(agentSwitchId);
                getSingleAgent.setAgentSwitchPin(agentSwitchPin);
                getSingleAgent.setAgentFloatMax(agentFloatMax);
                getSingleAgent.setAgentRegion(agentRegion);
                getSingleAgent.setAgentParentCompany(agentParentCompany);
                getSingleAgent.setAgentFloatAccount(agentFloatAccount);
                getSingleAgent.setAgentCommAccount(agentCommAccount);
                getSingleAgent.setAgentThirdName(agentThirdName);
                getSingleAgent.setAgentAlternatePhone(agentAlternatePhone);
                getSingleAgent.setAgentBankAccount(agentBankAccount);
                getSingleAgent.setAgentLocationPhoto(agentLocationPhoto);
                getSingleAgent.setAgentBranchCode(agentBranchCode);
                getSingleAgent.setAgentBranchName(agentBranchName);
                getSingleAgent.setAgentBankName(agentBankName);

                request.setAttribute("singleAgentDetails", getSingleAgent);
                // RequestDispatcher view = request.getRequestDispatcher("/Eapps/Corporate/dash_board.jsp");
                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/profile.jsp");
                view.forward(request, response);

                System.out.println("Response Forwaded to Profile.jsp");
            } else {

                response.sendRedirect("/AgencyNetwork/error.jsp");
            }

            /**
             * } else {
             *
             * response.sendRedirect("/Eapps/Retail/index.jsp");
             * //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request,
             * response); }*
             */
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(agencyNetworkResponse);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 3
     */
    /*Post to ALL TRANSACTIONS Request*/
    public void getAllTransactionRequest(HttpServletRequest request, HttpServletResponse response) {

        String agencyNetworkResponse = "";

        try {
            agencyNetworkResponse = sendRequest(Config.ALL_TRANSACTIONS);
            JSONParser parser = new JSONParser();

            String response_code = "000";
            String response_sub_code = "000";

            System.out.println("Response Code: " + response_code);

            //  HttpSession session = request.getSession(false);
            //  if (session != null) {
            //  String SESSION_ID = (String) session.getAttribute("session_id");
            if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")) {

                JSONArray jsonarray = (JSONArray) parser.parse(agencyNetworkResponse);

                List<GetAllTransaction> lName = new ArrayList<GetAllTransaction>();

                Iterator<JSONObject> iterator = jsonarray.iterator();

//                String lName="list"+tr;
                // String agentId = null;
                String transAgent = null;
                String transAmount = null;
                // String agentDateCreated = null;
                // String agentDateModified = null;
                String transCreditCard = null;
                String transCustCard = null;
                String transCustId = null;
                Long transDate = null;
                String transDebitCard = null;
                String transDeviceId = null;
                Long transId = null;
                String transNumber = null;
                String transStatus = null;
                String transSwitchRef = null;
                String transType = null;
                String transUser = null;

                while (iterator.hasNext()) {

                    GetAllTransaction getAllTransaction = new GetAllTransaction();

                    JSONObject respObj = (JSONObject) iterator.next();
                    //agentId = (String)respObj.get("agentId");
                    transAgent = (String) respObj.get("transAgent");
                    transAmount = (String) respObj.get("transAmount");
                    //  agentDateCreated = (String)respObj.get("agentDateCreated");
                    // agentDateModified = (String)respObj.get("agentDateModified");
                    transCreditCard = (String) respObj.get("transCreditCard");
                    transCustCard = (String) respObj.get("transCustCard");
                    transCustId = (String) respObj.get("transCustId");
                    transDate = (Long) respObj.get("transDate");
                    transDebitCard = (String) respObj.get("transDebitCard");
                    transDeviceId = (String) respObj.get("transDeviceId");
                    transId = (Long) respObj.get("transId");
                    transNumber = (String) respObj.get("transNumber");
                    transStatus = (String) respObj.get("transStatus");
                    transSwitchRef = (String) respObj.get("transSwitchRef");
                    transType = (String) respObj.get("transType");
                    transUser = (String) respObj.get("transUser");

                    //  getAllAgents.setAgentId(agentId);
                    getAllTransaction.setTransAgent(transAgent);
                    getAllTransaction.setTransAmount(transAmount);
                    //  getAllAgents.setAgentDateCreated(agentDateCreated);
                    //  getAllAgents.setAgentDateModified(agentDateModified);
                    getAllTransaction.setTransCreditCard(transCreditCard);
                    getAllTransaction.setTransCustCard(transCustCard);
                    getAllTransaction.setTransCustId(transCustId);
                    getAllTransaction.setTransDate(transDate);
                    getAllTransaction.setTransDebitCard(transDebitCard);
                    getAllTransaction.setTransDeviceId(transDeviceId);
                    getAllTransaction.setTransId(transId);
                    getAllTransaction.setTransNumber(transNumber);
                    getAllTransaction.setTransStatus(transStatus);
                    getAllTransaction.setTransSwitchRef(transSwitchRef);
                    getAllTransaction.setTransType(transType);
                    getAllTransaction.setTransUser(transUser);

                    lName.add(getAllTransaction);

                }
                request.setAttribute("allTransactionsDetails", lName);
                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/dashboard.jsp");
                view.forward(request, response);
            } else {

                response.sendRedirect("/error.jsp");
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(agencyNetworkResponse);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());
            e.printStackTrace();

        }

    }

    /**
     * 4 GET MINI-STATEMENT
     */
    public void ministatementrequest(HttpServletRequest request, HttpServletResponse response) {

        String agencyNetworkResponse = "";

        try {
            agencyNetworkResponse = sendRequest(Config.ALL_TRANSACTIONS);
            JSONParser parser = new JSONParser();

            String response_code = "000";
            String response_sub_code = "000";

            System.out.println("Response Code: " + response_code);

            //  HttpSession session = request.getSession(false);
            //  if (session != null) {
            //  String SESSION_ID = (String) session.getAttribute("session_id");
            if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")) {

                JSONArray jsonarray = (JSONArray) parser.parse(agencyNetworkResponse);

                List<GetMiniStatement> lName = new ArrayList<GetMiniStatement>();

                Iterator<JSONObject> iterator = jsonarray.iterator();

//                String lName="list"+tr;
                // String agentId = null;
                String transAgent = null;
                String transAmount = null;
                // String agentDateCreated = null;
                // String agentDateModified = null;
                String transCreditCard = null;
                String transCustCard = null;
                String transCustId = null;
                Long transDate = null;
                String transDebitCard = null;
                String transDeviceId = null;
                Long transId = null;
                String transNumber = null;
                String transStatus = null;
                String transSwitchRef = null;
                String transType = null;
                String transUser = null;

                while (iterator.hasNext()) {

                    GetMiniStatement getAllMiniStatement = new GetMiniStatement();

                    JSONObject respObj = (JSONObject) iterator.next();
                    //agentId = (String)respObj.get("agentId");
                    transAgent = (String) respObj.get("transAgent");
                    transAmount = (String) respObj.get("transAmount");
                    //  agentDateCreated = (String)respObj.get("agentDateCreated");
                    // agentDateModified = (String)respObj.get("agentDateModified");
                    transCreditCard = (String) respObj.get("transCreditCard");
                    transCustCard = (String) respObj.get("transCustCard");
                    transCustId = (String) respObj.get("transCustId");
                    transDate = (Long) respObj.get("transDate");
                    transDebitCard = (String) respObj.get("transDebitCard");
                    transDeviceId = (String) respObj.get("transDeviceId");
                    transId = (Long) respObj.get("transId");
                    transNumber = (String) respObj.get("transNumber");
                    transStatus = (String) respObj.get("transStatus");
                    transSwitchRef = (String) respObj.get("transSwitchRef");
                    transType = (String) respObj.get("transType");
                    transUser = (String) respObj.get("transUser");

                    //  getAllAgents.setAgentId(agentId);
                    getAllMiniStatement.setTransAgent(transAgent);
                    getAllMiniStatement.setTransAmount(transAmount);
                    //  getAllAgents.setAgentDateCreated(agentDateCreated);
                    //  getAllAgents.setAgentDateModified(agentDateModified);
                    getAllMiniStatement.setTransCreditCard(transCreditCard);
                    getAllMiniStatement.setTransCustCard(transCustCard);
                    getAllMiniStatement.setTransCustId(transCustId);
                    getAllMiniStatement.setTransDate(transDate);
                    getAllMiniStatement.setTransDebitCard(transDebitCard);
                    getAllMiniStatement.setTransDeviceId(transDeviceId);
                    getAllMiniStatement.setTransId(transId);
                    getAllMiniStatement.setTransNumber(transNumber);
                    getAllMiniStatement.setTransStatus(transStatus);
                    getAllMiniStatement.setTransSwitchRef(transSwitchRef);
                    getAllMiniStatement.setTransType(transType);
                    getAllMiniStatement.setTransUser(transUser);

                    lName.add(getAllMiniStatement);

                }
                request.setAttribute("miniStatement", lName);
                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/ministatement.jsp");
                view.forward(request, response);
            } else {

                response.sendRedirect("/error.jsp");
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(agencyNetworkResponse);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());
            e.printStackTrace();

        }

    }

    /**
     * 4 GET FULL STATEMENT
     */
    public void fullstatementrequest(HttpServletRequest request, HttpServletResponse response) {

        String agencyNetworkResponse = "";

        try {
            agencyNetworkResponse = sendRequest(Config.ALL_TRANSACTIONS);
            JSONParser parser = new JSONParser();

            String response_code = "000";
            String response_sub_code = "000";

            System.out.println("Response Code: " + response_code);

            //  HttpSession session = request.getSession(false);
            //  if (session != null) {
            //  String SESSION_ID = (String) session.getAttribute("session_id");
            if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")) {

                JSONArray jsonarray = (JSONArray) parser.parse(agencyNetworkResponse);

                List<GetFullStatement> lName = new ArrayList<GetFullStatement>();

                Iterator<JSONObject> iterator = jsonarray.iterator();

//                String lName="list"+tr;
                // String agentId = null;
                String transAgent = null;
                String transAmount = null;
                // String agentDateCreated = null;
                // String agentDateModified = null;
                String transCreditCard = null;
                String transCustCard = null;
                String transCustId = null;
                Long transDate = null;
                String transDebitCard = null;
                String transDeviceId = null;
                Long transId = null;
                String transNumber = null;
                String transStatus = null;
                String transSwitchRef = null;
                String transType = null;
                String transUser = null;

                while (iterator.hasNext()) {

                    GetFullStatement getFullStatement = new GetFullStatement();

                    JSONObject respObj = (JSONObject) iterator.next();
                    //agentId = (String)respObj.get("agentId");
                    transAgent = (String) respObj.get("transAgent");
                    transAmount = (String) respObj.get("transAmount");
                    //  agentDateCreated = (String)respObj.get("agentDateCreated");
                    // agentDateModified = (String)respObj.get("agentDateModified");
                    transCreditCard = (String) respObj.get("transCreditCard");
                    transCustCard = (String) respObj.get("transCustCard");
                    transCustId = (String) respObj.get("transCustId");
                    transDate = (Long) respObj.get("transDate");
                    transDebitCard = (String) respObj.get("transDebitCard");
                    transDeviceId = (String) respObj.get("transDeviceId");
                    transId = (Long) respObj.get("transId");
                    transNumber = (String) respObj.get("transNumber");
                    transStatus = (String) respObj.get("transStatus");
                    transSwitchRef = (String) respObj.get("transSwitchRef");
                    transType = (String) respObj.get("transType");
                    transUser = (String) respObj.get("transUser");

                    //  getAllAgents.setAgentId(agentId);
                    getFullStatement.setTransAgent(transAgent);
                    getFullStatement.setTransAmount(transAmount);
                    //  getAllAgents.setAgentDateCreated(agentDateCreated);
                    //  getAllAgents.setAgentDateModified(agentDateModified);
                    getFullStatement.setTransCreditCard(transCreditCard);
                    getFullStatement.setTransCustCard(transCustCard);
                    getFullStatement.setTransCustId(transCustId);
                    getFullStatement.setTransDate(transDate);
                    getFullStatement.setTransDebitCard(transDebitCard);
                    getFullStatement.setTransDeviceId(transDeviceId);
                    getFullStatement.setTransId(transId);
                    getFullStatement.setTransNumber(transNumber);
                    getFullStatement.setTransStatus(transStatus);
                    getFullStatement.setTransSwitchRef(transSwitchRef);
                    getFullStatement.setTransType(transType);
                    getFullStatement.setTransUser(transUser);

                    lName.add(getFullStatement);

                }
                request.setAttribute("fullStatement", lName);
                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/fullstatement.jsp");
                view.forward(request, response);
            } else {

                response.sendRedirect("/error.jsp");
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(agencyNetworkResponse);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());
            e.printStackTrace();

        }

    }

    /**
     * 4 GET FULL COMMISION
     */
    public void fullcommisionrequest(HttpServletRequest request, HttpServletResponse response) {

        String agencyNetworkResponse = "";

        try {
            agencyNetworkResponse = sendRequest(Config.ALL_TRANSACTIONS);
            JSONParser parser = new JSONParser();

            String response_code = "000";
            String response_sub_code = "000";

            System.out.println("Response Code: " + response_code);

            //  HttpSession session = request.getSession(false);
            //  if (session != null) {
            //  String SESSION_ID = (String) session.getAttribute("session_id");
            if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")) {

                JSONArray jsonarray = (JSONArray) parser.parse(agencyNetworkResponse);

                List<GetFullCommision> lName = new ArrayList<GetFullCommision>();

                Iterator<JSONObject> iterator = jsonarray.iterator();

//                String lName="list"+tr;
                // String agentId = null;
                String transAgent = null;
                String transAmount = null;
                // String agentDateCreated = null;
                // String agentDateModified = null;
                String transCreditCard = null;
                String transCustCard = null;
                String transCustId = null;
                Long transDate = null;
                String transDebitCard = null;
                String transDeviceId = null;
                Long transId = null;
                String transNumber = null;
                String transStatus = null;
                String transSwitchRef = null;
                String transType = null;
                String transUser = null;

                while (iterator.hasNext()) {

                    GetFullCommision getFullCommision = new GetFullCommision();

                    JSONObject respObj = (JSONObject) iterator.next();
                    //agentId = (String)respObj.get("agentId");
                    transAgent = (String) respObj.get("transAgent");
                    transAmount = (String) respObj.get("transAmount");
                    //  agentDateCreated = (String)respObj.get("agentDateCreated");
                    // agentDateModified = (String)respObj.get("agentDateModified");
                    transCreditCard = (String) respObj.get("transCreditCard");
                    transCustCard = (String) respObj.get("transCustCard");
                    transCustId = (String) respObj.get("transCustId");
                    transDate = (Long) respObj.get("transDate");
                    transDebitCard = (String) respObj.get("transDebitCard");
                    transDeviceId = (String) respObj.get("transDeviceId");
                    transId = (Long) respObj.get("transId");
                    transNumber = (String) respObj.get("transNumber");
                    transStatus = (String) respObj.get("transStatus");
                    transSwitchRef = (String) respObj.get("transSwitchRef");
                    transType = (String) respObj.get("transType");
                    transUser = (String) respObj.get("transUser");

                    //  getAllAgents.setAgentId(agentId);
                    getFullCommision.setTransAgent(transAgent);
                    getFullCommision.setTransAmount(transAmount);
                    //  getAllAgents.setAgentDateCreated(agentDateCreated);
                    //  getAllAgents.setAgentDateModified(agentDateModified);
                    getFullCommision.setTransCreditCard(transCreditCard);
                    getFullCommision.setTransCustCard(transCustCard);
                    getFullCommision.setTransCustId(transCustId);
                    getFullCommision.setTransDate(transDate);
                    getFullCommision.setTransDebitCard(transDebitCard);
                    getFullCommision.setTransDeviceId(transDeviceId);
                    getFullCommision.setTransId(transId);
                    getFullCommision.setTransNumber(transNumber);
                    getFullCommision.setTransStatus(transStatus);
                    getFullCommision.setTransSwitchRef(transSwitchRef);
                    getFullCommision.setTransType(transType);
                    getFullCommision.setTransUser(transUser);

                    lName.add(getFullCommision);

                }
                request.setAttribute("fullCommision", lName);
                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/fullCommission.jsp");
                view.forward(request, response);
            } else {

                response.sendRedirect("/error.jsp");
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(agencyNetworkResponse);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());
            e.printStackTrace();

        }

    }
    
    /**
     * 4 GET FULL COMMISION
     */
    
     public void depositrequest(HttpServletRequest request, HttpServletResponse response) {

        String agencyNetworkResponse = "";

        try {
            agencyNetworkResponse = sendRequest(Config.TRANSACTIONS_DEPOSIT);
            JSONParser parser = new JSONParser();

            String response_code = "000";
            String response_sub_code = "000";

            System.out.println("Response Code: " + response_code);

            //  HttpSession session = request.getSession(false);
            //  if (session != null) {
            //  String SESSION_ID = (String) session.getAttribute("session_id");
            if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")) {

                JSONArray jsonarray = (JSONArray) parser.parse(agencyNetworkResponse);

                List<DepositRequest> lName = new ArrayList<DepositRequest>();

                Iterator<JSONObject> iterator = jsonarray.iterator();


                String transAgent = null;
                String transAmount = null;
                String transCreditCard = null;
                String transCurrency = null;
                Long transCustId = null;
                String transCustCard = null;
                String transCustomerAcct = null;
                String transDeviceId = null;
                

                while (iterator.hasNext()) {

                    DepositRequest depositRequest = new DepositRequest();

                    JSONObject respObj = (JSONObject) iterator.next();
                    
                    transAgent = (String) respObj.get("transAgent");
                    transAmount = (String) respObj.get("transAmount");
                    transCurrency = (String) respObj.get("transCurrency");
                    transCreditCard = (String) respObj.get("transCreditCard");
                    transCustCard = (String) respObj.get("transCustCard");
                    transCustId = (long) respObj.get("transCustId");
                    transCustomerAcct = (String) respObj.get("transCustomerAcct");
                    transDeviceId = (String) respObj.get("transDeviceId");


                    depositRequest.setTransAgent(transAgent);
                    depositRequest.setTransAmount(transAmount);
                    depositRequest.setTransCreditCard(transCreditCard);
                    depositRequest.setTransCustCard(transCustCard);
                    depositRequest.setTransCustId(transCustId);
                    depositRequest.setTransDate(transCustomerAcct);
                    depositRequest.setTransCurrency(transCurrency);
                    depositRequest.setTransDeviceId(transDeviceId);
                 

                    lName.add(depositRequest);

                }
                request.setAttribute("depositRequest", lName);
                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/deposit.jsp");
                view.forward(request, response);
            } else {

                response.sendRedirect("/error.jsp");
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(agencyNetworkResponse);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());
            e.printStackTrace();

        }
     }
     
     
     
     
     /**
     * 4 GET FULL COMMISION
     */
    
     public void withdrawrequest(HttpServletRequest request, HttpServletResponse response) {

        String agencyNetworkResponse = "";

        try {
            agencyNetworkResponse = sendRequest(Config.TRANSACTIONS_DEPOSIT);
            JSONParser parser = new JSONParser();

            String response_code = "000";
            String response_sub_code = "000";

            System.out.println("Response Code: " + response_code);

            //  HttpSession session = request.getSession(false);
            //  if (session != null) {
            //  String SESSION_ID = (String) session.getAttribute("session_id");
            if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")) {

                JSONArray jsonarray = (JSONArray) parser.parse(agencyNetworkResponse);

                List<WithdrawRequest> lName = new ArrayList<WithdrawRequest>();

                Iterator<JSONObject> iterator = jsonarray.iterator();


                String transAgent = null;
                String transAmount = null;
                String transCreditCard = null;
                String transCurrency = null;
                Long transCustId = null;
                String transCustCard = null;
                String transCustomerAcct = null;
                String transDeviceId = null;
                

              

                    WithdrawRequest withdrawRequest = new WithdrawRequest();

                    JSONObject respObj = (JSONObject) iterator.next();
                    
                    transAgent = (String) respObj.get("transAgent");
                    transAmount = (String) respObj.get("transAmount");
                    transCurrency = (String) respObj.get("transCurrency");
                    transCreditCard = (String) respObj.get("transCreditCard");
                    transCustCard = (String) respObj.get("transCustCard");
                    transCustId = (long) respObj.get("transCustId");
                    transCustomerAcct = (String) respObj.get("transCustomerAcct");
                    transDeviceId = (String) respObj.get("transDeviceId");


                    withdrawRequest.setTransAgent(transAgent);
                    withdrawRequest.setTransAmount(transAmount);
                    withdrawRequest.setTransCreditCard(transCreditCard);
                    withdrawRequest.setTransCustCard(transCustCard);
                    withdrawRequest.setTransCustId(transCustId);
                    withdrawRequest.setTransDate(transCustomerAcct);
                    withdrawRequest.setTransCurrency(transCurrency);
                    withdrawRequest.setTransDeviceId(transDeviceId);
                 

                    lName.add(withdrawRequest);

          
                request.setAttribute("withdrawRequest", lName);
                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/withdraw.jsp");
                view.forward(request, response);
            } else {

                response.sendRedirect("/error.jsp");
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(agencyNetworkResponse);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());
            e.printStackTrace();

        }
     }
     
     
     
     
     
     
     /*Method to Send POST Request to server*/
    public static String sendPOSTRequest(String req, String endPoint) throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        System.out.println("Requeted URL:" + endPoint);
        CloseableHttpResponse response = null;
        String agencyresponse = null;
        
        try {

//            SSLContextBuilder builder = new SSLContextBuilder();
//            builder.loadTrustMaterial(null, new TrustStrategy() {
//                @Override
//                public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
//                    return true;
//                }
//
//            });
//
//            SSLConnectionSocketFactory sslSF = new SSLConnectionSocketFactory(builder.build(),
//                    SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            // CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslSF).build();
            CloseableHttpClient httpclient = HttpClients.createDefault();

            HttpPost httpPost = new HttpPost(endPoint);

            StringEntity entity = new StringEntity(req, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);

            response = httpclient.execute(httpPost);
            int code = response.getStatusLine().getStatusCode();

            agencyresponse = EntityUtils.toString(response.getEntity());

            System.out.println("EappsCore Response Status Code: " + code);

        } catch (UnsupportedEncodingException ex) {

        } catch (IOException ex) {

            //handle timeout
        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException ex) {

                }
            }
        }

        System.out.println("Response" + agencyresponse);

        return agencyresponse;
    }
    
    
    
    
    

    /*Method to Send Request to server*/
    public String sendRequest(String myURL) throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        System.out.println("Requeted URL:" + myURL);

        StringBuilder sb = new StringBuilder();
        URLConnection urlConn = null;
        InputStreamReader in = null;
        try {
            URL url = new URL(myURL);
            urlConn = url.openConnection();
            if (urlConn != null) {
                urlConn.setReadTimeout(60 * 1000);
            }
            if (urlConn != null && urlConn.getInputStream() != null) {
                in = new InputStreamReader(urlConn.getInputStream(),
                        Charset.defaultCharset().defaultCharset());
                BufferedReader bufferedReader = new BufferedReader(in);
                if (bufferedReader != null) {
                    int cp;
                    while ((cp = bufferedReader.read()) != -1) {
                        sb.append((char) cp);
                    }
                    bufferedReader.close();
                }
            }
            in.close();
        } catch (Exception e) {
            throw new RuntimeException("Exception while calling URL:" + myURL, e);
        }

        return sb.toString();
    }

    /**
     *
     *
     * public String sendRequest() throws KeyStoreException,
     * NoSuchAlgorithmException, KeyManagementException { CloseableHttpResponse
     * response = null; String agencyResponse = null; try {
     *
     * // SSLContextBuilder builder = new SSLContextBuilder(); //
     * builder.loadTrustMaterial(null, new TrustStrategy() { // @Override //
     * public boolean isTrusted(X509Certificate[] chain, String authType) throws
     * CertificateException { // return true; // } // // }); // //
     * SSLConnectionSocketFactory sslSF = new
     * SSLConnectionSocketFactory(builder.build(), //
     * SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
     *
     * // CloseableHttpClient httpclient =
     * HttpClients.custom().setSSLSocketFactory(sslSF).build();
     *
     * CloseableHttpClient httpclient = HttpClients.createDefault();
     *
     * HttpPost httpPost = new HttpPost(Config.ALL_AGENTS_ENDPOINT);
     *
     *
     * //StringEntity entity = new StringEntity(req);
     * //httpPost.setEntity(entity);
     *
     * response = httpclient.execute(httpPost); int code =
     * response.getStatusLine().getStatusCode();
     *
     * agencyResponse = EntityUtils.toString(response.getEntity());
     *
     * System.out.println("EappsCore Response Status Code: " + code);
     *
     * } catch (UnsupportedEncodingException ex) {
     *
     * } catch (IOException ex) {
     *
     * } finally { if (response != null) { try { response.close(); } catch
     * (IOException ex) {
     *
     * }
     * }
     * }
     * return agencyResponse; }
     *
     */
}
