/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obi.agencynetwork.web.model;

/**
 *
 * @author { VIN }
 */
public class DepositRequest {

    private String transAgent;
    private String transAmount;
    private String transCurrency;
    private String transCreditCard;
    private String transCustCard;
    private Long transCustId;
    private String transDate;
    private String transDeviceId;

    /**
     * @return the transAgent
     */
    public String getTransAgent() {
        return transAgent;
    }

    /**
     * @param transAgent the transAgent to set
     */
    public void setTransAgent(String transAgent) {
        this.transAgent = transAgent;
    }

    /**
     * @return the transAmount
     */
    public String getTransAmount() {
        return transAmount;
    }

    /**
     * @param transAmount the transAmount to set
     */
    public void setTransAmount(String transAmount) {
        this.transAmount = transAmount;
    }

    /**
     * @return the transCurrency
     */
    public String getTransCurrency() {
        return transCurrency;
    }

    /**
     * @param transCurrency the transCurrency to set
     */
    public void setTransCurrency(String transCurrency) {
        this.transCurrency = transCurrency;
    }

    /**
     * @return the transCreditCard
     */
    public String getTransCreditCard() {
        return transCreditCard;
    }

    /**
     * @param transCreditCard the transCreditCard to set
     */
    public void setTransCreditCard(String transCreditCard) {
        this.transCreditCard = transCreditCard;
    }

    /**
     * @return the transCustCard
     */
    public String getTransCustCard() {
        return transCustCard;
    }

    /**
     * @param transCustCard the transCustCard to set
     */
    public void setTransCustCard(String transCustCard) {
        this.transCustCard = transCustCard;
    }

    /**
     * @return the transCustId
     */
    public Long getTransCustId() {
        return transCustId;
    }

    /**
     * @param transCustId the transCustId to set
     */
    public void setTransCustId(Long transCustId) {
        this.transCustId = transCustId;
    }

    /**
     * @return the transDate
     */
    public String getTransDate() {
        return transDate;
    }

    /**
     * @param transDate the transDate to set
     */
    public void setTransDate(String transDate) {
        this.transDate = transDate;
    }

    /**
     * @return the transDeviceId
     */
    public String getTransDeviceId() {
        return transDeviceId;
    }

    /**
     * @param transDeviceId the transDeviceId to set
     */
    public void setTransDeviceId(String transDeviceId) {
        this.transDeviceId = transDeviceId;
    }

}
