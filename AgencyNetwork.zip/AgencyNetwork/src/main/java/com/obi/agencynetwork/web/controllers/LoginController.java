/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obi.agencynetwork.web.controllers;

import com.obi.agencynetwork.web.BusinessLogic;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author SAM
 */
@WebServlet(urlPatterns = {"/LoggedIn"})
public class LoginController extends HttpServlet  {

    BusinessLogic businessLogic;
    private final String agentID = "admin";
    private final String password = "password";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String agent_code = request.getParameter("username");
        String password = request.getParameter("password");

        if (!agent_code.isEmpty() && !password.isEmpty()) {
            
            HttpSession session = request.getSession();
			session.setAttribute("agent_code", agent_code);
			//setting session to expiry in 30 mins
			session.setMaxInactiveInterval(30*60);
            
            Cookie loginCookie = new Cookie("agent_code",agent_code);
			//setting cookie to expiry in 30 mins
			loginCookie.setMaxAge(30*60);
			response.addCookie(loginCookie);

            businessLogic = new BusinessLogic();
            //businessLogic.getSingleAgentsRequest(request, response, agent_code);
            businessLogic.getAllTransactionRequest(request, response);

        }
        else{
           response.sendRedirect("index.jsp");
        }

    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);
    }

}
