/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author Nzangi
 */
public class CorpBalanceRequest40 {

    private String resp_code_,
            resp_subcode_,
            session_id_,
            resp_desc_,
            avail_bal_,
            cur_bal_;

    /**
     * @return the resp_code_
     */
    public String getResp_code_() {
        return resp_code_;
    }

    /**
     * @param resp_code_ the resp_code_ to set
     */
    public void setResp_code_(String resp_code_) {
        this.resp_code_ = resp_code_;
    }

    /**
     * @return the resp_subcode_
     */
    public String getResp_subcode_() {
        return resp_subcode_;
    }

    /**
     * @param resp_subcode_ the resp_subcode_ to set
     */
    public void setResp_subcode_(String resp_subcode_) {
        this.resp_subcode_ = resp_subcode_;
    }

    /**
     * @return the session_id_
     */
    public String getSession_id_() {
        return session_id_;
    }

    /**
     * @param session_id_ the session_id_ to set
     */
    public void setSession_id_(String session_id_) {
        this.session_id_ = session_id_;
    }

    /**
     * @return the resp_desc_
     */
    public String getResp_desc_() {
        return resp_desc_;
    }

    /**
     * @param resp_desc_ the resp_desc_ to set
     */
    public void setResp_desc_(String resp_desc_) {
        this.resp_desc_ = resp_desc_;
    }

    /**
     * @return the avail_bal_
     */
    public String getAvail_bal_() {
        return avail_bal_;
    }

    /**
     * @param avail_bal_ the avail_bal_ to set
     */
    public void setAvail_bal_(String avail_bal_) {
        this.avail_bal_ = avail_bal_;
    }

    /**
     * @return the cur_bal_
     */
    public String getCur_bal_() {
        return cur_bal_;
    }

    /**
     * @param cur_bal_ the cur_bal_ to set
     */
    public void setCur_bal_(String cur_bal_) {
        this.cur_bal_ = cur_bal_;
    }
}
