/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author Nzangi
 */
public class GetTranTypeRequest32 {

    private String inst_id_,
            transfer_name_,
            transfer_type_,
            transfer_code_,
            status_,
            auth_status_,
            maker_name_,
            auth_name_,
            rej_reason_,
            auth_desc_,
            rec_id_,
            maker_role_;

    /**
     * @return the inst_id_
     */
    public String getInst_id_() {
        return inst_id_;
    }

    /**
     * @param inst_id_ the inst_id_ to set
     */
    public void setInst_id_(String inst_id_) {
        this.inst_id_ = inst_id_;
    }

    /**
     * @return the transfer_name_
     */
    public String getTransfer_name_() {
        return transfer_name_;
    }

    /**
     * @param transfer_name_ the transfer_name_ to set
     */
    public void setTransfer_name_(String transfer_name_) {
        this.transfer_name_ = transfer_name_;
    }

    /**
     * @return the transfer_type_
     */
    public String getTransfer_type_() {
        return transfer_type_;
    }

    /**
     * @param transfer_type_ the transfer_type_ to set
     */
    public void setTransfer_type_(String transfer_type_) {
        this.transfer_type_ = transfer_type_;
    }

    /**
     * @return the transfer_code_
     */
    public String getTransfer_code_() {
        return transfer_code_;
    }

    /**
     * @param transfer_code_ the transfer_code_ to set
     */
    public void setTransfer_code_(String transfer_code_) {
        this.transfer_code_ = transfer_code_;
    }

    /**
     * @return the status_
     */
    public String getStatus_() {
        return status_;
    }

    /**
     * @param status_ the status_ to set
     */
    public void setStatus_(String status_) {
        this.status_ = status_;
    }

    /**
     * @return the auth_status_
     */
    public String getAuth_status_() {
        return auth_status_;
    }

    /**
     * @param auth_status_ the auth_status_ to set
     */
    public void setAuth_status_(String auth_status_) {
        this.auth_status_ = auth_status_;
    }

    /**
     * @return the maker_name_
     */
    public String getMaker_name_() {
        return maker_name_;
    }

    /**
     * @param maker_name_ the maker_name_ to set
     */
    public void setMaker_name_(String maker_name_) {
        this.maker_name_ = maker_name_;
    }

    /**
     * @return the auth_name_
     */
    public String getAuth_name_() {
        return auth_name_;
    }

    /**
     * @param auth_name_ the auth_name_ to set
     */
    public void setAuth_name_(String auth_name_) {
        this.auth_name_ = auth_name_;
    }

    /**
     * @return the rej_reason_
     */
    public String getRej_reason_() {
        return rej_reason_;
    }

    /**
     * @param rej_reason_ the rej_reason_ to set
     */
    public void setRej_reason_(String rej_reason_) {
        this.rej_reason_ = rej_reason_;
    }

    /**
     * @return the auth_desc_
     */
    public String getAuth_desc_() {
        return auth_desc_;
    }

    /**
     * @param auth_desc_ the auth_desc_ to set
     */
    public void setAuth_desc_(String auth_desc_) {
        this.auth_desc_ = auth_desc_;
    }

    /**
     * @return the rec_id_
     */
    public String getRec_id_() {
        return rec_id_;
    }

    /**
     * @param rec_id_ the rec_id_ to set
     */
    public void setRec_id_(String rec_id_) {
        this.rec_id_ = rec_id_;
    }

    /**
     * @return the maker_role_
     */
    public String getMaker_role_() {
        return maker_role_;
    }

    /**
     * @param maker_role_ the maker_role_ to set
     */
    public void setMaker_role_(String maker_role_) {
        this.maker_role_ = maker_role_;
    }

}
