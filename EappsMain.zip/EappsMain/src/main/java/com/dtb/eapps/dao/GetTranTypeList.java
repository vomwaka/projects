/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nzangi
 */
public class GetTranTypeList {

    private int k;
    List<List> arrLst = new ArrayList<>();

    public GetTranTypeList(int k) {
        this.k = k;
    }
    private String resp_code, resp_subcode, session_id, resp_desc,
            inst_id, transfer_name, transfer_type, transfer_code, status, auth_status, maker_name, auth_name, rej_reason, auth_desc,
            rec_id, maker_role;

    ;
//    List<String> list = new ArrayList<>();

    /**
     * @return the resp_code
     */
    public String getResp_code() {
        return resp_code;
    }

    /**
     * @param resp_code the resp_code to set
     */
    public void setResp_code(String resp_code) {
        this.resp_code = resp_code;
    }

    /**
     * @return the resp_subcode
     */
    public String getResp_subcode() {
        return resp_subcode;
    }

    /**
     * @param resp_subcode the resp_subcode to set
     */
    public void setResp_subcode(String resp_subcode) {
        this.resp_subcode = resp_subcode;
    }

    /**
     * @return the session_id
     */
    public String getSession_id() {
        return session_id;
    }

    /**
     * @param session_id the session_id to set
     */
    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    /**
     * @return the resp_desc
     */
    public String getResp_desc() {
        return resp_desc;
    }

    /**
     * @param resp_desc the resp_desc to set
     */
    public void setResp_desc(String resp_desc) {
        this.resp_desc = resp_desc;
    }

    /**
     * @return the inst_id
     */
    public String getInst_id() {
        return inst_id;
    }

    /**
     * @param inst_id the inst_id to set
     */
    public void setInst_id(String inst_id, List<String> list) {
        this.inst_id = inst_id;
        list.add(this.inst_id);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the transfer_name
     */
    public String getTransfer_name() {
        return transfer_name;
    }

    /**
     * @param transfer_name the transfer_name to set
     */
    public void setTransfer_name(String transfer_name, List<String> list) {
        this.transfer_name = transfer_name;
        list.add(this.transfer_name);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the transfer_type
     */
    public String getTransfer_type() {
        return transfer_type;
    }

    /**
     * @param transfer_type the transfer_type to set
     */
    public void setTransfer_type(String transfer_type, List<String> list) {
        this.transfer_type = transfer_type;
        list.add(this.transfer_type);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the transfer_code
     */
    public String getTransfer_code() {
        return transfer_code;
    }

    /**
     * @param transfer_code the transfer_code to set
     */
    public void setTransfer_code(String transfer_code, List<String> list) {
        this.transfer_code = transfer_code;
        list.add(this.transfer_code);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status, List<String> list) {
        this.status = status;
        list.add(this.status);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the auth_status
     */
    public String getAuth_status() {
        return auth_status;
    }

    /**
     * @param auth_status the auth_status to set
     */
    public void setAuth_status(String auth_status, List<String> list) {
        this.auth_status = auth_status;
        list.add(this.auth_status);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the maker_name
     */
    public String getMaker_name() {
        return maker_name;
    }

    /**
     * @param maker_name the maker_name to set
     */
    public void setMaker_name(String maker_name, List<String> list) {
        this.maker_name = maker_name;
        list.add(this.maker_name);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the auth_name
     */
    public String getAuth_name() {
        return auth_name;
    }

    /**
     * @param auth_name the auth_name to set
     */
    public void setAuth_name(String auth_name, List<String> list) {
        this.auth_name = auth_name;
        list.add(this.auth_name);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the rej_reason
     */
    public String getRej_reason() {
        return rej_reason;
    }

    /**
     * @param rej_reason the rej_reason to set
     */
    public void setRej_reason(String rej_reason, List<String> list) {
        this.rej_reason = rej_reason;
        list.add(this.rej_reason);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the auth_desc
     */
    public String getAuth_desc() {
        return auth_desc;
    }

    /**
     * @param auth_desc the auth_desc to set
     */
    public void setAuth_desc(String auth_desc, List<String> list) {
        this.auth_desc = auth_desc;
        list.add(this.auth_desc);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the rec_id
     */
    public String getRec_id() {
        return rec_id;
    }

    /**
     * @param rec_id the rec_id to set
     */
    public void setRec_id(String rec_id, List<String> list) {
        this.rec_id = rec_id;
        list.add(this.rec_id);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    /**
     * @return the maker_role
     */
    public String getMaker_role() {
        return maker_role;
    }

    /**
     * @param maker_role the maker_role to set
     */
    public void setMaker_role(String maker_role, List<String> list) {
        this.maker_role = maker_role;
        list.add(this.maker_role);
        if (list.size() == k) {
            listHolder(list);
        }
    }

    public List<List> listHolder(List<String> list) {
        arrLst.add(list);
        return arrLst;
    }

}
