/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.servlets.retail.web;

/**
 *
 * @author Nzangi
 */
public class GetRelationshipList2 {

    private String inst_id_,
            rel_id_,
            rel_desc_,
            rec_id_,
            auth_status_,
            maker_name_,
            auth_desc_,
            status_,
            reject_reason_,
            auth_name_,
            maker_role_;

    /**
     * @return the inst_id_
     */
    public String getInst_id_() {
        return inst_id_;
    }

    /**
     * @param inst_id_ the inst_id_ to set
     */
    public void setInst_id_(String inst_id_) {
        this.inst_id_ = inst_id_;
    }

    /**
     * @return the rel_id_
     */
    public String getRel_id_() {
        return rel_id_;
    }

    /**
     * @param rel_id_ the rel_id_ to set
     */
    public void setRel_id_(String rel_id_) {
        this.rel_id_ = rel_id_;
    }

    /**
     * @return the rel_desc_
     */
    public String getRel_desc_() {
        return rel_desc_;
    }

    /**
     * @param rel_desc_ the rel_desc_ to set
     */
    public void setRel_desc_(String rel_desc_) {
        this.rel_desc_ = rel_desc_;
    }

    /**
     * @return the rec_id_
     */
    public String getRec_id_() {
        return rec_id_;
    }

    /**
     * @param rec_id_ the rec_id_ to set
     */
    public void setRec_id_(String rec_id_) {
        this.rec_id_ = rec_id_;
    }

    /**
     * @return the auth_status_
     */
    public String getAuth_status_() {
        return auth_status_;
    }

    /**
     * @param auth_status_ the auth_status_ to set
     */
    public void setAuth_status_(String auth_status_) {
        this.auth_status_ = auth_status_;
    }

    /**
     * @return the maker_name_
     */
    public String getMaker_name_() {
        return maker_name_;
    }

    /**
     * @param maker_name_ the maker_name_ to set
     */
    public void setMaker_name_(String maker_name_) {
        this.maker_name_ = maker_name_;
    }

    /**
     * @return the auth_desc_
     */
    public String getAuth_desc_() {
        return auth_desc_;
    }

    /**
     * @param auth_desc_ the auth_desc_ to set
     */
    public void setAuth_desc_(String auth_desc_) {
        this.auth_desc_ = auth_desc_;
    }

    /**
     * @return the status_
     */
    public String getStatus_() {
        return status_;
    }

    /**
     * @param status_ the status_ to set
     */
    public void setStatus_(String status_) {
        this.status_ = status_;
    }

    /**
     * @return the reject_reason_
     */
    public String getReject_reason_() {
        return reject_reason_;
    }

    /**
     * @param reject_reason_ the reject_reason_ to set
     */
    public void setReject_reason_(String reject_reason_) {
        this.reject_reason_ = reject_reason_;
    }

    /**
     * @return the auth_name_
     */
    public String getAuth_name_() {
        return auth_name_;
    }

    /**
     * @param auth_name_ the auth_name_ to set
     */
    public void setAuth_name_(String auth_name_) {
        this.auth_name_ = auth_name_;
    }

    /**
     * @return the maker_role_
     */
    public String getMaker_role_() {
        return maker_role_;
    }

    /**
     * @param maker_role_ the maker_role_ to set
     */
    public void setMaker_role_(String maker_role_) {
        this.maker_role_ = maker_role_;
    }

}
