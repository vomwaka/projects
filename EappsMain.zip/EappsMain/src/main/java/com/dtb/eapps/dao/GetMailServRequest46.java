/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author Nzangi
 */
public class GetMailServRequest46 {

    private String inst_id_,
            pickup_location_,
            parcel_description_,
            destination_,
            destination_branch_,
            date_of_pickup_,
            app_id_,
            corp_id_,
            channel_type_;

    /**
     * @return the inst_id_
     */
    public String getInst_id_() {
        return inst_id_;
    }

    /**
     * @param inst_id_ the inst_id_ to set
     */
    public void setInst_id_(String inst_id_) {
        this.inst_id_ = inst_id_;
    }

    /**
     * @return the pickup_location_
     */
    public String getPickup_location_() {
        return pickup_location_;
    }

    /**
     * @param pickup_location_ the pickup_location_ to set
     */
    public void setPickup_location_(String pickup_location_) {
        this.pickup_location_ = pickup_location_;
    }

    /**
     * @return the parcel_description_
     */
    public String getParcel_description_() {
        return parcel_description_;
    }

    /**
     * @param parcel_description_ the parcel_description_ to set
     */
    public void setParcel_description_(String parcel_description_) {
        this.parcel_description_ = parcel_description_;
    }

    /**
     * @return the destination_
     */
    public String getDestination_() {
        return destination_;
    }

    /**
     * @param destination_ the destination_ to set
     */
    public void setDestination_(String destination_) {
        this.destination_ = destination_;
    }

    /**
     * @return the destination_branch_
     */
    public String getDestination_branch_() {
        return destination_branch_;
    }

    /**
     * @param destination_branch_ the destination_branch_ to set
     */
    public void setDestination_branch_(String destination_branch_) {
        this.destination_branch_ = destination_branch_;
    }

    /**
     * @return the date_of_pickup_
     */
    public String getDate_of_pickup_() {
        return date_of_pickup_;
    }

    /**
     * @param date_of_pickup_ the date_of_pickup_ to set
     */
    public void setDate_of_pickup_(String date_of_pickup_) {
        this.date_of_pickup_ = date_of_pickup_;
    }

    /**
     * @return the app_id_
     */
    public String getApp_id_() {
        return app_id_;
    }

    /**
     * @param app_id_ the app_id_ to set
     */
    public void setApp_id_(String app_id_) {
        this.app_id_ = app_id_;
    }

    /**
     * @return the corp_id_
     */
    public String getCorp_id_() {
        return corp_id_;
    }

    /**
     * @param corp_id_ the corp_id_ to set
     */
    public void setCorp_id_(String corp_id_) {
        this.corp_id_ = corp_id_;
    }

    /**
     * @return the channel_type_
     */
    public String getChannel_type_() {
        return channel_type_;
    }

    /**
     * @param channel_type_ the channel_type_ to set
     */
    public void setChannel_type_(String channel_type_) {
        this.channel_type_ = channel_type_;
    }
}
