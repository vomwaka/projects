/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nzangi
 */
public class GetBenificiaryListRequest56 {

    List<List> lHolder = new ArrayList<>();
    private String nick_name_,
            benificiary_id_,
            acc_no_,
            branch_,
            group_name_,
            group_id_,
            inst_id_,
            inst_desc_,
            priority_,
            visibility_,
            status_,
            name_,
            benifi_bank_name_,
            branch_code_,
            swift_code_,
            email_add_,
            phone_no_,
            staff_number_;

    /**
     * @return the nick_name_
     */
    public String getNick_name_() {
        return nick_name_;
    }

    /**
     * @param nick_name_ the nick_name_ to set
     */
    public void setNick_name_(String nick_name_, List<String> list, int t) {
        this.nick_name_ = nick_name_;
        list.add(this.nick_name_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the benificiary_id_
     */
    public String getBenificiary_id_() {
        return benificiary_id_;
    }

    /**
     * @param benificiary_id_ the benificiary_id_ to set
     */
    public void setBenificiary_id_(String benificiary_id_, List<String> list, int t) {
        this.benificiary_id_ = benificiary_id_;
        list.add(this.benificiary_id_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the acc_no_
     */
    public String getAcc_no_() {
        return acc_no_;
    }

    /**
     * @param acc_no_ the acc_no_ to set
     */
    public void setAcc_no_(String acc_no_, List<String> list, int t) {
        this.acc_no_ = acc_no_;
        list.add(this.acc_no_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the branch_
     */
    public String getBranch_() {
        return branch_;
    }

    /**
     * @param branch_ the branch_ to set
     */
    public void setBranch_(String branch_, List<String> list, int t) {
        this.branch_ = branch_;
        list.add(this.branch_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the group_name_
     */
    public String getGroup_name_() {
        return group_name_;
    }

    /**
     * @param group_name_ the group_name_ to set
     */
    public void setGroup_name_(String group_name_, List<String> list, int t) {
        this.group_name_ = group_name_;
        list.add(this.group_name_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the group_id_
     */
    public String getGroup_id_() {
        return group_id_;
    }

    /**
     * @param group_id_ the group_id_ to set
     */
    public void setGroup_id_(String group_id_, List<String> list, int t) {
        this.group_id_ = group_id_;
        list.add(this.group_id_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the inst_id_
     */
    public String getInst_id_() {
        return inst_id_;
    }

    /**
     * @param inst_id_ the inst_id_ to set
     */
    public void setInst_id_(String inst_id_, List<String> list, int t) {
        this.inst_id_ = inst_id_;
        list.add(this.inst_id_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the inst_desc_
     */
    public String getInst_desc_() {
        return inst_desc_;
    }

    /**
     * @param inst_desc_ the inst_desc_ to set
     */
    public void setInst_desc_(String inst_desc_, List<String> list, int t) {
        this.inst_desc_ = inst_desc_;
        list.add(this.inst_desc_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the priority_
     */
    public String getPriority_() {
        return priority_;
    }

    /**
     * @param priority_ the priority_ to set
     */
    public void setPriority_(String priority_, List<String> list, int t) {
        this.priority_ = priority_;
        list.add(this.priority_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the visibility_
     */
    public String getVisibility_() {
        return visibility_;
    }

    /**
     * @param visibility_ the visibility_ to set
     */
    public void setVisibility_(String visibility_, List<String> list, int t) {
        this.visibility_ = visibility_;
        list.add(this.visibility_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the status_
     */
    public String getStatus_() {
        return status_;
    }

    /**
     * @param status_ the status_ to set
     */
    public void setStatus_(String status_, List<String> list, int t) {
        this.status_ = status_;
        list.add(this.status_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the name_
     */
    public String getName_() {
        return name_;
    }

    /**
     * @param name_ the name_ to set
     */
    public void setName_(String name_, List<String> list, int t) {
        this.name_ = name_;
        list.add(this.name_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the benifi_bank_name_
     */
    public String getBenifi_bank_name_() {
        return benifi_bank_name_;
    }

    /**
     * @param benifi_bank_name_ the benifi_bank_name_ to set
     */
    public void setBenifi_bank_name_(String benifi_bank_name_, List<String> list, int t) {
        this.benifi_bank_name_ = benifi_bank_name_;
        list.add(this.benifi_bank_name_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the branch_code_
     */
    public String getBranch_code_() {
        return branch_code_;
    }

    /**
     * @param branch_code_ the branch_code_ to set
     */
    public void setBranch_code_(String branch_code_, List<String> list, int t) {
        this.branch_code_ = branch_code_;
        list.add(this.branch_code_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the swift_code_
     */
    public String getSwift_code_() {
        return swift_code_;
    }

    /**
     * @param swift_code_ the swift_code_ to set
     */
    public void setSwift_code_(String swift_code_, List<String> list, int t) {
        this.swift_code_ = swift_code_;
        list.add(this.swift_code_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the email_add_
     */
    public String getEmail_add_() {
        return email_add_;
    }

    /**
     * @param email_add_ the email_add_ to set
     */
    public void setEmail_add_(String email_add_, List<String> list, int t) {
        this.email_add_ = email_add_;
        list.add(this.email_add_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the phone_no_
     */
    public String getPhone_no_() {
        return phone_no_;
    }

    /**
     * @param phone_no_ the phone_no_ to set
     */
    public void setPhone_no_(String phone_no_, List<String> list, int t) {
        this.phone_no_ = phone_no_;
        list.add(this.phone_no_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the staff_number_
     */
    public String getStaff_number_() {
        return staff_number_;
    }

    /**
     * @param staff_number_ the staff_number_ to set
     */
    public void setStaff_number_(String staff_number_, List<String> list, int t) {
        this.staff_number_ = staff_number_;
        list.add(this.staff_number_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    public List<List> listHolder(List<String> list) {
        lHolder.add(list);
        return lHolder;
    }

}
