/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.servlets.corporate.web;

import java.io.FileReader;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author Nzangi
 */
public class JsonObject {

    public JSONObject jsonObj(String resp) {
        try {
            JSONParser parser = new JSONParser();
//            Object obj = parser.parse(resp);
            Object obj = parser.parse(new FileReader(resp));
            JSONObject jsonObject = (JSONObject) obj;
            return jsonObject;
        } catch (Exception ex) {
            System.out.println("Error in creating json object.....\n" + ex.toString());
        }
        return null;
    }
    public JSONObject jsonObj2(String resp) {
        try {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
//            Object obj = parser.parse(new FileReader(resp));
            JSONObject jsonObject = (JSONObject) obj;
            return jsonObject;
        } catch (Exception ex) {
            System.out.println("Error in creating json object.....\n" + ex.toString());
        }
        return null;
    }
    public JSONArray parseJsonArray(String file, String key) {
        try {
            JSONParser parser1 = new JSONParser();
//            Object obj1 = parser1.parse(file);
            Object obj1 = parser1.parse(new FileReader(file));
            JSONObject jsonObject = (JSONObject) obj1;
            JSONArray arr = (JSONArray) jsonObject.get(key);

            return arr;
        } catch (Exception ex) {
            System.out.println("Error in creating json object************************************8\n" 
                    + ex.toString());

        }
        return null;
    }
    public JSONArray parseJsonArray2(String file, String key) {
        try {
            JSONParser parser1 = new JSONParser();
            Object obj1 = parser1.parse(file);
//            Object obj1 = parser1.parse(new FileReader(file));
            JSONObject jsonObject = (JSONObject) obj1;
            JSONArray arr = (JSONArray) jsonObject.get(key);

            return arr;
        } catch (Exception ex) {
            System.out.println("Error in creating json object************************************8\n" 
                    + ex.toString());

        }
        return null;
    }
}
