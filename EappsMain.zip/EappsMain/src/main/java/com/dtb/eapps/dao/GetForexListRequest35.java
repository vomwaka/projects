/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nzangi
 */
public class GetForexListRequest35 {

    private String inst_id_,
            forex_amount_,
            currency_,
            charges_,
            booking_id_,
            booking_date_,
            status_,
            auth_status_,
            user_id_,
            corp_id_,
            auth_desc_,
            reject_reason_;
    List<List>l=new ArrayList<>();

    /**
     * @return the inst_id_
     */
    public String getInst_id_() {
        return inst_id_;
    }

    /**
     * @param inst_id_ the inst_id_ to set
     */
    public void setInst_id_(String inst_id_, int size, List<String> list) {
        this.inst_id_ = inst_id_;
        list.add(this.inst_id_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the forex_amount_
     */
    public String getForex_amount_() {
        return forex_amount_;
    }

    /**
     * @param forex_amount_ the forex_amount_ to set
     */
    public void setForex_amount_(String forex_amount_, int size, List<String> list) {
        this.forex_amount_ = forex_amount_;
        list.add(this.forex_amount_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the currency_
     */
    public String getCurrency_() {
        return currency_;
    }

    /**
     * @param currency_ the currency_ to set
     */
    public void setCurrency_(String currency_, int size, List<String> list) {
        this.currency_ = currency_;
        list.add(this.currency_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the charges_
     */
    public String getCharges_() {
        return charges_;
    }

    /**
     * @param charges_ the charges_ to set
     */
    public void setCharges_(String charges_, int size, List<String> list) {
        this.charges_ = charges_;
        list.add(this.charges_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the booking_id_
     */
    public String getBooking_id_() {
        return booking_id_;
    }

    /**
     * @param booking_id_ the booking_id_ to set
     */
    public void setBooking_id_(String booking_id_, int size, List<String> list) {
        this.booking_id_ = booking_id_;
        list.add(this.booking_id_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the booking_date_
     */
    public String getBooking_date_() {
        return booking_date_;
    }

    /**
     * @param booking_date_ the booking_date_ to set
     */
    public void setBooking_date_(String booking_date_, int size, List<String> list) {
        this.booking_date_ = booking_date_;
        list.add(this.booking_date_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the status_
     */
    public String getStatus_() {
        return status_;
    }

    /**
     * @param status_ the status_ to set
     */
    public void setStatus_(String status_, int size, List<String> list) {
        this.status_ = status_;
        list.add(this.status_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the auth_status_
     */
    public String getAuth_status_() {
        return auth_status_;
    }

    /**
     * @param auth_status_ the auth_status_ to set
     */
    public void setAuth_status_(String auth_status_, int size, List<String> list) {
        this.auth_status_ = auth_status_;
        list.add(this.auth_status_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the user_id_
     */
    public String getUser_id_() {
        return user_id_;
    }

    /**
     * @param user_id_ the user_id_ to set
     */
    public void setUser_id_(String user_id_, int size, List<String> list) {
        this.user_id_ = user_id_;
        list.add(this.user_id_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the corp_id_
     */
    public String getCorp_id_() {
        return corp_id_;
    }

    /**
     * @param corp_id_ the corp_id_ to set
     */
    public void setCorp_id_(String corp_id_, int size, List<String> list) {
        this.corp_id_ = corp_id_;
        list.add(this.corp_id_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the auth_desc_
     */
    public String getAuth_desc_() {
        return auth_desc_;
    }

    /**
     * @param auth_desc_ the auth_desc_ to set
     */
    public void setAuth_desc_(String auth_desc_, int size, List<String> list) {
        this.auth_desc_ = auth_desc_;
        list.add(this.auth_desc_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    /**
     * @return the reject_reason_
     */
    public String getReject_reason_() {
        return reject_reason_;
    }

    /**
     * @param reject_reason_ the reject_reason_ to set
     */
    public void setReject_reason_(String reject_reason_, int size, List<String> list) {
        this.reject_reason_ = reject_reason_;
        list.add(this.reject_reason_ );
        if(list.size()==size){
            addToMainList(list);
        }
    }

    private void addToMainList(List<String> list) {
        l.add(list);    
    }
    public List<List> getMainlst(){
        return l;
    }
}
