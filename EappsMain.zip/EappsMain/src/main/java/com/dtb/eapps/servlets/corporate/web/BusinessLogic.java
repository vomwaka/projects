package com.dtb.eapps.servlets.corporate.web;

import com.dtb.eapps.dao.*;
import com.dtb.eapps.endpoint.CorporateEndPoint;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author Sam Kyalo
 */
public class BusinessLogic {

    private final String USER_AGENT = "Mozilla/5.0";
    JsonObjectParser jsonOb;
    static GetForexListRequest35 getForexListRequest35;
    static CorpMyAccountsListRequest41 corpMyAccountsListRequest41;

    /**
     * 1
     */
    /*Post to INITIATE SESSION Request*/
    public void is(HttpServletRequest request, HttpServletResponse response) {

        String application_id = "eapps_core";
        String channel_type = "corporate";
        String device_sub_type = "centos";
        String device_type = "centos";
        String device_address = "127.0.0.1";
        String device_model = "pc";

        JSONObject application_info = new JSONObject();
        application_info.put("application_id", application_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", "initiate_session");
        req_info.put("channel_type", channel_type);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();

        finalJsonObj.put("application_info", application_info);
        finalJsonObj.put("device_info", device_info);
        finalJsonObj.put("req_info", req_info);

        System.out.println("INITIATE SESSION 3435 - Gson Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());

            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            String session_id = (String) response_info.get("session_id");

            HttpSession session = request.getSession();
            session.setAttribute("session_id", session_id);

            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            System.out.println("Response JSON: " + resp);
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 2
     */
    /*Post to ADD CORP SELF REG Request*/
    //addCorpSelfReg
    public void acsr(HttpServletRequest request, HttpServletResponse response) {

        String channel_type = "corporate";
        String user_name = request.getParameter("username");
        String email_id = "googcsdle@gmaigffbfl.com";
        String uniq_id = "1234567c48fhfdhf90";
        String mob_no = "675849403c52sfbfgfh2";
        String module_name = "corp";
        String inst_id = "DTB";
        String session_id = "CORPWEB1234";
        String device_sub_type = "mozila";
        String device_type = "web";
        String device_address = "127.0.0.1";
        String device_model = "pc";

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", "add_corp_self_reg");
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("user_name", user_name);
        corp_kyc_info.put("email_id", email_id);
        corp_kyc_info.put("uniq_id", uniq_id);
        corp_kyc_info.put("mob_no", mob_no);
        corp_kyc_info.put("module_name", module_name);
        corp_kyc_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORP SELF REG - Gson Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());

//            JSONParser parser = new JSONParser();
//            Object obj = parser.parse(resp);
//            JSONObject jsonObject = (JSONObject) obj;
            JSONObject jsonObject = (new JsonObjectParser()).jsonObj(resp);
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            JSONObject user_info = (JSONObject) jsonObject.get("user_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");
            System.out.println("Response Code: " + resp);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    String app_id = (String) user_info.get("app_id");
                    String user_pwd = (String) user_info.get("user_pwd");

                    AddCorpSelfReg addCorpSelfReg = new AddCorpSelfReg();
                    addCorpSelfReg.setApp_id(app_id);
                    addCorpSelfReg.setUser_pwd(user_pwd);

                    request.setAttribute("add_corp_self_reg", addCorpSelfReg);
                    RequestDispatcher view = request.getRequestDispatcher("/Eapps/Corporate/dash_board.jsp");
                    view.forward(request, response);

                    //response.sendRedirect("/Eapps/Corporate/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
                //request.getRequestDispatcher("/Eapps/Corporate/index.jsp").include(request, response);  
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            System.out.println("Response JSON: " + resp);
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 3
     */
    /*Post to AUTH CORPORATE SELF REG Request*/
    //authCorpSelfReg
    protected void aucsr(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "auth_corp_self_reg";
        String channel_type = request.getParameter("user_pwd");
        String user_pwd = request.getParameter("user_pwd");
        String user_name = request.getParameter("user_name");
        String email_id = request.getParameter("email_id");
        String uniq_id = request.getParameter("uniq_id");
        String mob_no = request.getParameter("mob_no");
        String inst_id = request.getParameter("inst_id");
        String session_id = "CORPWEB1234";
        String device_sub_type = "mozilla";
        String device_type = "web";
        String device_address = "127.0.0.1";
        String device_model = "pc";

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("app_id", email_id);
        corp_kyc_info.put("auth_status", uniq_id);
        corp_kyc_info.put("auth_desc", mob_no);
        corp_kyc_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("AUTH CORPORATE SELF REG - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");
            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {
                    response.sendRedirect("/Eapps/Corporate/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
                //request.getRequestDispatcher("/Eapps/Corporate/index.jsp").include(request, response);  
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 4
     */
    /*Post to GET CORPORATE SELF REG Request*/
    // getCorpSelfReg
    protected void gcsr(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "get_corp_self_reg";
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String app_id = request.getParameter("app_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("inst_id", inst_id);
        corp_kyc_info.put("app_id", app_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET CORPORATE SELF REG - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONArray jsonarray = (JSONArray) jsonObject.get("get_self_reg");
                    Iterator<JSONObject> iterator = jsonarray.iterator();

                    String app_id_resp = null;
                    String inst_id_resp = null;
                    String module_name_resp = null;
                    String user_name_resp = null;
                    String user_pwd_resp = null;
                    String uniq_id_resp = null;
                    String email_id_resp = null;
                    String mob_no_resp = null;
                    String status_resp = null;
                    String auth_desc_resp = null;
                    String user_id_resp = null;
                    String auth_status_resp = null;

                    while (iterator.hasNext()) {
                        JSONObject respObj = (JSONObject) iterator.next();
                        inst_id_resp = (String) respObj.get("inst_id");
                        app_id_resp = (String) respObj.get("app_id");
                        module_name_resp = (String) respObj.get("module_name");
                        user_name_resp = (String) respObj.get("user_name");
                        user_pwd_resp = (String) respObj.get("user_pwd");
                        uniq_id_resp = (String) respObj.get("uniq_id");
                        email_id_resp = (String) respObj.get("email_id");
                        mob_no_resp = (String) respObj.get("mob_no");
                        status_resp = (String) respObj.get("status");
                        auth_desc_resp = (String) respObj.get("auth_desc");
                        user_id_resp = (String) respObj.get("user_id");
                        auth_status_resp = (String) respObj.get("auth_status");

                    }

                    GetCorpSelfReg getCorpSelfReg = new GetCorpSelfReg();
                    getCorpSelfReg.setApp_id(app_id_resp);
                    getCorpSelfReg.setUser_pwd(user_pwd_resp);
                    getCorpSelfReg.setInst_id(inst_id_resp);
                    getCorpSelfReg.setModule_name(module_name_resp);
                    getCorpSelfReg.setUser_name(user_name_resp);
                    getCorpSelfReg.setUniq_id(uniq_id_resp);
                    getCorpSelfReg.setEmail_id(email_id_resp);
                    getCorpSelfReg.setMob_no(mob_no_resp);
                    getCorpSelfReg.setStatus(status_resp);
                    getCorpSelfReg.setAuth_desc(auth_desc_resp);
                    getCorpSelfReg.setUser_id(user_id_resp);
                    getCorpSelfReg.setAuth_status(auth_status_resp);

                    request.setAttribute("get_corp_self_reg", getCorpSelfReg);
                    // RequestDispatcher view = request.getRequestDispatcher("/Eapps/Corporate/dash_board.jsp");
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard_dummy.jsp");
                    view.forward(request, response);

                    // response.sendRedirect("/Eapps/Corporate/dashboard_dummy.jsp");
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
                //request.getRequestDispatcher("/Eapps/Corporate/index.jsp").include(request, response);  
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 5
     */
    /*Post to GET CORPORATE SELF REG LIST Request*/
    //getCorporateSelfRegListRequest
    protected void gcsrl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET CORPORATE SELF REG LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");
            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {
                    response.sendRedirect("/Eapps/Corporate/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
                //request.getRequestDispatcher("/Eapps/Corporate/index.jsp").include(request, response);  
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 6
     */
    /*Post to TEMP CORPORATE LOGIN Request*/
    //tempCorporateLogin
    public void tcl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println(request.getLocalAddr());

        String req_type = "corp_reg_login";
        String channel_type = "corporate";
        String user_name = request.getParameter("username");
        String user_pwd = request.getParameter("password");

        String session_id = "CORPWEB1234";
        String device_sub_type = "centos";
        String device_type = "web";
        String device_address = "127.0.0.1";
        String device_model = "pc";

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("TEMP CORPORATE LOGIN - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            String resp = sendRequest(finalJsonObj.toJSONString());
            System.out.println("Response - Json Data : " + resp);
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");
            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {
                    response.sendRedirect("/Eapps/Corporate/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
                //request.getRequestDispatcher("/Eapps/Corporate/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            e.printStackTrace();

        }

    }

    /**
     * 7
     */
    /*Post to ADD CORPORATE KYC Request*/
    //addCorporateKYCRequest
    protected void ackyc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String module_name = request.getParameter("module_name");
        String corp_name = request.getParameter("corp_name");
        String corp_reg_no = request.getParameter("corp_reg_no");
        String corp_addr = request.getParameter("corp_addr");
        String corp_branch = request.getParameter("corp_branch");
        String corp_reg = request.getParameter("corp_reg");
        String industry = request.getParameter("industry");
        String corp_logo = request.getParameter("corp_logo");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("inst_id", inst_id);
        corp_kyc_info.put("module_name", module_name);
        corp_kyc_info.put("corp_name", corp_name);
        corp_kyc_info.put("corp_reg_no", corp_reg_no);
        corp_kyc_info.put("corp_addr", corp_addr);
        corp_kyc_info.put("corp_branch", corp_branch);
        corp_kyc_info.put("corp_reg", corp_reg);
        corp_kyc_info.put("industry", industry);
        corp_kyc_info.put("corp_logo", corp_logo);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 8
     */
    /*Post to UPDATE CORPORATE KYC Request*/
    //updateCorporateKYCRequest
    protected void uckyc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String phy_addr = request.getParameter("phy_addr");
        String postal_addr = request.getParameter("postal_addr");
        String postal_code = request.getParameter("postal_code");
        String official_phone_no = request.getParameter("official_phone_no");
        String official_mob_no = request.getParameter("official_mob_no");
        String official_email_id = request.getParameter("official_email_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("phy_addr", phy_addr);
        corp_kyc_info.put("postal_addr", postal_addr);
        corp_kyc_info.put("postal_code", postal_code);
        corp_kyc_info.put("official_phone_no", official_phone_no);
        corp_kyc_info.put("official_mob_no", official_mob_no);
        corp_kyc_info.put("official_email_id", official_email_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("UPDATE CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 9
     */
    /*Post to GET CORPORATE KYC Request*/
    //getCorporateKYCRequest
    protected void gckyc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("req_type");
        String user_name = request.getParameter("req_type");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");;
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String application_id = request.getParameter("application_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("inst_id", inst_id);
        corp_kyc_info.put("application_id", application_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONArray jsonarray = (JSONArray) jsonObject.get("s_get_corp_kyc");
                    Iterator<JSONObject> iterator = jsonarray.iterator();

                    String inst_id_resp = null;
                    String application_id_resp = null;
                    String module_name_resp = null;
                    String corp_name_resp = null;
                    String corp_reg_no_resp = null;
                    String corp_addr_resp = null;
                    String corp_branch_resp = null;
                    String corp_reg_resp = null;
                    String industry_resp = null;
                    String corp_logo_resp = null;
                    String phy_addr_resp = null;
                    String postal_addr_resp = null;
                    String postal_code_resp = null;
                    String official_mob_no_resp = null;
                    String official_phone_no_resp = null;
                    String official_email_id_resp = null;
                    String auth_status_resp = null;
                    String auth_desc_resp = null;
                    String reject_reason_resp = null;
                    String status_resp = null;

                    while (iterator.hasNext()) {
                        JSONObject respObj = (JSONObject) iterator.next();
                        inst_id_resp = (String) respObj.get("inst_id");
                        application_id_resp = (String) respObj.get("application_id");
                        module_name_resp = (String) respObj.get("module_name");
                        corp_name_resp = (String) respObj.get("corp_name");
                        corp_reg_no_resp = (String) respObj.get("corp_reg_no");
                        corp_addr_resp = (String) respObj.get("corp_addr");
                        corp_branch_resp = (String) respObj.get("corp_branch");
                        corp_reg_resp = (String) respObj.get("corp_reg");
                        status_resp = (String) respObj.get("status");
                        auth_desc_resp = (String) respObj.get("auth_desc");
                        industry_resp = (String) respObj.get("industry");
                        auth_status_resp = (String) respObj.get("auth_status");
                        reject_reason_resp = (String) respObj.get("reject_reason");
                        official_email_id_resp = (String) respObj.get("official_email_id");
                        official_phone_no_resp = (String) respObj.get("official_phone_no");
                        official_mob_no_resp = (String) respObj.get("official_mob_no");
                        postal_code_resp = (String) respObj.get("postal_code");
                        postal_addr_resp = (String) respObj.get("postal_addr");
                        phy_addr_resp = (String) respObj.get("phy_addr");
                        corp_logo_resp = (String) respObj.get("corp_logo");

                    }

                    /**
                     * if (inst_id_resp != null || application_id_resp != null
                     * || module_name_resp != null || corp_name_resp != null) {
                     * }
                     *
                     */
                    GetCorpKYC getCorpKYC = new GetCorpKYC();
                    getCorpKYC.setApplication_id(application_id_resp);
                    getCorpKYC.setCorp_name(corp_name_resp);
                    getCorpKYC.setInst_id(inst_id_resp);
                    getCorpKYC.setModule_name(module_name_resp);
                    getCorpKYC.setCorp_reg_no(corp_reg_no_resp);
                    getCorpKYC.setCorp_addr(corp_addr_resp);
                    getCorpKYC.setCorp_branch(corp_branch_resp);
                    getCorpKYC.setCorp_reg(corp_reg_resp);
                    getCorpKYC.setStatus(status_resp);
                    getCorpKYC.setAuth_desc(auth_desc_resp);
                    getCorpKYC.setIndustry(industry_resp);
                    getCorpKYC.setAuth_status(auth_status_resp);
                    getCorpKYC.setCorp_logo(corp_logo_resp);
                    getCorpKYC.setPhy_addr(phy_addr_resp);
                    getCorpKYC.setPostal_addr(postal_addr_resp);
                    getCorpKYC.setPostal_code(postal_code_resp);
                    getCorpKYC.setOfficial_mob_no(official_mob_no_resp);
                    getCorpKYC.setOfficial_phone_no(official_phone_no_resp);
                    getCorpKYC.setOfficial_email_id(official_email_id_resp);
                    getCorpKYC.setReject_reason(reject_reason_resp);

                    request.setAttribute("s_get_corp_kyc", getCorpKYC);
                    // RequestDispatcher view = request.getRequestDispatcher("/Eapps/Corporate/dash_board.jsp");
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard_dummy.jsp");
                    view.forward(request, response);

                    // response.sendRedirect("/Eapps/Corporate/dashboard_dummy.jsp");
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
                //request.getRequestDispatcher("/Eapps/Corporate/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 10
     */
    /*Post to GET CORPORATE KYC LIST Request*/
    //getCorporateKYCListRequest
    protected void gckycl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET CORPORATE KYC LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONArray jsonarray = (JSONArray) jsonObject.get("s_get_corp_kyc");
                    Iterator<JSONObject> iterator = jsonarray.iterator();

                    String inst_id_resp = null;
                    String application_id_resp = null;
                    String module_name_resp = null;
                    String corp_name_resp = null;
                    String corp_reg_no_resp = null;
                    String corp_addr_resp = null;
                    String corp_branch_resp = null;
                    String corp_reg_resp = null;
                    String industry_resp = null;
                    String corp_logo_resp = null;
                    String phy_addr_resp = null;
                    String postal_addr_resp = null;
                    String postal_code_resp = null;
                    String official_mob_no_resp = null;
                    String official_phone_no_resp = null;
                    String official_email_id_resp = null;
                    String auth_status_resp = null;
                    String auth_desc_resp = null;
                    String reject_reason_resp = null;
                    String status_resp = null;

                    while (iterator.hasNext()) {
                        JSONObject respObj = (JSONObject) iterator.next();
                        inst_id_resp = (String) respObj.get("inst_id");
                        application_id_resp = (String) respObj.get("application_id");
                        module_name_resp = (String) respObj.get("module_name");
                        corp_name_resp = (String) respObj.get("corp_name");
                        corp_reg_no_resp = (String) respObj.get("corp_reg_no");
                        corp_addr_resp = (String) respObj.get("corp_addr");
                        corp_branch_resp = (String) respObj.get("corp_branch");
                        corp_reg_resp = (String) respObj.get("corp_reg");
                        status_resp = (String) respObj.get("status");
                        auth_desc_resp = (String) respObj.get("auth_desc");
                        industry_resp = (String) respObj.get("industry");
                        auth_status_resp = (String) respObj.get("auth_status");
                        reject_reason_resp = (String) respObj.get("reject_reason");
                        official_email_id_resp = (String) respObj.get("official_email_id");
                        official_phone_no_resp = (String) respObj.get("official_phone_no");
                        official_mob_no_resp = (String) respObj.get("official_mob_no");
                        postal_code_resp = (String) respObj.get("postal_code");
                        postal_addr_resp = (String) respObj.get("postal_addr");
                        phy_addr_resp = (String) respObj.get("phy_addr");
                        corp_logo_resp = (String) respObj.get("corp_logo");

                    }

                    /**
                     * if (inst_id_resp != null || application_id_resp != null
                     * || module_name_resp != null || corp_name_resp != null) {
                     * }
                     *
                     */
                    GetCorpKYCList getCorpKYCList = new GetCorpKYCList();
                    getCorpKYCList.setApplication_id(application_id_resp);
                    getCorpKYCList.setCorp_name(corp_name_resp);
                    getCorpKYCList.setInst_id(inst_id_resp);
                    getCorpKYCList.setModule_name(module_name_resp);
                    getCorpKYCList.setCorp_reg_no(corp_reg_no_resp);
                    getCorpKYCList.setCorp_addr(corp_addr_resp);
                    getCorpKYCList.setCorp_branch(corp_branch_resp);
                    getCorpKYCList.setCorp_reg(corp_reg_resp);
                    getCorpKYCList.setStatus(status_resp);
                    getCorpKYCList.setAuth_desc(auth_desc_resp);
                    getCorpKYCList.setIndustry(industry_resp);
                    getCorpKYCList.setAuth_status(auth_status_resp);
                    getCorpKYCList.setCorp_logo(corp_logo_resp);
                    getCorpKYCList.setPhy_addr(phy_addr_resp);
                    getCorpKYCList.setPostal_addr(postal_addr_resp);
                    getCorpKYCList.setPostal_code(postal_code_resp);
                    getCorpKYCList.setOfficial_mob_no(official_mob_no_resp);
                    getCorpKYCList.setOfficial_phone_no(official_phone_no_resp);
                    getCorpKYCList.setOfficial_email_id(official_email_id_resp);
                    getCorpKYCList.setReject_reason(reject_reason_resp);

                    request.setAttribute("s_get_corp_kyc", getCorpKYCList);
                    // RequestDispatcher view = request.getRequestDispatcher("/Eapps/Corporate/dash_board.jsp");
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard_dummy.jsp");
                    view.forward(request, response);

                    // response.sendRedirect("/Eapps/Corporate/dashboard_dummy.jsp");
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
                //request.getRequestDispatcher("/Eapps/Corporate/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 11
     */
    /*Post to ADD CORPORATE CONTACT KYC Request*/
    //addCorporateContactKYCRequest
    protected void acckyc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String staff_number = request.getParameter("staff_number");
        String id_number = request.getParameter("id_number");
        String phone_number = request.getParameter("phone_number");
        String mobile_number = request.getParameter("mobile_number");
        String email_address = request.getParameter("email_address");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("inst_id", inst_id);
        corp_kyc_info.put("user_name", user_name);
        corp_kyc_info.put("staff_number", staff_number);
        corp_kyc_info.put("id_number", id_number);
        corp_kyc_info.put("phone_number", phone_number);
        corp_kyc_info.put("mobile_number", mobile_number);
        corp_kyc_info.put("email_address", email_address);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORPORATE CONTACT KYC - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 12
     */
    /*Post to GET CORPORATE CONTACT Request*/
    //getCorporateContactRequest
    protected void gcc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String app_id = request.getParameter("app_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("inst_id", inst_id);
        corp_kyc_info.put("app_id", app_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET CORPORATE CONTACT - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 13
     */
    /*Post to GET CORPORATE CONTACT LIST Request*/
    //getCorporateContactListRequest
    protected void gccl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("req_type");
        String session_id = request.getParameter("req_type");
        String device_sub_type = request.getParameter("req_type");
        String device_type = request.getParameter("req_type");
        String device_address = request.getParameter("req_type");
        String device_model = request.getParameter("req_type");
        String user_pwd = request.getParameter("req_type");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_info = new JSONObject();
        corp_kyc_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET CORPORATE CONTACT LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 14
     */
    /*Post to ADD CORPORATE KYC PRODUCTS Request*/
    //addCorporateKYCProductsRequest 
    protected void ackycp(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd ");
        String entity_type = request.getParameter("entity_type");
        String rel_id = request.getParameter("rel_id");
        String rel_id_desc = request.getParameter("rel_id_desc");
        String rel_type = request.getParameter("rel_type");
        String rel_sub_type = request.getParameter("rel_sub_type");
        String rel_branch_code = request.getParameter("rel_branch_code");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_prod_info = new JSONObject();
        corp_kyc_prod_info.put("inst_id", inst_id);
        corp_kyc_prod_info.put("entity_type", entity_type);
        corp_kyc_prod_info.put("rel_id", rel_id);
        corp_kyc_prod_info.put("rel_id_desc", rel_id_desc);
        corp_kyc_prod_info.put("rel_type", rel_type);
        corp_kyc_prod_info.put("rel_sub_type", rel_sub_type);
        corp_kyc_prod_info.put("rel_branch_code", rel_branch_code);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORPORATE KYC PRODUCTS - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 15
     */
    /*Post to ADD CORPORATE KYC USER Request*/
    //addCorporateKYCUserRequest
    protected void ackycu(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "add_corp_kyc_role";
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String staff_number = request.getParameter("staff_number");
        String passport_number = request.getParameter("passport_number");
        String official_phone_no = request.getParameter("official_phone_no");
        String official_mob_no = request.getParameter("official_mob_no");
        String official_email_id = request.getParameter("official_email_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_role_info = new JSONObject();
        corp_kyc_role_info.put("inst_id", inst_id);
        corp_kyc_role_info.put("user_name", user_name);
        corp_kyc_role_info.put("staff_number", staff_number);
        corp_kyc_role_info.put("passport_number", passport_number);
        corp_kyc_role_info.put("official_phone_no", official_phone_no);
        corp_kyc_role_info.put("official_mob_no", official_mob_no);
        corp_kyc_role_info.put("official_email_id", official_email_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_role_info", corp_kyc_role_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORPORATE KYC USER - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 16
     */
    /*Post to ADD CORPORATE USER ROLE Request*/
    //addCorporateUserRoleRequest
    protected void acur(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String module_name = request.getParameter("module_name");
        String rel_type = request.getParameter("rel_type");
        String rel_id = request.getParameter("rel_id");
        String rel_sub_type = request.getParameter("rel_sub_type");
        String rel_action = request.getParameter("rel_action");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_prod_info = new JSONObject();
        corp_kyc_prod_info.put("inst_id", inst_id);
        corp_kyc_prod_info.put("entity_id", module_name);

        JSONArray accountsArray = new JSONArray();

        try {
            for (int i = 0; i < 3; i++) {

                JSONObject account_items = new JSONObject();
                account_items.put("rel_type", rel_type + 1);
                account_items.put("rel_id", rel_id + 2);
                account_items.put("rel_sub_type", rel_sub_type + 3);
                account_items.put("rel_action", rel_action + 4);
                accountsArray.add(account_items);
            }
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        JSONObject account_list = new JSONObject();
        account_list.put("req_type", req_type);
        account_list.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORPORATE USER ROLE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000") && response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 17
     */
    /*Post to FIRST LEVEL OF AUTH Request*/
    //firstLevelOfAuthRequest
    protected void floau(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String app_id = request.getParameter("app_id");
        String auth_status = request.getParameter("auth_status");
        String auth_desc = request.getParameter("auth_desc");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject app_info = new JSONObject();
        app_info.put("app_id", app_id);
        app_info.put("auth_status", auth_status);
        app_info.put("auth_desc", auth_desc);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("app_info", app_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("FIRST LEVEL OF AUTH - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 18
     */
    /*Post to SECOND LEVEL OF AUTH Request*/
    //secondLevelOfAuthRequest
    protected void sloau(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String app_id = request.getParameter("app_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_info = new JSONObject();
        corp_info.put("inst_id", inst_id);
        corp_info.put("app_id", app_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 19
     */
    /*Post to ADD  CORP ADMIN USER Request*/
    //addCorpAdminUserRequest
    protected void acau(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String user_role = request.getParameter("user_role");
        String user_type = request.getParameter("user_type");
        String user_id = request.getParameter("user_id");
        String first_name = request.getParameter("first_name");
        String last_name = request.getParameter("last_name");
        String other_name = request.getParameter("other_name");
        String staff_number = request.getParameter("staff_number");
        String official_mob_number_1 = request.getParameter("official_mob_number_1");
        String official_mob_number_2 = request.getParameter("official_mob_number_2");
        String official_mail_1 = request.getParameter("official_mail_1");
        String official_mail_2 = request.getParameter("official_mail_2");
        String id_doc_1 = request.getParameter("id_doc_1");
        String id_doc_1_desc = request.getParameter("id_doc_1_desc");
        String id_doc_2 = request.getParameter("id_doc_2");
        String id_doc_2_desc = request.getParameter("id_doc_2_desc");
        String id_doc_3 = request.getParameter("id_doc_3");
        String id_doc_3_desc = request.getParameter("id_doc_3_desc");
        String id_doc_4 = request.getParameter("id_doc_4");
        String id_doc_4_desc = request.getParameter("id_doc_4_desc");
        String id_doc_5 = request.getParameter("id_doc_5");
        String id_doc_5_desc = request.getParameter("id_doc_5_desc");
        String phy_address = request.getParameter("phy_address");
        String postal_code = request.getParameter("postal_code");
        String gender = request.getParameter("gender");
        String dob = request.getParameter("dob");
        String country = request.getParameter("country");
        String postal_address = request.getParameter("postal_address");
        String pwd_retry_count = request.getParameter("pwd_retry_count");
        String kin_first_name = request.getParameter("kin_first_name");
        String kin_last_name = request.getParameter("kin_last_name");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject kyc_info = new JSONObject();
        kyc_info.put("user_role", user_role);
        kyc_info.put("user_type", user_type);
        kyc_info.put("user_id", user_id);
        kyc_info.put("first_name", first_name);
        kyc_info.put("last_name", last_name);
        kyc_info.put("other_name", other_name);
        kyc_info.put("staff_number", staff_number);
        kyc_info.put("official_mob_number_1", official_mob_number_1);
        kyc_info.put("official_mob_number_2", official_mob_number_2);
        kyc_info.put("official_mail_1", official_mail_1);
        kyc_info.put("official_mail_2", official_mail_2);
        kyc_info.put("id_doc_1", id_doc_1);
        kyc_info.put("id_doc_1_desc", id_doc_1_desc);
        kyc_info.put("id_doc_2", id_doc_2);
        kyc_info.put("id_doc_2_desc", id_doc_2_desc);
        kyc_info.put("id_doc_3", id_doc_3);
        kyc_info.put("id_doc_3_desc", id_doc_3_desc);
        kyc_info.put("id_doc_4", id_doc_4);
        kyc_info.put("id_doc_4_desc", id_doc_4_desc);
        kyc_info.put("id_doc_5", id_doc_5);
        kyc_info.put("id_doc_5_desc", id_doc_5_desc);
        kyc_info.put("phy_address", phy_address);
        kyc_info.put("postal_code", postal_code);
        kyc_info.put("gender", gender);
        kyc_info.put("dob", dob);
        kyc_info.put("country", country);
        kyc_info.put("postal_address", postal_address);
        kyc_info.put("pwd_retry_count", pwd_retry_count);
        kyc_info.put("inst_id", inst_id);
        kyc_info.put("kin_first_name", kin_first_name);
        kyc_info.put("kin_last_name", kin_last_name);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("kyc_info", kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD  CORP ADMIN USER - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 20
     */
    /*Post to AUTH CORP ADMIN USER Request*/
//        /authCorpAdminUserRequest
    protected void aucau(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String user_id = request.getParameter("user_id");
        String auth_status = request.getParameter("auth_status");
        String auth_desc = request.getParameter("auth_desc");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("user_id", user_id);
        req_info.put("auth_status", auth_status);
        req_info.put("auth_desc", auth_desc);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("AUTH CORP ADMIN USER - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 21
     */
    /*Post to CORPORATE LOGIN Request*/
    //corporateLoginRequest
    public void cl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "corp_user_login"; //request.getParameter("req_type");      
        String channel_type = "corporate"; //request.getParameter("channel_type");
        String user_name = "16244w000436"; //request.getParameter("user_name");            
        String inst_id = "DTB";//request.getParameter("inst_id");
        String session_id = "CORPWEB1234"; //request.getParameter("session_id");
        String device_sub_type = "mozilla"; //request.getParameter("device_sub_type");
        String device_type = "web"; //request.getParameter("device_type");
        String device_address = "127.0.0.1";//request.getParameter("device_address");
        String device_model = "pc";//request.getParameter("device_model");
        String user_pwd = "password"; //request.getParameter("user_pwd");
        String corp_id = "000025";// request.getParameter("corp_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("CORPORATE LOGIN - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            System.out.println(" JSON Response : " + resp);
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    String app_id = "1234567890";
                    String username = "0991sam";

                    AddCorpSelfReg addCorpSelfReg = new AddCorpSelfReg();
                    addCorpSelfReg.setApp_id(app_id);
                    addCorpSelfReg.setUser_pwd(username);
                    request.setAttribute("add_corp_self_reg", addCorpSelfReg);
                    // RequestDispatcher view = request.getRequestDispatcher("/Eapps/Corporate/dash_board.jsp");
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard_dummy.jsp");
                    view.forward(request, response);

                    // response.sendRedirect("/Eapps/Corporate/dashboard_dummy.jsp");
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
                //request.getRequestDispatcher("/Eapps/Corporate/index.jsp").include(request, response);  
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 22
     */
    /*Post to CORPORATE RELATIONSHIP Request*/
    //corporateRelationshipRequest
    protected void cr(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String inst_id = request.getParameter("session_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String eapps_corp_id = request.getParameter("eapps_corp_id");
        String entity_id = request.getParameter("entity_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_prod_info = new JSONObject();
        corp_kyc_prod_info.put("inst_id", inst_id);
        corp_kyc_prod_info.put("eapps_corp_id", eapps_corp_id);
        corp_kyc_prod_info.put("entity_id", entity_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("CORPORATE RELATIONSHIP - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 23
     */
    /*Post to GET CORP PROD Request*/
    //getCorporateProdRequest
    public void gcp(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_prod_info = new JSONObject();
        corp_kyc_prod_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET CORP PROD - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 24
     */
    /*Post to GET CORP PROD LIST Request*/
    //getCorporateProdListRequest
    protected void gcpl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_kyc_prod_info = new JSONObject();
        corp_kyc_prod_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET CORP PROD LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 25
     */
    /*Post to ADD LOAN INFO MAKER Request*/
    /**
     * protected void addLoanInfoMakerRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * try { * RequestDecoder decoder = new RequestDecoder(requestBody); String
     * [] decodedString = decoder.getDecodedString(); String req_type =
     * decodedString[1].trim(); String channel_type = decodedString[2].trim();
     * String user_name = decodedString[3].trim(); * String inst_id =
     * decodedString[4].trim(); String session_id = decodedString[5].trim();
     * String device_sub_type = decodedString[6].trim(); String device_type =
     * decodedString[7].trim(); String device_address = decodedString[8].trim();
     * String device_model = decodedString[9].trim(); String user_pwd =
     * decodedString[10].trim(); String module_name = decodedString[11].trim();
     * String corp_name = decodedString[12].trim(); String corp_reg_no =
     * decodedString[13].trim(); String corp_addr = decodedString[14].trim();
     * String corp_branch = decodedString[15].trim(); String corp_reg =
     * decodedString[16].trim(); String industry = decodedString[17].trim();
     * String corp_logo = decodedString[18].trim();
     *
     *
     *
     * JSONObject user_info = new JSONObject(); user_info.put("user_name",
     * user_name); user_info.put("user_pwd", user_pwd);
     *
     * JSONObject req_info = new JSONObject(); req_info.put("req_type",
     * req_type); req_info.put("channel_type", channel_type);
     *
     * JSONObject loan_info = new JSONObject(); loan_info.put("corp_id",
     * corp_id); loan_info.put("account", account);
     * loan_info.put("bank_tran_ser_period", bank_tran_ser_period);
     *
     * JSONObject corp_kyc_info = new JSONObject(); corp_kyc_info.put("inst_id",
     * inst_id); corp_kyc_info.put("module_name", module_name);
     * corp_kyc_info.put("corp_name", corp_name);
     * corp_kyc_info.put("corp_reg_no", corp_reg_no);
     * corp_kyc_info.put("corp_addr",corp_addr);
     * corp_kyc_info.put("corp_branch", corp_branch);
     * corp_kyc_info.put("corp_reg", corp_reg); corp_kyc_info.put("industry",
     * industry); corp_kyc_info.put("corp_logo", corp_logo);
     *
     *
     *
     *
     * JSONObject session_info = new JSONObject();
     * session_info.put("session_id", session_id);
     *
     * JSONObject device_info = new JSONObject();
     * device_info.put("device_sub_type", device_sub_type);
     * device_info.put("device_type", device_type);
     * device_info.put("device_address", device_address);
     * device_info.put("device_model", device_model);
     *
     * JSONObject finalJsonObj = new JSONObject();
     * finalJsonObj.put("user_info",user_info); finalJsonObj.put("req_info",
     * req_info); finalJsonObj.put("loan_info", loan_info);
     * finalJsonObj.put("corp_kyc_info",corp_kyc_info);
     * finalJsonObj.put("session_info",session_info);
     * finalJsonObj.put("device_info", device_info);
     *
     *
     * System.out.println("ADD LOAN INFO MAKER - Json Data : " +
     * finalJsonObj.toJSONString()); //Send the request to EappsCore for
     * Response try{ String resp=sendRequest(finalJsonObj.toJSONString());
     * PrintWriter out = response.getWriter(); /* TODO output your page here.
     * You may use following sample code.
     */
    /**
     * out.println(resp);
     *
     *
     * }catch(Exception e){ System.out.println("Send Request Error: " +
     * e.getMessage().toString());
     *
     * }
     *
     * }
     * catch (ArrayIndexOutOfBoundsException e) { System.out.println("Request
     * Parameter Error: Array is out of Bounds"+e); }
     *
     *
     * }
     *
     *
     *
     * /**26
     */
    /*Post to GET_LOAN_INFO Request*/
    /**
     * protected void getLoanInfoRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * try { * RequestDecoder decoder = new RequestDecoder(requestBody); String
     * [] decodedString = decoder.getDecodedString(); String req_type =
     * decodedString[1].trim(); String channel_type = decodedString[2].trim();
     * String user_name = decodedString[3].trim(); * String inst_id =
     * decodedString[4].trim(); String session_id = decodedString[5].trim();
     * String device_sub_type = decodedString[6].trim(); String device_type =
     * decodedString[7].trim(); String device_address = decodedString[8].trim();
     * String device_model = decodedString[9].trim(); String user_pwd =
     * decodedString[10].trim(); String module_name = decodedString[11].trim();
     * String corp_name = decodedString[12].trim(); String corp_reg_no =
     * decodedString[13].trim(); String corp_addr = decodedString[14].trim();
     * String corp_branch = decodedString[15].trim(); String corp_reg =
     * decodedString[16].trim(); String industry = decodedString[17].trim();
     * String corp_logo = decodedString[18].trim();
     *
     *
     *
     *
     *
     * JSONObject user_info = new JSONObject(); user_info.put("user_name",
     * user_name); user_info.put("user_pwd", user_pwd);
     *
     * JSONObject req_info = new JSONObject(); req_info.put("req_type",
     * req_type); req_info.put("channel_type", channel_type);
     *
     * JSONObject corp_kyc_info = new JSONObject(); corp_kyc_info.put("inst_id",
     * inst_id); corp_kyc_info.put("module_name", module_name);
     * corp_kyc_info.put("corp_name", corp_name);
     * corp_kyc_info.put("corp_reg_no", corp_reg_no);
     * corp_kyc_info.put("corp_addr",corp_addr);
     * corp_kyc_info.put("corp_branch", corp_branch);
     * corp_kyc_info.put("corp_reg", corp_reg); corp_kyc_info.put("industry",
     * industry); corp_kyc_info.put("corp_logo", corp_logo);
     *
     *
     *
     *
     * JSONObject session_info = new JSONObject();
     * session_info.put("session_id", session_id);
     *
     * JSONObject device_info = new JSONObject();
     * device_info.put("device_sub_type", device_sub_type);
     * device_info.put("device_type", device_type);
     * device_info.put("device_address", device_address);
     * device_info.put("device_model", device_model);
     *
     * JSONObject finalJsonObj = new JSONObject();
     * finalJsonObj.put("user_info",user_info); finalJsonObj.put("req_info",
     * req_info); finalJsonObj.put("corp_kyc_info",corp_kyc_info);
     * finalJsonObj.put("session_info",session_info);
     * finalJsonObj.put("device_info", device_info);
     *
     *
     * System.out.println("ADD CORPORATE KYC - Json Data : " +
     * finalJsonObj.toJSONString()); //Send the request to EappsCore for
     * Response try{ String resp=sendRequest(finalJsonObj.toJSONString());
     * PrintWriter out = response.getWriter(); /* TODO output your page here.
     * You may use following sample code.
     */
    /**
     * out.println(resp);
     *
     *
     * }catch(Exception e){ System.out.println("Send Request Error: " +
     * e.getMessage().toString());
     *
     * }
     *
     * }
     * catch (ArrayIndexOutOfBoundsException e) { System.out.println("Request
     * Parameter Error: Array is out of Bounds"+e); }
     *
     *
     * }
     *
     *
     *
     * /**27
     */
    /*Post to GET_LOAN_INFO_LIST Request*/
    /**
     * protected void getLoanInfoListRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * try { * RequestDecoder decoder = new RequestDecoder(requestBody); String
     * [] decodedString = decoder.getDecodedString(); String req_type =
     * decodedString[1].trim(); String channel_type = decodedString[2].trim();
     * String user_name = decodedString[3].trim(); * String inst_id =
     * decodedString[4].trim(); String session_id = decodedString[5].trim();
     * String device_sub_type = decodedString[6].trim(); String device_type =
     * decodedString[7].trim(); String device_address = decodedString[8].trim();
     * String device_model = decodedString[9].trim(); String user_pwd =
     * decodedString[10].trim(); String module_name = decodedString[11].trim();
     * String corp_name = decodedString[12].trim(); String corp_reg_no =
     * decodedString[13].trim(); String corp_addr = decodedString[14].trim();
     * String corp_branch = decodedString[15].trim(); String corp_reg =
     * decodedString[16].trim(); String industry = decodedString[17].trim();
     * String corp_logo = decodedString[18].trim();
     *
     *
     *
     *
     *
     * JSONObject user_info = new JSONObject(); user_info.put("user_name",
     * user_name); user_info.put("user_pwd", user_pwd);
     *
     * JSONObject req_info = new JSONObject(); req_info.put("req_type",
     * req_type); req_info.put("channel_type", channel_type);
     *
     * JSONObject corp_kyc_info = new JSONObject(); corp_kyc_info.put("inst_id",
     * inst_id); corp_kyc_info.put("module_name", module_name);
     * corp_kyc_info.put("corp_name", corp_name);
     * corp_kyc_info.put("corp_reg_no", corp_reg_no);
     * corp_kyc_info.put("corp_addr",corp_addr);
     * corp_kyc_info.put("corp_branch", corp_branch);
     * corp_kyc_info.put("corp_reg", corp_reg); corp_kyc_info.put("industry",
     * industry); corp_kyc_info.put("corp_logo", corp_logo);
     *
     *
     *
     *
     * JSONObject session_info = new JSONObject();
     * session_info.put("session_id", session_id);
     *
     * JSONObject device_info = new JSONObject();
     * device_info.put("device_sub_type", device_sub_type);
     * device_info.put("device_type", device_type);
     * device_info.put("device_address", device_address);
     * device_info.put("device_model", device_model);
     *
     * JSONObject finalJsonObj = new JSONObject();
     * finalJsonObj.put("user_info",user_info); finalJsonObj.put("req_info",
     * req_info); finalJsonObj.put("corp_kyc_info",corp_kyc_info);
     * finalJsonObj.put("session_info",session_info);
     * finalJsonObj.put("device_info", device_info);
     *
     *
     * System.out.println("ADD CORPORATE KYC - Json Data : " +
     * finalJsonObj.toJSONString()); //Send the request to EappsCore for
     * Response try{ String resp=sendRequest(finalJsonObj.toJSONString());
     * PrintWriter out = response.getWriter(); /* TODO output your page here.
     * You may use following sample code.
     */
    /**
     * out.println(resp);
     *
     *
     * }catch(Exception e){ System.out.println("Send Request Error: " +
     * e.getMessage().toString());
     *
     * }
     *
     * }
     * catch (ArrayIndexOutOfBoundsException e) { System.out.println("Request
     * Parameter Error: Array is out of Bounds"+e); }
     *
     *
     *
     * }
     *
     *
     *
     * /**28
     */
    /*Post to ADD TRAN TYPE Request*/
    //addTranTypeRequest
    protected void att(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String transfer_name = request.getParameter("transfer_name");
        String transfer_type = request.getParameter("transfer_type");
        String transfer_code = request.getParameter("transfer_code");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject tran_type_info = new JSONObject();
        tran_type_info.put("transfer_name", transfer_name);
        tran_type_info.put("transfer_type", transfer_type);
        tran_type_info.put("transfer_code", transfer_code);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("tran_type_info", tran_type_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD TRAN TYPE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 29
     */
    /*Post to AUTH TRAN TYPE Request*/
    //authTranTypeRequest
    protected void autt(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String rec_id = request.getParameter("rec_id");
        String auth_status = request.getParameter("auth_status");
        String auth_desc = request.getParameter("auth_desc");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject tran_type_info = new JSONObject();
        tran_type_info.put("rec_id", rec_id);
        tran_type_info.put("auth_status", auth_status);
        tran_type_info.put("auth_desc", auth_desc);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", tran_type_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("AUTH TRAN TYPE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 30
     */
    /*Post to DEAUTH_TRAN_TYPE Request*/
    //deauthTranTypeRequest
    protected void dtt(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String rec_id = request.getParameter("rec_id");
        String auth_status = request.getParameter("auth_status");
        String auth_desc = request.getParameter("auth_desc");
        String rej_reason = request.getParameter("rej_reason");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject tran_type_info = new JSONObject();
        tran_type_info.put("rec_id", rec_id);
        tran_type_info.put("auth_status", auth_status);
        tran_type_info.put("auth_desc", auth_desc);
        tran_type_info.put("rej_reason", rej_reason);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("tran_type_info", tran_type_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("DEAUTH_TRAN_TYPE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 31
     */
    /*Post to GET_TRAN_TYPE_LIST Request*/
    //getTranTypeListRequest
    public void gttl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET_TRAN_TYPE_LIST - Json Data : " + finalJsonObj.toJSONString());

        try {
            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());

            System.out.println("Response Code: " + resp);
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + resp);
            String response_subcode = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc = (String) response_info.get("resp_desc");

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_subcode.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONArray arr = (new JsonObjectParser()).parseJsonArray2(resp, "tran_type_list");
                    int objSize = 0;

                    for (int i = 0; i < arr.size(); i++) {
                        JSONObject objects = (JSONObject) arr.get(i);
                        objSize = objects.size();
                    }
                    GetTranTypeList getTranTypeList = new GetTranTypeList(objSize);
                    for (int tr = 0; tr < arr.size(); tr++) {
                        List<String> lName = new ArrayList<>();

                        String inst_id_,
                                transfer_name_,
                                transfer_type_,
                                transfer_code_,
                                status_,
                                auth_status_,
                                maker_name_,
                                auth_name_,
                                rej_reason_,
                                auth_desc_,
                                rec_id_,
                                maker_role_;

                        transfer_name_ = (String) ((JSONObject) arr.get(tr)).get("transfer_name");
                        inst_id_ = (String) ((JSONObject) arr.get(tr)).get("inst_id");
                        transfer_type_ = (String) ((JSONObject) arr.get(tr)).get("transfer_type");
                        transfer_code_ = (String) ((JSONObject) arr.get(tr)).get("transfer_code");
                        status_ = (String) ((JSONObject) arr.get(tr)).get("status");
                        auth_status_ = (String) ((JSONObject) arr.get(tr)).get("auth_status");
                        auth_name_ = (String) ((JSONObject) arr.get(tr)).get("auth_name");
                        rej_reason_ = (String) ((JSONObject) arr.get(tr)).get("rej_reason");
                        maker_name_ = (String) ((JSONObject) arr.get(tr)).get("maker_name");
                        auth_desc_ = (String) ((JSONObject) arr.get(tr)).get("auth_desc");
                        rec_id_ = (String) ((JSONObject) arr.get(tr)).get("rec_id");
                        maker_role_ = (String) ((JSONObject) arr.get(tr)).get("maker_role");
                        System.out.println("Parsed the array.....\nValue of 1st item is:  " + tr);

                        getTranTypeList.setInst_id(inst_id_, lName);
                        getTranTypeList.setTransfer_name(transfer_name_, lName);
                        getTranTypeList.setTransfer_type(transfer_type_, lName);
                        getTranTypeList.setTransfer_code(transfer_code_, lName);
                        getTranTypeList.setStatus(status_, lName);
                        getTranTypeList.setAuth_status(auth_status_, lName);
                        getTranTypeList.setMaker_name(maker_name_, lName);
                        getTranTypeList.setAuth_name(auth_name_, lName);
                        getTranTypeList.setRej_reason(rej_reason_, lName);
                        getTranTypeList.setAuth_desc(auth_desc_, lName);
                        getTranTypeList.setRec_id(rec_id_, lName);
                        getTranTypeList.setMaker_role(maker_role_, lName);
                    }
                    request.setAttribute("get_tran_type_list", getTranTypeList);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);

                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {
                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }

        } catch (Exception e) {
            System.out.println("Send Request Error:\n" + e.getMessage().toString());

        }
    }

    /**
     * 32
     */
    /*Post to GET_TRAN_TYPE Request*/
    //getTranTypeRequest
    protected void gtt(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String rec_id = request.getParameter("rec_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject tran_type_info = new JSONObject();
        tran_type_info.put("rec_id", rec_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("tran_type_info", tran_type_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET_TRAN_TYPE - Json Data : " + finalJsonObj.toJSONString());

        jsonOb = new JsonObjectParser();
        //Send the request to EappsCore for Response
        try {

            String resp = sendRequest(finalJsonObj.toJSONString());

            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String resp_code_ = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id_");
            String resp_desc_ = (String) response_info.get("resp_desc");
            System.out.println("Response Code: " + resp_code_ + " "
                    + resp_subcode_ + " " + session_id_ + " " + resp_desc_);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    GetTranTypeRequest32 getTranTypeRequest32 = new GetTranTypeRequest32();

                    JSONArray arr = jsonOb.parseJsonArray2(resp, "s_get_tran_type");
                    for (int t = 0; t < arr.size(); t++) {

                        String inst_id_,
                                transfer_name_,
                                transfer_type_,
                                transfer_code_,
                                status_,
                                auth_status_,
                                maker_name_,
                                auth_name_,
                                rej_reason_,
                                auth_desc_,
                                rec_id_,
                                maker_role_;

                        inst_id_ = (String) ((JSONObject) arr.get(t)).get("inst_id");
                        transfer_name_ = (String) ((JSONObject) arr.get(t)).get("transfer_name");
                        transfer_type_ = (String) ((JSONObject) arr.get(t)).get("transfer_type");
                        transfer_code_ = (String) ((JSONObject) arr.get(t)).get("transfer_code");
                        status_ = (String) ((JSONObject) arr.get(t)).get("status");
                        auth_status_ = (String) ((JSONObject) arr.get(t)).get("auth_status");
                        maker_name_ = (String) ((JSONObject) arr.get(t)).get("maker_name");
                        auth_name_ = (String) ((JSONObject) arr.get(t)).get("auth_name");
                        rej_reason_ = (String) ((JSONObject) arr.get(t)).get("rej_reason");
                        auth_desc_ = (String) ((JSONObject) arr.get(t)).get("auth_desc");
                        rec_id_ = (String) ((JSONObject) arr.get(t)).get("rec_id");
                        maker_role_ = (String) ((JSONObject) arr.get(t)).get("maker_role");

                        getTranTypeRequest32.setInst_id_(inst_id_);
                        getTranTypeRequest32.setTransfer_name_(transfer_name_);
                        getTranTypeRequest32.setTransfer_type_(transfer_type_);
                        getTranTypeRequest32.setTransfer_code_(transfer_code_);
                        getTranTypeRequest32.setStatus_(status_);
                        getTranTypeRequest32.setAuth_status_(auth_status_);
                        getTranTypeRequest32.setMaker_name_(maker_name_);
                        getTranTypeRequest32.setAuth_name_(auth_name_);
                        getTranTypeRequest32.setRej_reason_(rej_reason_);
                        getTranTypeRequest32.setAuth_desc_(auth_desc_);
                        getTranTypeRequest32.setRec_id_(rec_id_);
                        getTranTypeRequest32.setMaker_role_(maker_role_);

                    }
                    request.setAttribute("get_tran_type", getTranTypeRequest32);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);
                } else {
                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {
                response.sendRedirect("/Eapps/Corporate/index.jsp");

                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);
            }

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 33
     */
    /*Post to BOOK FOREX Request*/
    //bookForexRequest
    protected void bf(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");
        String txf_currency = request.getParameter("txf_currency");
        String txf_amount = request.getParameter("txf_amount");
        String txf_date = request.getParameter("txf_date");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("corp_id", corp_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("inst_id", inst_id);
        req_info.put("txf_currency", txf_currency);
        req_info.put("txf_amount", txf_amount);
        req_info.put("txf_date", txf_date);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("BOOK FOREX - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String resp_code_ = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc_ = (String) response_info.get("resp_desc");
            String forex_booking_id_ = (String) response_info.get("forex_booking_id");

            System.out.println("Response Code: " + resp_code_);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    BookForexRequest33 bookForexRequest33 = new BookForexRequest33();
//                    bookForexRequest33.setResp_code_(resp_code_);
//                    bookForexRequest33.setResp_subcode_(resp_subcode_);
//                    bookForexRequest33.setSession_id_(session_id_);
//                    bookForexRequest33.setResp_desc_(resp_desc_);
                    bookForexRequest33.setForex_booking_id_(forex_booking_id_);

                    request.setAttribute("book_forex", bookForexRequest33);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);

                } else {
                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {
                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 34
     */
    /*Post to GET FOREX  Request*/
    //getForexRequest
    protected void gf(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");
        String forex_booking_id = request.getParameter("forex_booking_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("corp_id", corp_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("inst_id", inst_id);

        JSONObject forex_info = new JSONObject();
        forex_info.put("forex_booking_id", forex_booking_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("forex_info", forex_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET FOREX - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String resp_code_ = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc_ = (String) response_info.get("resp_desc");

            System.out.println("Response Code: " + resp_code_);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    GetForexRequest34 getForexRequest34 = new GetForexRequest34();

                    JSONArray arr = jsonOb.parseJsonArray2(resp, "forex_booking_list");
                    for (int t = 0; t < arr.size(); t++) {

                        String inst_id_,
                                forex_amount_,
                                currency_,
                                charges_,
                                booking_id_,
                                booking_date_,
                                status_,
                                auth_status_,
                                user_id_,
                                corp_id_,
                                auth_desc_,
                                reject_reason_;

                        inst_id_ = (String) ((JSONObject) arr.get(t)).get("inst_id");
                        forex_amount_ = (String) ((JSONObject) arr.get(t)).get("forex_amount");
                        currency_ = (String) ((JSONObject) arr.get(t)).get("currency_");
                        charges_ = (String) ((JSONObject) arr.get(t)).get("charges");
                        booking_id_ = (String) ((JSONObject) arr.get(t)).get("booking_id_");
                        booking_date_ = (String) ((JSONObject) arr.get(t)).get("booking_date");
                        status_ = (String) ((JSONObject) arr.get(t)).get("status");
                        auth_status_ = (String) ((JSONObject) arr.get(t)).get("auth_status");
                        user_id_ = (String) ((JSONObject) arr.get(t)).get("user_id");
                        corp_id_ = (String) ((JSONObject) arr.get(t)).get("corp_id_");
                        auth_desc_ = (String) ((JSONObject) arr.get(t)).get("auth_desc");
                        reject_reason_ = (String) ((JSONObject) arr.get(t)).get("reject_reason");

                        getForexRequest34.setInst_id_(inst_id_);
                        getForexRequest34.setForex_amount_(forex_amount_);
                        getForexRequest34.setReject_reason_(reject_reason_);
                        getForexRequest34.setStatus_(status_);
                        getForexRequest34.setUser_id_(user_id_);
                        getForexRequest34.setCurrency_(currency_);
                        getForexRequest34.setCorp_id_(corp_id_);
                        getForexRequest34.setCharges_(charges_);
                        getForexRequest34.setBooking_id_(booking_id_);
                        getForexRequest34.setBooking_date_(booking_date_);
                        getForexRequest34.setAuth_status_(auth_status_);
                        getForexRequest34.setAuth_desc_(auth_desc_);

                    }
                    request.setAttribute("get_book_forex", getForexRequest34);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);
                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());
        }
    }

    /**
     * 35
     */
    /*Post to GET FOREX LIST Request*/
    //getForexListRequest
    public void gfl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("corp_id", corp_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET FOREX LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            jsonOb = new JsonObjectParser();
//            String resp = sendRequest(finalJsonObj.toJSONString());
//            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
//            String resp_code_ = (String) response_info.get("resp_code");
//            String resp_subcode_ = (String) response_info.get("resp_subcode");
//            String session_id_ = (String) response_info.get("session_id");
//            String resp_desc_ = (String) response_info.get("resp_desc");
//
//            System.out.println("Response Code: " + resp_code_);
//
//            HttpSession session = request.getSession(false);
//            if (session != null) {
//
//                String SESSION_ID = (String) session.getAttribute("session_id");
//
//                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
//                        && SESSION_ID.equals(session_id)) {

//            GetForexListRequest35 getForexListRequest35 = new GetForexListRequest35();
            getForexListRequest35 = new GetForexListRequest35();
            JSONArray arr = jsonOb.parseJsonArray("C:/Users/Nzangi/Desktop/files/forexList.txt", "forex_booking_list");
            for (int t = 0; t < arr.size(); t++) {
//                List<String> lName = new ArrayList<>();

                String inst_id_,
                        forex_amount_,
                        currency_,
                        charges_,
                        booking_id_,
                        booking_date_,
                        status_,
                        auth_status_,
                        user_id_,
                        corp_id_,
                        auth_desc_,
                        reject_reason_;

                System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.................................");
                inst_id_ = (String) ((JSONObject) arr.get(t)).get("inst_id");
                forex_amount_ = (String) ((JSONObject) arr.get(t)).get("forex_amount");
                currency_ = (String) ((JSONObject) arr.get(t)).get("currency");
                charges_ = (String) ((JSONObject) arr.get(t)).get("charges");
                booking_id_ = (String) ((JSONObject) arr.get(t)).get("booking_id_");
                booking_date_ = (String) ((JSONObject) arr.get(t)).get("booking_date");
                status_ = (String) ((JSONObject) arr.get(t)).get("status");
                auth_status_ = (String) ((JSONObject) arr.get(t)).get("auth_status");
                user_id_ = (String) ((JSONObject) arr.get(t)).get("user_id");
                corp_id_ = (String) ((JSONObject) arr.get(t)).get("corp_id_");
                auth_desc_ = (String) ((JSONObject) arr.get(t)).get("auth_desc");
                reject_reason_ = (String) ((JSONObject) arr.get(t)).get("reject_reason");

                List<String> list = new ArrayList<>();
                int size = (Integer) ((JSONObject) arr.get(t)).size();

                getForexListRequest35.setInst_id_(inst_id_, size, list);
                getForexListRequest35.setForex_amount_(forex_amount_, size, list);
                getForexListRequest35.setReject_reason_(reject_reason_, size, list);
                getForexListRequest35.setStatus_(status_, size, list);
                getForexListRequest35.setUser_id_(user_id_, size, list);
                getForexListRequest35.setCurrency_(currency_, size, list);
                getForexListRequest35.setCorp_id_(corp_id_, size, list);
                getForexListRequest35.setCharges_(charges_, size, list);
                getForexListRequest35.setBooking_id_(booking_id_, size, list);
                getForexListRequest35.setBooking_date_(booking_date_, size, list);
                getForexListRequest35.setAuth_status_(auth_status_, size, list);
                getForexListRequest35.setAuth_desc_(auth_desc_, size, list);
//                list.

            }
            request.setAttribute("book_forex_list", getForexListRequest35);

            RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/forex.jsp");
            view.forward(request, response);
            System.out.println("Redirect successfull..........................................");
//                } else {
//
//                    response.sendRedirect("/Eapps/Corporate/index.jsp");
//                }
//            } else {
//
//                response.sendRedirect("/Eapps/Corporate/index.jsp");
//            }

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 36
     */
    /*Post to GET_APPLICATION_DETAILS Request*/
    //getApplicationDetailsRequest
    protected void gad(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET_APPLICATION_DETAILS - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) (new JsonObjectParser()).jsonObj(resp).get("resp_info");
            String resp_code_ = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc_ = (String) response_info.get("resp_desc");
            System.out.println("Response Code: " + resp_code_);

            HttpSession session = request.getSession(false);
            if (session != null) {
                jsonOb = new JsonObjectParser();

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONArray arr = jsonOb.parseJsonArray2(resp, "s_get_corp_kyc_app");

                    for (int a = 0; a < arr.size(); a++) {
                        JSONObject user_role = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
                        JSONObject user_prod = (JSONObject) jsonOb.jsonObj(resp).get("resp_info");
                        JSONObject user_cont = (JSONObject) jsonOb.jsonObj(resp).get("resp_info");
                    }
                    response.sendRedirect("/Eapps/Corporate/dashboard.jsp");
                } else {
                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {
                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 37
     */
    /*Post to GET_INDUSTRY_LIST Request*/
    //getIndustryListRequest
    protected void gil(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET_INDUSTRY_LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String resp_code_ = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            System.out.println("Response Code: " + resp_code_);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONArray arr = jsonOb.parseJsonArray2(resp, "industry_list");
                    int objSize = 0;

                    for (int i = 0; i < arr.size(); i++) {
                        JSONObject objects = (JSONObject) arr.get(i);
                        objSize = objects.size();
                    }

                    System.out.println(objSize);
                    GetIndustryList37 getIndustryList37 = new GetIndustryList37(objSize);
                    for (int tr = 0; tr < arr.size(); tr++) {
//                String lName="list"+tr;
                        List<String> lName = new ArrayList<>();

                        String industry_name_,
                                industry_desc_,
                                industry_id_;

                        industry_name_ = (String) ((JSONObject) arr.get(tr)).get("industry_name");
                        industry_desc_ = (String) ((JSONObject) arr.get(tr)).get("industry_desc");
                        industry_id_ = (String) ((JSONObject) arr.get(tr)).get("industry_id");

                        getIndustryList37.setIndustry_desc_(industry_desc_, lName);
                        getIndustryList37.setIndustry_id_(industry_id_, lName);
                        getIndustryList37.setIndustry_name_(industry_name_, lName);

                    }
                    request.setAttribute("get_industry_list", getIndustryList37);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);

                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 38
     */
    /*Post to MY_ACCOUNT_CORPORATE Request*/
    //myAccountCorporateRequest
    public void mac(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String br_code = request.getParameter("br_code");
        String acct_no = request.getParameter("acct_no");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("br_code", br_code);
        req_info.put("acct_no", acct_no);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("MY_ACCOUNT_CORPORATE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            jsonOb = new JsonObjectParser();
            String resp = "C:/Users/Nzangi/Desktop/files/myAccounts.txt";// sendRequest(finalJsonObj.toJSONString());

            JSONObject response_info = (JSONObject) jsonOb.jsonObj(resp).get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

//            if (response_code.equalsIgnoreCase("000")) {
            String resp_code_,
                    resp_subcode_,
                    session_id_,
                    resp_desc_,
                    consolidated_balance_,
                    tran_date_,
                    tran_time_,
                    acct_type_,
                    acct_number,
                    acct_desc,
                    total_balance,
                    last_mon_stmt,
                    opening_balance,
                    las_dr_act,
                    las_cr_act,
                    cr_turn_over,
                    dr_turn_over,
                    branch,
                    sweep_amt,
                    chq_flag,
                    sig_name,
                    sig_limit,
                    sig_type;

            resp_code_ = (String) response_info.get("resp_code");
            resp_subcode_ = (String) response_info.get("resp_subcode");
            session_id_ = (String) response_info.get("session_id");
            resp_desc_ = (String) response_info.get("resp_desc");
            System.out.println(response_info.toString());

            HttpSession session = request.getSession(false);
            System.out.println("____________________________________________________________________________________________");

            if (session != null) {

                String SESSION_ID = "session_id"; //(String) session.getAttribute("session_id");
                System.out.println("_________________________xxxxxxxxxxxxxxxxxxxxxxxxxxxxx_______________________________________");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals("session_id")) {
//            System.out.println(resp);

                    consolidated_balance_ = (String) response_info.get("consolidated_balance");
                    tran_date_ = (String) response_info.get("tran_date");
                    tran_time_ = (String) response_info.get("tran_time");
                    acct_type_ = (String) response_info.get("acct_type");

                    JSONArray arr = jsonOb.parseJsonArray2(response_info.toJSONString(), "acct_status_list");
                    acct_number = (String) ((JSONObject) arr.get(0)).get("acct_number");
                    acct_desc = (String) ((JSONObject) arr.get(0)).get("acct_desc");
                    total_balance = (String) ((JSONObject) arr.get(0)).get("total_balance");
                    last_mon_stmt = (String) ((JSONObject) arr.get(0)).get("last_mon_stmt");
                    opening_balance = (String) ((JSONObject) arr.get(0)).get("opening_balance");
                    las_dr_act = (String) ((JSONObject) arr.get(0)).get("las_dr_act");
                    las_cr_act = (String) ((JSONObject) arr.get(0)).get("las_cr_act");
                    cr_turn_over = (String) ((JSONObject) arr.get(0)).get("cr_turn_over");
                    dr_turn_over = (String) ((JSONObject) arr.get(0)).get("dr_turn_over");
                    branch = (String) ((JSONObject) arr.get(0)).get("branch");
                    sweep_amt = (String) ((JSONObject) arr.get(0)).get("sweep_amt");
                    chq_flag = (String) ((JSONObject) arr.get(0)).get("chq_flag");
//                acct_number = (String) ((JSONObject) arr.get(0)).get("acct_number");

                    JSONArray arr2 = jsonOb.parseJsonArray2(arr.get(0).toString(), "sig_list");
                    sig_name = (String) ((JSONObject) arr2.get(0)).get("sig_name");
                    sig_limit = (String) ((JSONObject) arr2.get(0)).get("sig_limit");
                    sig_type = (String) ((JSONObject) arr2.get(0)).get("sig_type");

                    MyAccountCorporate38 myAccountCorporate38 = new MyAccountCorporate38();

                    myAccountCorporate38.setAcct_desc(acct_desc);
                    myAccountCorporate38.setAcct_number(acct_number);
                    myAccountCorporate38.setBranch(branch);
                    myAccountCorporate38.setChq_flag(chq_flag);
                    myAccountCorporate38.setConsolidated_balance_(consolidated_balance_);
                    myAccountCorporate38.setCr_turn_over(cr_turn_over);
                    myAccountCorporate38.setDr_turn_over(dr_turn_over);
                    myAccountCorporate38.setLas_cr_act(las_cr_act);
                    myAccountCorporate38.setLas_dr_act(las_dr_act);
                    myAccountCorporate38.setLast_mon_stmt(last_mon_stmt);
                    myAccountCorporate38.setOpening_balance(opening_balance);
                    myAccountCorporate38.setResp_code_(resp_code_);
                    myAccountCorporate38.setResp_desc_(resp_desc_);
                    myAccountCorporate38.setResp_subcode_(resp_subcode_);
                    myAccountCorporate38.setSession_id_(session_id_);
                    myAccountCorporate38.setSig_limit(sig_limit);
                    myAccountCorporate38.setTran_time_(tran_time_);
                    myAccountCorporate38.setTran_date_(tran_date_);
                    myAccountCorporate38.setTotal_balance(total_balance);
                    myAccountCorporate38.setSweep_amt(sweep_amt);
                    myAccountCorporate38.setSig_type(sig_type);
                    myAccountCorporate38.setSig_name(sig_name);
                    myAccountCorporate38.setAcct_type_(acct_type_);

                    request.setAttribute("myaccounts", myAccountCorporate38);

                    System.out.println("Resp:\n__________________hhhhhhhhhhhhhhhhhhhhh______________________________________");

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/Loan_statements.jsp");
                    view.forward(request, response);

                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
//            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.toString());

        }

    }

    /**
     * 39
     */
    /*Post to CORP_MY_ACCOUNTS Request*/
    //corpMyAccountsRequest
    public void cma(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("corp_id", corp_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("br_code", channel_type);
        req_info.put("acct_no", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("CORP_MY_ACCOUNTS - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");

            String resp_code_,
                    resp_subcode_,
                    session_id_,
                    resp_desc_,
                    consolidated_balance_,
                    tran_date_,
                    tran_time_,
                    acct_type_,
                    acct_number_,
                    acct_desc_,
                    total_balance_,
                    last_mon_stmt_,
                    opening_balance_,
                    las_dr_act_,
                    las_cr_act_,
                    cr_turn_over_,
                    dr_turn_over_,
                    branch_,
                    sweep_amt_;
            JSONArray arr = jsonOb.parseJsonArray2(response_info.toJSONString(), "acct_status_list");

            resp_code_ = (String) response_info.get("resp_code");
            resp_subcode_ = (String) response_info.get("resp_subcode");
            session_id_ = (String) response_info.get("session_id");
            resp_desc_ = (String) response_info.get("resp_desc");

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = "session_id";//(String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals("session_id")) {

                    consolidated_balance_ = (String) response_info.get("consolidated_balance");
                    tran_date_ = (String) response_info.get("tran_date");
                    tran_time_ = (String) response_info.get("tran_time");
                    acct_type_ = (String) response_info.get("acct_type");

                    acct_number_ = (String) ((JSONObject) arr.get(0)).get("acct_number");
                    acct_desc_ = (String) ((JSONObject) arr.get(0)).get("acct_desc");
                    total_balance_ = (String) ((JSONObject) arr.get(0)).get("total_balance");
                    last_mon_stmt_ = (String) ((JSONObject) arr.get(0)).get("last_mon_stmt");
                    opening_balance_ = (String) ((JSONObject) arr.get(0)).get("opening_balance");
                    las_dr_act_ = (String) ((JSONObject) arr.get(0)).get("las_dr_act");
                    las_cr_act_ = (String) ((JSONObject) arr.get(0)).get("las_cr_act");
                    cr_turn_over_ = (String) ((JSONObject) arr.get(0)).get("cr_turn_over");
                    dr_turn_over_ = (String) ((JSONObject) arr.get(0)).get("dr_turn_over");
                    branch_ = (String) ((JSONObject) arr.get(0)).get("branch");
                    sweep_amt_ = (String) ((JSONObject) arr.get(0)).get("sweep_amt");

                    CorpMyAccountsRequest39 corpMyAccountsRequest39 = new CorpMyAccountsRequest39();
                    corpMyAccountsRequest39.setAcct_desc_(acct_desc_);
                    corpMyAccountsRequest39.setAcct_number_(acct_number_);
                    corpMyAccountsRequest39.setAcct_type_(acct_type_);
                    corpMyAccountsRequest39.setBranch_(branch_);
                    corpMyAccountsRequest39.setConsolidated_balance_(consolidated_balance_);
                    corpMyAccountsRequest39.setCr_turn_over_(cr_turn_over_);
                    corpMyAccountsRequest39.setDr_turn_over_(dr_turn_over_);
                    corpMyAccountsRequest39.setLas_cr_act_(las_cr_act_);
                    corpMyAccountsRequest39.setLast_mon_stmt_(last_mon_stmt_);
                    corpMyAccountsRequest39.setOpening_balance_(opening_balance_);
                    corpMyAccountsRequest39.setResp_code_(resp_code_);
                    corpMyAccountsRequest39.setResp_desc_(resp_desc_);
                    corpMyAccountsRequest39.setResp_subcode_(resp_subcode_);
                    corpMyAccountsRequest39.setSession_id_(session_id_);
                    corpMyAccountsRequest39.setSweep_amt_(sweep_amt_);
                    corpMyAccountsRequest39.setTotal_balance_(total_balance_);
                    corpMyAccountsRequest39.setTran_date_(tran_date_);
                    corpMyAccountsRequest39.setTran_time_(tran_time_);

                    request.setAttribute("myaccounts_corp", corpMyAccountsRequest39);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/Loan_statements.jsp");
                    view.forward(request, response);
                } else {
                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {
                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 40
     */
    /*Post to CORP_BALANCE Request*/
    //corpBalanceRequest
    protected void cb(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");
        String account_no = request.getParameter("account_no");
        String branch_code = request.getParameter("branch_code");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("corp_id", corp_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject txn_info = new JSONObject();
        txn_info.put("account_no", account_no);
        txn_info.put("branch_code", branch_code);
        txn_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("txn_info", txn_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("CORP_BALANCE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            String resp_code_,
                    resp_subcode_,
                    session_id_,
                    resp_desc_,
                    avail_bal_,
                    cur_bal_;

            resp_code_ = (String) response_info.get("resp_code");
            resp_subcode_ = (String) response_info.get("resp_subcode");
            session_id_ = (String) response_info.get("session_id");

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    resp_desc_ = (String) response_info.get("resp_desc");
                    avail_bal_ = (String) response_info.get("avail_bal");
                    cur_bal_ = (String) response_info.get("cur_bal");

                    CorpBalanceRequest40 corpBalanceRequest40 = new CorpBalanceRequest40();
                    corpBalanceRequest40.setAvail_bal_(avail_bal_);
                    corpBalanceRequest40.setCur_bal_(cur_bal_);
                    corpBalanceRequest40.setResp_code_(resp_code_);
                    corpBalanceRequest40.setResp_desc_(resp_desc_);
                    corpBalanceRequest40.setResp_subcode_(resp_subcode_);
                    corpBalanceRequest40.setSession_id_(session_id_);

                    request.setAttribute("corp_bal_inq", corpBalanceRequest40);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 41
     */
    /*Post to CORP_MY_ACCOUNTS_LIST Request*/
    //corpMyAccountsListRequest
    protected void cmal(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("corp_id", corp_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("CORP_MY_ACCOUNTS_LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            String resp_code_,
                    resp_subcode_,
                    session_id_,
                    resp_desc_,
                    rel_type_,
                    rel_id_,
                    rel_sub_type_,
                    br_id_;
            resp_code_ = (String) response_info.get("resp_code");
            resp_subcode_ = (String) response_info.get("resp_subcode");
            session_id_ = (String) response_info.get("session_id");
            resp_desc_ = (String) response_info.get("resp_desc");

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = "session_id";// (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals("session_id")) {

                    corpMyAccountsListRequest41 = new CorpMyAccountsListRequest41();
                    
                    corpMyAccountsListRequest41.setSession_id_(session_id_);
                    corpMyAccountsListRequest41.setResp_subcode_(resp_subcode_);
                    corpMyAccountsListRequest41.setResp_desc_(resp_desc_);
                    corpMyAccountsListRequest41.setResp_code_(resp_code_);

                    JSONArray arr = jsonOb.parseJsonArray2(response_info.toJSONString(), "realtionship_list");
                    for (int r = 0; r < arr.size(); r++) {
                        List<String> list = new ArrayList<>();
                        int t = (Integer) ((JSONObject) arr.get(0)).size();

                        rel_type_ = (String) response_info.get("rel_type");
                        rel_id_ = (String) response_info.get("rel_id");
                        rel_sub_type_ = (String) response_info.get("rel_sub_type");
                        br_id_ = (String) response_info.get("br_id_");

                        corpMyAccountsListRequest41.setRel_id_(rel_id_, list, t);
                        corpMyAccountsListRequest41.setRel_sub_type_(rel_sub_type_, list, t);
                        corpMyAccountsListRequest41.setRel_type_(rel_type_, list, t);
                        corpMyAccountsListRequest41.setBr_id_(br_id_, list, t);

                    }

                    request.setAttribute("myaccounts_corp_list", corpMyAccountsListRequest41);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 42
     */
    /*Post to CORPORATE OTP Request*/
    //corporateOTPRequest
    protected void cOTP(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String module_name = request.getParameter("module_name");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject otp_info = new JSONObject();
        otp_info.put("inst_id", inst_id);
        otp_info.put("otp_type", module_name);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("otp_info", otp_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("CORPORATE OTP - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) (new JsonObjectParser()).jsonObj2(resp).get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            String resp_code_,
                    resp_subcode_,
                    session_id_,
                    resp_desc_;

            resp_code_ = (String) response_info.get("resp_code");
            resp_subcode_ = (String) response_info.get("resp_subcode");
            session_id_ = (String) response_info.get("session_id");
            resp_desc_ = (String) response_info.get("resp_desc");

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    request.setAttribute("sessionId", session_id);
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);
                } else {
                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {
                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 43
     */
    /*Post to ADD_CARD Request*/
    //addCardRequest
    protected void ac(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");
        String card_number = request.getParameter("card_number");
        String cvv = request.getParameter("cvv");
        String date_of_expiry = request.getParameter("date_of_expiry");
        String card_type = request.getParameter("card_type");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject card_info = new JSONObject();
        card_info.put("inst_id", inst_id);
        card_info.put("card_number", card_number);
        card_info.put("cvv", cvv);
        card_info.put("date_of_expiry", date_of_expiry);
        card_info.put("card_number", card_number);
        card_info.put("card_type", card_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("card_info", card_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD_CARD - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) (new JsonObjectParser()).jsonObj2(resp).get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            String resp_code_,
                    resp_subcode_,
                    session_id_,
                    resp_desc_,
                    app_id_;

            resp_code_ = (String) response_info.get("resp_code");
            resp_subcode_ = (String) response_info.get("resp_subcode");
            session_id_ = (String) response_info.get("session_id");
            resp_desc_ = (String) response_info.get("resp_desc");

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONObject card_info_ = (JSONObject) (new JsonObjectParser()).jsonObj2(resp).get("card_info");
                    app_id_ = (String) card_info_.get("app_id");

                    request.setAttribute("app_id", app_id_);
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard_dummy.jsp");
                    view.forward(request, response);
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 44
     */
    /*Post to GET_CARD Request*/
    //getCardRequest
    protected void gc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");
        String card_number = request.getParameter("card_number");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject card_info = new JSONObject();
        card_info.put("card_number", card_number);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("card_info", card_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET_CARD - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String resp_code_ = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc_ = (String) response_info.get("resp_desc");

            System.out.println("Response Code: " + resp_code_);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONArray arr = jsonOb.parseJsonArray2(resp, "card_info");
                    String inst_id_,
                            card_number_,
                            cvv_,
                            date_of_expiry_,
                            card_type_,
                            auth_desc_,
                            status_,
                            auth_status_,
                            user_id_,
                            corp_id_,
                            channel_type_;
//                acct_number_ = (String) ((JSONObject) arr.get(0)).get("acct_number");

                    inst_id_ = (String) ((JSONObject) arr.get(0)).get("resp_desc");
                    card_number_ = (String) ((JSONObject) arr.get(0)).get("card_number");
                    cvv_ = (String) ((JSONObject) arr.get(0)).get("cvv");
                    date_of_expiry_ = (String) ((JSONObject) arr.get(0)).get("date_of_expiry");
                    card_type_ = (String) ((JSONObject) arr.get(0)).get("card_type");
                    auth_desc_ = (String) ((JSONObject) arr.get(0)).get("auth_desc");
                    auth_status_ = (String) ((JSONObject) arr.get(0)).get("auth_status");
                    user_id_ = (String) ((JSONObject) arr.get(0)).get("user_id");
                    corp_id_ = (String) ((JSONObject) arr.get(0)).get("corp_id");
                    channel_type_ = (String) ((JSONObject) arr.get(0)).get("channel_type");
                    status_ = (String) ((JSONObject) arr.get(0)).get("status_");

                    GetCardRequest44 getCardRequest44 = new GetCardRequest44();

                    getCardRequest44.setAuth_desc_(auth_desc_);
                    getCardRequest44.setAuth_status_(auth_status_);
                    getCardRequest44.setCard_number_(card_number_);
                    getCardRequest44.setCard_type_(card_type_);
                    getCardRequest44.setChannel_type_(channel_type_);
                    getCardRequest44.setCorp_id_(corp_id_);
                    getCardRequest44.setCvv_(cvv_);
                    getCardRequest44.setDate_of_expiry_(date_of_expiry_);
                    getCardRequest44.setInst_id_(inst_id_);
                    getCardRequest44.setStatus_(status_);
                    getCardRequest44.setUser_id_(user_id_);

                    request.setAttribute("get_card_corp", getCardRequest44);
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);
                } else {
                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {
                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 45
     */
    /*Post to ADD_MAIL_SERV Request*/
    //addMailServRequest
    protected void ams(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String pickup_location = request.getParameter("pickup_location");
        String parcel_description = request.getParameter("parcel_description");
        String destination = request.getParameter("destination");
        String destination_branch = request.getParameter("destination_branch");
        String date_of_pickup = request.getParameter("date_of_pickup");
        String corp_id = request.getParameter("corp_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject mail_info = new JSONObject();
        mail_info.put("pickup_location", pickup_location);
        mail_info.put("parcel_description", parcel_description);
        mail_info.put("destination", destination);
        mail_info.put("destination_branch", destination_branch);
        mail_info.put("date_of_pickup", date_of_pickup);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("mail_info", mail_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String resp_code_ = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc_ = (String) response_info.get("resp_desc");

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONObject mail_info_ = (JSONObject) (new JsonObjectParser()).jsonObj2(resp).get("mail_info");

                    String app_id_ = (String) mail_info_.get("app_id");
                    System.out.println("Response Code: " + resp_subcode_);

                    request.setAttribute("app_id", app_id_);
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 46
     */
    /*Post to GET_MAIL_SERV Request*/
    //getMailServRequest
    protected void gms(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");
        String app_id = request.getParameter("app_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject mail_info = new JSONObject();
        mail_info.put("app_id", app_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("mail_info", mail_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET_MAIL_SERV - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String resp_code_ = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc_ = (String) response_info.get("resp_desc");
            System.out.println("Response Code: " + resp_code_);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    String inst_id_,
                            pickup_location_,
                            parcel_description_,
                            destination_,
                            destination_branch_,
                            date_of_pickup_,
                            app_id_,
                            corp_id_,
                            channel_type_;

                    JSONArray arr = jsonOb.parseJsonArray2(resp, "mail_serv_info");

                    inst_id_ = (String) ((JSONObject) arr.get(0)).get("inst_id");
                    pickup_location_ = (String) ((JSONObject) arr.get(0)).get("pickup_location");
                    parcel_description_ = (String) ((JSONObject) arr.get(0)).get("parcel_description");
                    destination_ = (String) ((JSONObject) arr.get(0)).get("destination");
                    destination_branch_ = (String) ((JSONObject) arr.get(0)).get("destination_branch");
                    date_of_pickup_ = (String) ((JSONObject) arr.get(0)).get("date_of_pickup");
                    app_id_ = (String) ((JSONObject) arr.get(0)).get("app_id");
                    corp_id_ = (String) ((JSONObject) arr.get(0)).get("corp_id");
                    channel_type_ = (String) ((JSONObject) arr.get(0)).get("channel_type");

                    GetMailServRequest46 getMailServRequest46 = new GetMailServRequest46();
                    getMailServRequest46.setApp_id_(app_id_);
                    getMailServRequest46.setChannel_type_(channel_type_);
                    getMailServRequest46.setCorp_id_(corp_id_);
                    getMailServRequest46.setDate_of_pickup_(date_of_pickup_);
                    getMailServRequest46.setDestination_(destination_);
                    getMailServRequest46.setDestination_branch_(destination_branch_);
                    getMailServRequest46.setInst_id_(inst_id_);
                    getMailServRequest46.setParcel_description_(parcel_description_);
                    getMailServRequest46.setPickup_location_(pickup_location_);

                    request.setAttribute("get_mail_serv_corp", getMailServRequest46);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {
                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 47
     */
    /*Post to ADD_GROUP_CORP Request*/
    //addGroupCorpRequest
    protected void agc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");
        String group_name = request.getParameter("group_name");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject group_info = new JSONObject();
        group_info.put("inst_id", inst_id);
        group_info.put("group_name", group_name);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("group_info", group_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD_GROUP_CORP - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String resp_code_ = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc_ = (String) response_info.get("resp_desc");
            System.out.println("Response Code: " + resp_code_);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (resp_code_.equalsIgnoreCase("000") && resp_subcode_.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    JSONObject group_info_ = (JSONObject) (new JsonObjectParser()).jsonObj2(resp).get("group_info");
                    String app_id_ = (String) response_info.get("app_id");

                    request.setAttribute("app_id_", app_id_);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard.jsp");
                    view.forward(request, response);
                } else {

                    response.sendRedirect("/Eapps/Corporate/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 48
     */
    /*Post to ADD_INSURANCE Request*/
    /**
     * protected void addInsuranceRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * try { * RequestDecoder decoder = new RequestDecoder(requestBody); String
     * [] decodedString = decoder.getDecodedString(); String req_type =
     * decodedString[1].trim(); String channel_type = decodedString[2].trim();
     * String user_name = decodedString[3].trim(); * String inst_id =
     * decodedString[4].trim(); String ses0sion_id = decodedString[5].trim();
     * String device_sub_type = decodedString[6].trim(); String device_type =
     * decodedString[7].trim(); String device_address = decodedString[8].trim();
     * String device_model = decodedString[9].trim(); String user_pwd =
     * decodedString[10].trim(); String module_name = decodedString[11].trim();
     * String corp_name = decodedString[12].trim(); String corp_reg_no =
     * decodedString[13].trim(); String corp_addr = decodedString[14].trim();
     * String corp_branch = decodedString[15].trim(); String corp_reg =
     * decodedString[16].trim(); String industry = decodedString[17].trim();
     * String corp_logo = decodedString[18].trim();
     *
     *
     *
     *
     *
     * JSONObject user_info = new JSONObject(); user_info.put("user_name",
     * user_name); user_info.put("user_pwd", user_pwd);
     *
     * JSONObject req_info = new JSONObject(); req_info.put("req_type",
     * req_type); req_info.put("channel_type", channel_type);
     *
     * JSONObject corp_kyc_info = new JSONObject(); corp_kyc_info.put("inst_id",
     * inst_id); corp_kyc_info.put("module_name", module_name);
     * corp_kyc_info.put("corp_name", corp_name);
     * corp_kyc_info.put("corp_reg_no", corp_reg_no);
     * corp_kyc_info.put("corp_addr",corp_addr);
     * corp_kyc_info.put("corp_branch", corp_branch);
     * corp_kyc_info.put("corp_reg", corp_reg); corp_kyc_info.put("industry",
     * industry); corp_kyc_info.put("corp_logo", corp_logo);
     *
     *
     *
     *
     * JSONObject session_info = new JSONObject();
     * session_info.put("session_id", session_id);
     *
     * JSONObject device_info = new JSONObject();
     * device_info.put("device_sub_type", device_sub_type);
     * device_info.put("device_type", device_type);
     * device_info.put("device_address", device_address);
     * device_info.put("device_model", device_model);
     *
     * JSONObject finalJsonObj = new JSONObject();
     * finalJsonObj.put("user_info",user_info); finalJsonObj.put("req_info",
     * req_info); finalJsonObj.put("corp_kyc_info",corp_kyc_info);
     * finalJsonObj.put("session_info",session_info);
     * finalJsonObj.put("device_info", device_info);
     *
     *
     * System.out.println("ADD CORPORATE KYC - Json Data : " +
     * finalJsonObj.toJSONString()); //Send the request to EappsCore for
     * Response try{ String resp=sendRequest(finalJsonObj.toJSONString());
     * PrintWriter out = response.getWriter(); / /* TODO output your page here.
     * You may use following sample code.
     *
     * /**
     * out.println(resp);
     *
     *
     * }catch(Exception e){ System.out.println("Send Request Error: " +
     * e.getMessage().toString());
     *
     * }
     *
     * }
     * catch (ArrayIndexOutOfBoundsException e) { System.out.println("Request
     * Parameter Error: Array is out of Bounds"+e); }
     *
     *
     * }
     *
     *
     *
     * /**49
     */
    /*Post to GET_INSURANCE Request*/
    /**
     * protected void getInsuranceRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * try { * RequestDecoder decoder = new RequestDecoder(requestBody); String
     * [] decodedString = decoder.getDecodedString(); String req_type =
     * decodedString[1].trim(); String channel_type = decodedString[2].trim();
     * String user_name = decodedString[3].trim(); * String inst_id =
     * decodedString[4].trim(); String session_id = decodedString[5].trim();
     * String device_sub_type = decodedString[6].trim(); String device_type =
     * decodedString[7].trim(); String device_address = decodedString[8].trim();
     * String device_model = decodedString[9].trim(); String user_pwd =
     * decodedString[10].trim(); String module_name = decodedString[11].trim();
     * String corp_name = decodedString[12].trim(); String corp_reg_no =
     * decodedString[13].trim(); String corp_addr = decodedString[14].trim();
     * String corp_branch = decodedString[15].trim(); String corp_reg =
     * decodedString[16].trim(); String industry = decodedString[17].trim();
     * String corp_logo = decodedString[18].trim();
     *
     *
     *
     *
     *
     * JSONObject user_info = new JSONObject(); user_info.put("user_name",
     * user_name); user_info.put("user_pwd", user_pwd);
     *
     * JSONObject req_info = new JSONObject(); req_info.put("req_type",
     * req_type); req_info.put("channel_type", channel_type);
     *
     * JSONObject corp_kyc_info = new JSONObject(); corp_kyc_info.put("inst_id",
     * inst_id); corp_kyc_info.put("module_name", module_name);
     * corp_kyc_info.put("corp_name", corp_name);
     * corp_kyc_info.put("corp_reg_no", corp_reg_no);
     * corp_kyc_info.put("corp_addr",corp_addr);
     * corp_kyc_info.put("corp_branch", corp_branch);
     * corp_kyc_info.put("corp_reg", corp_reg); corp_kyc_info.put("industry",
     * industry); corp_kyc_info.put("corp_logo", corp_logo);
     *
     *
     *
     *
     * JSONObject session_info = new JSONObject();
     * session_info.put("session_id", session_id);
     *
     * JSONObject device_info = new JSONObject();
     * device_info.put("device_sub_type", device_sub_type);
     * device_info.put("device_type", device_type);
     * device_info.put("device_address", device_address);
     * device_info.put("device_model", device_model);
     *
     * JSONObject finalJsonObj = new JSONObject();
     * finalJsonObj.put("user_info",user_info); finalJsonObj.put("req_info",
     * req_info); finalJsonObj.put("corp_kyc_info",corp_kyc_info);
     * finalJsonObj.put("session_info",session_info);
     * finalJsonObj.put("device_info", device_info);
     *
     *
     * System.out.println("ADD CORPORATE KYC - Json Data : " +
     * finalJsonObj.toJSONString()); //Send the request to EappsCore for
     * Response try{ String resp=sendRequest(finalJsonObj.toJSONString());
     * PrintWriter out = response.getWriter(); /* TODO output your page here.
     * You may use following sample code.
     */
    /**
     * out.println(resp);
     *
     *
     * }catch(Exception e){ System.out.println("Send Request Error: " +
     * e.getMessage().toString());
     *
     * }
     *
     * }
     * catch (ArrayIndexOutOfBoundsException e) { System.out.println("Request
     * Parameter Error: Array is out of Bounds"+e); }
     *
     *
     * }
     *
     *
     * /**50
     */
    /*Post to ADD TERM DEPOSITE Request*/
    //addTermDepositeRequest
    protected void atd(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");
        String amount = request.getParameter("amount");
        String rate = request.getParameter("rate");
        String deposite = request.getParameter("deposite");
        String term_dep_type = request.getParameter("term_dep_type");
        String maturity_period = request.getParameter("maturity_period");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject term_dep_info = new JSONObject();
        term_dep_info.put("amount", amount);
        term_dep_info.put("rate", rate);
        term_dep_info.put("deposite", deposite);
        term_dep_info.put("term_dep_type", term_dep_type);
        term_dep_info.put("maturity_period", maturity_period);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("term_dep_info", term_dep_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD TERM DEPOSITE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 51
     */
    /*Post to AUTH TERM DEPOSITE Request*/
    //authTermDepositeRequest
    protected void autd(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");
        String app_id = request.getParameter("app_id");
        String auth_status = request.getParameter("auth_status");
        String auth_desc = request.getParameter("auth_desc");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject term_dep_info = new JSONObject();
        term_dep_info.put("inst_id", inst_id);
        term_dep_info.put("corp_id", corp_id);
        term_dep_info.put("app_id", app_id);
        term_dep_info.put("auth_status", auth_status);
        term_dep_info.put("auth_desc", auth_desc);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("term_dep_info", term_dep_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("AUTH TERM DEPOSITE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 52
     */
    /*Post to GET TERM DEPOSITE LIST Request*/
    //getTermDepositeListRequest
    protected void gtdl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 53
     */
    /*Post to GET TERM DEPOSITE BASED CORP ID Request*/
    //getTermDepositeBasedCorpIDRequest
    protected void gtdbcID(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type");
        String channel_type = request.getParameter("channel_type");
        String user_name = request.getParameter("user_name");

        String inst_id = request.getParameter("inst_id");
        String session_id = request.getParameter("session_id");
        String device_sub_type = request.getParameter("device_sub_type");
        String device_type = request.getParameter("device_type");
        String device_address = request.getParameter("device_address");
        String device_model = request.getParameter("device_model");
        String user_pwd = request.getParameter("user_pwd");
        String corp_id = request.getParameter("corp_id");

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET TERM DEPOSITE BASED CORP ID - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 54
     */
    /*Post to GET TERM DEPOSITE  Request*/
    //getTermDepositeRequest
    protected void gtd(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type").trim();
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();

        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String corp_id = request.getParameter("corp_id").trim();
        String app_id = request.getParameter("app_id").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);
        req_info.put("app_id", app_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET TERM DEPOSITE  - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 55
     */
    /*Post to ADD BENIFICIARY  Request*/
    //addBenificiaryRequest
    protected void ab(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type").trim();
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();

        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String corp_id = request.getParameter("corp_id").trim();
        String entity_type = request.getParameter("entity_type").trim();
        String rel_type = request.getParameter("rel_type").trim();
        String priority = request.getParameter("priority").trim();
        String rel_sub_id = request.getParameter("rel_sub_id").trim();
        String rel_sub_type = request.getParameter("rel_sub_type").trim();
        String rel_id_desc = request.getParameter("rel_id_desc").trim();
        String inst_desc = request.getParameter("inst_desc").trim();
        String group_id = request.getParameter("group_id").trim();
        String nick_name = request.getParameter("nick_name").trim();
        String acc_no = request.getParameter("acc_no").trim();
        String rel_branch = request.getParameter("rel_branch").trim();
        String visibility = request.getParameter("visibility").trim();
        String branch = request.getParameter("branch").trim();
        String name = request.getParameter("name").trim();
        String benifi_bank_name = request.getParameter("benifi_bank_name").trim();
        String branch_code = request.getParameter("branch_code").trim();
        String swift_code = request.getParameter("swift_code").trim();
        String email_add = request.getParameter("email_add").trim();
        String phone_no = request.getParameter("phone_no").trim();
        String group_name = request.getParameter("group_name").trim();
        String staff_number = request.getParameter("staff_number").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_benifi_info = new JSONObject();
        corp_benifi_info.put("inst_id", inst_id);
        corp_benifi_info.put("corp_id", corp_id);
        corp_benifi_info.put("entity_type", entity_type);
        corp_benifi_info.put("rel_type", rel_type);
        corp_benifi_info.put("priority", priority);
        corp_benifi_info.put("rel_sub_id", rel_sub_id);
        corp_benifi_info.put("rel_sub_type", rel_sub_type);
        corp_benifi_info.put("rel_id_desc", rel_id_desc);
        corp_benifi_info.put("group_name", group_name);
        corp_benifi_info.put("inst_desc", inst_desc);
        corp_benifi_info.put("group_id", group_id);
        corp_benifi_info.put("nick_name", nick_name);
        corp_benifi_info.put("acc_no", acc_no);
        corp_benifi_info.put("rel_branch", rel_branch);
        corp_benifi_info.put("visibility", visibility);
        corp_benifi_info.put("nick_name", nick_name);
        corp_benifi_info.put("acc_no", acc_no);
        corp_benifi_info.put("branch", branch);
        corp_benifi_info.put("visibility", visibility);
        corp_benifi_info.put("name", name);
        corp_benifi_info.put("benifi_bank_name", benifi_bank_name);
        corp_benifi_info.put("branch_code", branch_code);
        corp_benifi_info.put("swift_code", swift_code);
        corp_benifi_info.put("email_add", email_add);
        corp_benifi_info.put("phone_no", phone_no);
        corp_benifi_info.put("staff_number", staff_number);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_benifi_info", corp_benifi_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD BENIFICIARY - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 56
     */
    /*Post to GET BENIFICIARY LIST  Request*/
    //getBenificiaryListRequest
    protected void gbl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type").trim();
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();

        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String rel_type = request.getParameter("rel_type").trim();
        String corp_id = request.getParameter("corp_id").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject corp_benifi_info = new JSONObject();
        corp_benifi_info.put("inst_id", inst_id);
        corp_benifi_info.put("rel_type", rel_type);
        corp_benifi_info.put("corp_id", corp_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("corp_kyc_info", corp_benifi_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET BENIFICIARY LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            jsonOb = new JsonObjectParser();
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) jsonOb.jsonObj2(resp).get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc_ = (String) response_info.get("resp_desc");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                GetBenificiaryListRequest56 getBenificiaryListRequest56 = new GetBenificiaryListRequest56();
                JSONArray arr = jsonOb.parseJsonArray2(resp, "get_benifi_list");
                for (int f = 0; f < arr.size(); f++) {
                    List<String> list = new ArrayList<>();
                    int len = (Integer) ((JSONObject) arr.get(f)).size();
                    String nick_name_,
                            benificiary_id_,
                            acc_no_,
                            branch_,
                            group_name_,
                            group_id_,
                            inst_id_,
                            inst_desc_,
                            priority_,
                            visibility_,
                            status_,
                            name_,
                            benifi_bank_name_,
                            branch_code_,
                            swift_code_,
                            email_add_,
                            phone_no_,
                            staff_number_;

                    nick_name_ = (String) ((JSONObject) arr.get(f)).get("nick_name");
                    benificiary_id_ = (String) ((JSONObject) arr.get(f)).get("benificiary_id");
                    acc_no_ = (String) ((JSONObject) arr.get(f)).get("acc_no");
                    branch_ = (String) ((JSONObject) arr.get(f)).get("branch");
                    group_name_ = (String) ((JSONObject) arr.get(f)).get("group_name");
                    group_id_ = (String) ((JSONObject) arr.get(f)).get("group_id");
                    inst_id_ = (String) ((JSONObject) arr.get(f)).get("inst_id");
                    inst_desc_ = (String) ((JSONObject) arr.get(f)).get("inst_desc");
                    priority_ = (String) ((JSONObject) arr.get(f)).get("priority");
                    visibility_ = (String) ((JSONObject) arr.get(f)).get("visibility");
                    status_ = (String) ((JSONObject) arr.get(f)).get("status");
                    name_ = (String) ((JSONObject) arr.get(f)).get("name");
                    benifi_bank_name_ = (String) ((JSONObject) arr.get(f)).get("benifi_bank_name");
                    branch_code_ = (String) ((JSONObject) arr.get(f)).get("branch_code");
                    swift_code_ = (String) ((JSONObject) arr.get(f)).get("swift_code");
                    email_add_ = (String) ((JSONObject) arr.get(f)).get("email_add");
                    phone_no_ = (String) ((JSONObject) arr.get(f)).get("phone_no");
                    staff_number_ = (String) ((JSONObject) arr.get(f)).get("staff_number");

                    getBenificiaryListRequest56.setAcc_no_(acc_no_, list, len);
                    getBenificiaryListRequest56.setBenifi_bank_name_(benifi_bank_name_, list, len);
                    getBenificiaryListRequest56.setBenificiary_id_(benificiary_id_, list, len);
                    getBenificiaryListRequest56.setBranch_(branch_, list, len);
                    getBenificiaryListRequest56.setBranch_code_(branch_code_, list, len);
                    getBenificiaryListRequest56.setEmail_add_(email_add_, list, len);
                    getBenificiaryListRequest56.setGroup_name_(group_name_, list, len);
                    getBenificiaryListRequest56.setGroup_id_(group_id_, list, len);
                    getBenificiaryListRequest56.setInst_desc_(inst_desc_, list, len);
                    getBenificiaryListRequest56.setName_(name_, list, len);
                    getBenificiaryListRequest56.setNick_name_(nick_name_, list, len);
                    getBenificiaryListRequest56.setPhone_no_(phone_no_, list, len);
                    getBenificiaryListRequest56.setPriority_(priority_, list, len);
                    getBenificiaryListRequest56.setStaff_number_(staff_number_, list, len);
                    getBenificiaryListRequest56.setStatus_(status_, list, len);
                    getBenificiaryListRequest56.setSwift_code_(swift_code_, list, len);
                    getBenificiaryListRequest56.setVisibility_(visibility_, list, len);
                    getBenificiaryListRequest56.setInst_id_(inst_id_, list, len);
                }
                request.setAttribute("getBenificiaryListRequest56", getBenificiaryListRequest56);

                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard_dummy.jsp");
                view.forward(request, response);
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 57
     */
    /*Post to ADD_LOAN_INFO_MAKER Request*/
    /**
     * protected void addLoanInfoMakerRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     * /**58
     */
    /*Post to GET_LOAN_INFO Request*/
    /**
     * protected void getLoanInfoRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     *
     * /**59
     */
    /*Post to GET_LOAN_INFO_LIST Request*/
    /**
     * protected void getLoanInfoListRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     *
     * /**60
     */
    /*Post to AUTH_LOAN_CHECKER Request*/
    /**
     * protected void authLoanCheckerRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     *
     * /**61
     */
    /*Post to ADD TRADE FINANCE MAKER Request*/
    //addTradeFinanceMakerRequest
    protected void atfm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type").trim();
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();

        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String corp_id = request.getParameter("corp_id").trim();
        String branch_name = request.getParameter("branch_name").trim();
        String trade_date = request.getParameter("trade_date").trim();
        String cust_name = request.getParameter("cust_name").trim();
        String cust_address = request.getParameter("cust_address").trim();
        String cust_com_ident_no = request.getParameter("cust_com_ident_no").trim();
        String currency = request.getParameter("currency").trim();
        String commencement_date = request.getParameter("commencement_date").trim();
        String pro_forma_invoice = request.getParameter("pro_forma_invoice").trim();
        String evi_contract_sale_doc = request.getParameter("evi_contract_sale_doc").trim();
        String purchase_order_doc = request.getParameter("purchase_order_doc").trim();
        String commercial_invoice_doc = request.getParameter("commercial_invoice_doc").trim();
        String transport_doc = request.getParameter("transport_doc").trim();
        String from_country = request.getParameter("from_country").trim();
        String to_country = request.getParameter("to_country").trim();
        String buyer_seller = request.getParameter("buyer_seller").trim();
        String date_shipped = request.getParameter("date_shipped").trim();
        String goods_desc = request.getParameter("goods_desc").trim();
        String carrier_name = request.getParameter("carrier_name").trim();
        String vessel_name = request.getParameter("vessel_name").trim();
        String benefi_name = request.getParameter("benefi_name").trim();
        String benefi_bank = request.getParameter("benefi_bank").trim();
        String benefi_refer_details = request.getParameter("benefi_refer_details").trim();
        String benefi_acc_no = request.getParameter("benefi_acc_no").trim();
        String charges = request.getParameter("charges").trim();
        String debit_acc_no = request.getParameter("debit_acc_no").trim();
        String acc_no = request.getParameter("acc_no").trim();
        String exchange_rate = request.getParameter("exchange_rate").trim();
        String intrest = request.getParameter("intrest").trim();
        String maturity_date = request.getParameter("maturity_date").trim();
        String reference_no = request.getParameter("reference_no").trim();
        String term = request.getParameter("term").trim();
        String supporting_doc = request.getParameter("supporting_doc").trim();
        String file_upload = request.getParameter("file_upload").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject trade_info = new JSONObject();
        trade_info.put("branch_name", branch_name);
        trade_info.put("trade_date", trade_date);
        trade_info.put("cust_name", cust_name);
        trade_info.put("cust_address", cust_address);
        trade_info.put("cust_com_ident_no", cust_com_ident_no);
        trade_info.put("currency", currency);
        trade_info.put("term", term);
        trade_info.put("commencement_date", commencement_date);
        trade_info.put("pro_forma_invoice", pro_forma_invoice);
        trade_info.put("evi_contract_sale_doc", evi_contract_sale_doc);
        trade_info.put("purchase_order_doc", purchase_order_doc);
        trade_info.put("commercial_invoice_doc", commercial_invoice_doc);
        trade_info.put("transport_doc", transport_doc);
        trade_info.put("from_country", from_country);
        trade_info.put("to_country", to_country);
        trade_info.put("buyer_seller", buyer_seller);
        trade_info.put("date_shipped", date_shipped);
        trade_info.put("goods_desc", goods_desc);
        trade_info.put("carrier_name", carrier_name);
        trade_info.put("vessel_name", vessel_name);
        trade_info.put("benefi_name", benefi_name);
        trade_info.put("benefi_bank", benefi_bank);
        trade_info.put("benefi_refer_details", benefi_refer_details);
        trade_info.put("benefi_acc_no", benefi_acc_no);
        trade_info.put("charges", charges);
        trade_info.put("debit_acc_no", debit_acc_no);
        trade_info.put("acc_no", acc_no);
        trade_info.put("exchange_rate", exchange_rate);
        trade_info.put("intrest", intrest);
        trade_info.put("maturity_date", maturity_date);
        trade_info.put("reference_no", reference_no);
        trade_info.put("supporting_doc", supporting_doc);
        trade_info.put("file_upload", file_upload);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("trade_info", trade_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 62
     */
    /*Post to GET_TRADE_LIST Request*/
    //getTradeListRequest
    protected void gtl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type").trim();
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();

        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject trade_info = new JSONObject();
        trade_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("trade_info", trade_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET_TRADE_LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 63
     */
    /*Post to GET_TRADE Request*/
    //getTradeRequest
    protected void gt(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type").trim();
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();

        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String corp_id = request.getParameter("corp_id").trim();
        String app_id = request.getParameter("app_id").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("corp_id", corp_id);

        JSONObject trade_info = new JSONObject();
        trade_info.put("app_id", app_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("trade_info", trade_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET_TRADE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 63
     */
    /*Post to ADD TRADE FINANCE MAKER Request*/
    /**
     * protected void addTradeFinanceMakerRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     *
     * /**64
     */
    /*Post to CORPORATE TRANSFER MAKER Request*/
    //corporateTransferMakerRequest
    protected void ctm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type").trim();
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String corp_id = request.getParameter("corp_id").trim();
        String txn_amount = request.getParameter("txn_amount").trim();
        String debit_acct = request.getParameter("debit_acct").trim();
        String crd_acct = request.getParameter("crd_acct").trim();
        String cr_br_code = request.getParameter("cr_br_code").trim();
        String remarks = request.getParameter("remarks").trim();
        String txn_cur = request.getParameter("txn_cur").trim();
        String txf_req_type = request.getParameter("txf_req_type").trim();
        String dr_acc_name = request.getParameter("dr_acc_name").trim();
        String cr_acc_name = request.getParameter("cr_acc_name").trim();
        String cr_txn_cur = request.getParameter("cr_txn_cur").trim();
        String cr_bnk_name = request.getParameter("cr_bnk_name").trim();
        String cr_br_name = request.getParameter("cr_br_name").trim();
        String bnk_addr = request.getParameter("bnk_addr").trim();
        String txf_type = request.getParameter("txf_type").trim();
        String cr_name = request.getParameter("cr_name").trim();
        String txf_doc1 = request.getParameter("txf_doc1").trim();
        String txf_doc2 = request.getParameter("txf_doc2").trim();
        String debit_date = request.getParameter("debit_date").trim();
        String cr_address = request.getParameter("cr_address").trim();
        String rec_country = request.getParameter("rec_country").trim();
        String txf_code = request.getParameter("txf_code").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("corp_id", corp_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject txn_info = new JSONObject();
        txn_info.put("txn_amount", txn_amount);
        txn_info.put("debit_acct", debit_acct);
        txn_info.put("crd_acct", crd_acct);
        txn_info.put("cr_br_code", cr_br_code);
        txn_info.put("remarks", remarks);
        txn_info.put("txn_cur", txn_cur);
        txn_info.put("txf_type", txf_type);
        txn_info.put("txf_req_type", txf_req_type);
        txn_info.put("dr_acc_name", dr_acc_name);
        txn_info.put("cr_acc_name", cr_acc_name);
        txn_info.put("cr_txn_cur", cr_txn_cur);
        txn_info.put("cr_bnk_name", cr_bnk_name);
        txn_info.put("cr_br_name", cr_br_name);
        txn_info.put("bnk_addr", bnk_addr);
        txn_info.put("cr_name", cr_name);
        txn_info.put("txf_doc1", txf_doc1);
        txn_info.put("txf_doc2", txf_doc2);
        txn_info.put("debit_date", debit_date);
        txn_info.put("cr_address", cr_address);
        txn_info.put("rec_country", rec_country);
        txn_info.put("txf_code", txf_code);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("txn_info", txn_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("CORPORATE TRANSFER MAKER - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONObject response_info = (JSONObject) (new JsonObjectParser()).jsonObj2(resp).get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            String resp_subcode_ = (String) response_info.get("resp_subcode");
            String session_id_ = (String) response_info.get("session_id");
            String resp_desc_ = (String) response_info.get("resp_desc");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                request.setAttribute("session_id_", session_id_);

                RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Corporate/dashboard_dummy.jsp");
                view.forward(request, response);
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 65
     */
    /*Post to CORPORATE TRANSFER CHECKER Request*/
    //corporateTransferCheckerRequest
    protected void ctc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("req_type").trim();
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String corp_id = request.getParameter("corp_id").trim();
        String txn_amount = request.getParameter("txn_amount").trim();
        String txn_id = request.getParameter("txn_id").trim();
        String debit_acct = request.getParameter("debit_acct").trim();
        String crd_acct = request.getParameter("crd_acct").trim();
        String cr_br_code = request.getParameter("cr_br_code").trim();
        String remarks = request.getParameter("remarks").trim();
        String txf_type = request.getParameter("txf_type").trim();
        String txf_req_type = request.getParameter("txf_req_type").trim();
        String dr_acc_name = request.getParameter("dr_acc_name").trim();
        String cr_acc_name = request.getParameter("cr_acc_name").trim();
        String cr_txn_cur = request.getParameter("cr_txn_cur").trim();
        String txn_cur = request.getParameter("txn_cur").trim();
        String cr_br_name = request.getParameter("cr_br_name").trim();
        String bnk_addr = request.getParameter("bnk_addr").trim();
        String cr_name = request.getParameter("cr_name").trim();
        String cr_bnk_name = request.getParameter("cr_bnk_name").trim();
        String txf_doc1 = request.getParameter("txf_doc1").trim();
        String txf_doc2 = request.getParameter("txf_doc2").trim();
        String debit_date = request.getParameter("debit_date").trim();
        String cr_address = request.getParameter("cr_address").trim();
        String rec_country = request.getParameter("rec_country").trim();
        String txf_code = request.getParameter("txf_code").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);
        user_info.put("corp_id", corp_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject txn_info = new JSONObject();
        txn_info.put("txn_amount", txn_amount);
        txn_info.put("txn_id", txn_id);
        txn_info.put("debit_acct", debit_acct);
        txn_info.put("crd_acct", crd_acct);
        txn_info.put("cr_br_code", cr_br_code);
        txn_info.put("remarks", remarks);
        txn_info.put("txn_cur", txn_cur);
        txn_info.put("txf_type", txf_type);
        txn_info.put("txf_req_type", txf_req_type);
        txn_info.put("dr_acc_name", dr_acc_name);
        txn_info.put("cr_acc_name", cr_acc_name);
        txn_info.put("cr_txn_cur", cr_txn_cur);
        txn_info.put("cr_bnk_name", cr_bnk_name);
        txn_info.put("cr_br_name", cr_br_name);
        txn_info.put("bnk_addr", bnk_addr);
        txn_info.put("cr_name", cr_name);
        txn_info.put("txf_doc1", txf_doc1);
        txn_info.put("txf_doc2", txf_doc2);
        txn_info.put("debit_date", debit_date);
        txn_info.put("cr_address", cr_address);
        txn_info.put("rec_country", rec_country);
        txn_info.put("txf_code", txf_code);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("txn_info", txn_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("CORPORATE TRANSFER CHECKER - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Corporate/dashboard.html");
            } else {

                response.sendRedirect("/Eapps/Corporate/index.jsp");
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /*Method to Send Request to server*/
    public String sendRequest(String req) throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        CloseableHttpResponse response = null;
        String EappsResponse = null;
        try {

            SSLContextBuilder builder = new SSLContextBuilder();
            builder.loadTrustMaterial(null, new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                    return true;
                }

            });

            SSLConnectionSocketFactory sslSF = new SSLConnectionSocketFactory(builder.build(),
                    SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

            CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslSF).build();

            HttpPost httpPost = new HttpPost(CorporateEndPoint.CORPORATE_ENDPOINT);

            StringEntity entity = new StringEntity(req);
            httpPost.setEntity(entity);

            response = httpclient.execute(httpPost);
            int code = response.getStatusLine().getStatusCode();

            EappsResponse = EntityUtils.toString(response.getEntity());

            System.out.println("EappsCore Response Status Code: " + code);

        } catch (UnsupportedEncodingException ex) {

        } catch (IOException ex) {

        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException ex) {

                }
            }
        }
        return EappsResponse;
    }

    public static GetForexListRequest35 getforex() {
        return getForexListRequest35;
    }

    public static CorpMyAccountsListRequest41 corpMyAccountsListReq41() {
        return corpMyAccountsListRequest41;
    }

}
