/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author Nzangi
 */
public class GetCardRequest44 {

    private String inst_id_,
            card_number_,
            cvv_,
            date_of_expiry_,
            card_type_,
            auth_desc_,
            status_,
            auth_status_,
            user_id_,
            corp_id_,
            channel_type_;

    /**
     * @return the inst_id_
     */
    public String getInst_id_() {
        return inst_id_;
    }

    /**
     * @param inst_id_ the inst_id_ to set
     */
    public void setInst_id_(String inst_id_) {
        this.inst_id_ = inst_id_;
    }

    /**
     * @return the card_number_
     */
    public String getCard_number_() {
        return card_number_;
    }

    /**
     * @param card_number_ the card_number_ to set
     */
    public void setCard_number_(String card_number_) {
        this.card_number_ = card_number_;
    }

    /**
     * @return the cvv_
     */
    public String getCvv_() {
        return cvv_;
    }

    /**
     * @param cvv_ the cvv_ to set
     */
    public void setCvv_(String cvv_) {
        this.cvv_ = cvv_;
    }

    /**
     * @return the date_of_expiry_
     */
    public String getDate_of_expiry_() {
        return date_of_expiry_;
    }

    /**
     * @param date_of_expiry_ the date_of_expiry_ to set
     */
    public void setDate_of_expiry_(String date_of_expiry_) {
        this.date_of_expiry_ = date_of_expiry_;
    }

    /**
     * @return the card_type_
     */
    public String getCard_type_() {
        return card_type_;
    }

    /**
     * @param card_type_ the card_type_ to set
     */
    public void setCard_type_(String card_type_) {
        this.card_type_ = card_type_;
    }

    /**
     * @return the auth_desc_
     */
    public String getAuth_desc_() {
        return auth_desc_;
    }

    /**
     * @param auth_desc_ the auth_desc_ to set
     */
    public void setAuth_desc_(String auth_desc_) {
        this.auth_desc_ = auth_desc_;
    }

    /**
     * @return the status_
     */
    public String getStatus_() {
        return status_;
    }

    /**
     * @param status_ the status_ to set
     */
    public void setStatus_(String status_) {
        this.status_ = status_;
    }

    /**
     * @return the auth_status_
     */
    public String getAuth_status_() {
        return auth_status_;
    }

    /**
     * @param auth_status_ the auth_status_ to set
     */
    public void setAuth_status_(String auth_status_) {
        this.auth_status_ = auth_status_;
    }

    /**
     * @return the user_id_
     */
    public String getUser_id_() {
        return user_id_;
    }

    /**
     * @param user_id_ the user_id_ to set
     */
    public void setUser_id_(String user_id_) {
        this.user_id_ = user_id_;
    }

    /**
     * @return the corp_id_
     */
    public String getCorp_id_() {
        return corp_id_;
    }

    /**
     * @param corp_id_ the corp_id_ to set
     */
    public void setCorp_id_(String corp_id_) {
        this.corp_id_ = corp_id_;
    }

    /**
     * @return the channel_type_
     */
    public String getChannel_type_() {
        return channel_type_;
    }

    /**
     * @param channel_type_ the channel_type_ to set
     */
    public void setChannel_type_(String channel_type_) {
        this.channel_type_ = channel_type_;
    }

}
