/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.utilities;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

/**
 *
 * @author Sam Kyalo
 */
public class RequestDecoder {
    private String target_string;
    
    public RequestDecoder (String target_string){
        this.target_string = target_string;
    } 
    
  
    public String [] getDecodedString(){
        
      /**  //Decode from Base64
        try{
        
            
         byte[] base64decodedBytes = Base64.getDecoder().decode(target_string); 
         
         String decoded_string = new String(base64decodedBytes, "utf-8");
         target_string = decoded_string.trim();
         }
        catch(UnsupportedEncodingException e){
         System.out.println("Error :" + e.getMessage());
      }
        */
        
        //Split string by "%#@!" and return String Array
        
        String [] dataArray = target_string.split("%#@!\\s*");
        
     return dataArray;
    }        

}
