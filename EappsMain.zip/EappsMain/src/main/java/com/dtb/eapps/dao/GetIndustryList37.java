/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nzangi
 */
public class GetIndustryList37 {

    List<List> arrLst = new ArrayList<>();

    private int t;
    private String industry_name_,
            industry_desc_,
            industry_id_;

    public GetIndustryList37(int t) {
        this.t = t;
    }

    /**
     * @return the industry_name_
     */
    public String getIndustry_name_() {
        return industry_name_;
    }

    /**
     * @param industry_name_ the industry_name_ to set
     */
    public void setIndustry_name_(String industry_name_, List<String> list) {
        this.industry_name_ = industry_name_;
        list.add(this.industry_name_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the industry_desc_
     */
    public String getIndustry_desc_() {
        return industry_desc_;
    }

    /**
     * @param industry_desc_ the industry_desc_ to set
     */
    public void setIndustry_desc_(String industry_desc_, List<String> list) {
        this.industry_desc_ = industry_desc_;
        list.add(this.industry_desc_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    /**
     * @return the industry_id_
     */
    public String getIndustry_id_() {
        return industry_id_;
    }

    /**
     * @param industry_id_ the industry_id_ to set
     */
    public void setIndustry_id_(String industry_id_, List<String> list) {
        this.industry_id_ = industry_id_;
        list.add(this.industry_id_);
        if (list.size() == t) {
            listHolder(list);
        }
    }

    public List<List> listHolder(List<String> list) {
        arrLst.add(list);
        System.out.println("____________________________________________________________________________________________\nCalled listHolder");
        System.out.println(arrLst.size());
        System.out.println("YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY\n" + arrLst.toString());
        return arrLst;
    }

}
