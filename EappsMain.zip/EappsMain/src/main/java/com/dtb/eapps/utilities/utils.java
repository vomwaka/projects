///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package com.dtb.eapps.utilities;
//import java.io.File;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.apache.logging.log4j.core.LoggerContext;
//
///**
// *
// * @author Sam Kyalo
// */
//public class utils {
//    
//       private static  Logger logger =LogManager.getLogger(utils.class.getName());
//
//   
//      
//       private static AppConstants appconst;
//       
//    public static void info(String info){
//        logger.info(info);
//    }
//    
//     public static void debugg(String debug){
//        logger.info(debug);
//    }
//      public static void Error(String err){
//        logger.error(err);
//    }
//      
//      public static void configurelogging(){
//   
//          
//            LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
//             File file = new File(appconst.getConf().getLog4jxmlpath());
// 
//       // this will force a reconfiguration
//           context.setConfigLocation(file.toURI());
//
//                logger.debug("Debug Test Message");
//                logger.info("Info Test Message");
//                logger.error("Error  Test message");
//
//      
//          
//     
//    }
//}
