/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author Nzangi
 */
public class GetForexRequest34 {

    private String inst_id_,
            forex_amount_,
            currency_,
            charges_,
            booking_id_,
            booking_date_,
            status_,
            auth_status_,
            user_id_,
            corp_id_,
            auth_desc_,
            reject_reason_;

    /**
     * @return the inst_id_
     */
    public String getInst_id_() {
        return inst_id_;
    }

    /**
     * @param inst_id_ the inst_id_ to set
     */
    public void setInst_id_(String inst_id_) {
        this.inst_id_ = inst_id_;
    }

    /**
     * @return the forex_amount_
     */
    public String getForex_amount_() {
        return forex_amount_;
    }

    /**
     * @param forex_amount_ the forex_amount_ to set
     */
    public void setForex_amount_(String forex_amount_) {
        this.forex_amount_ = forex_amount_;
    }

    /**
     * @return the currency_
     */
    public String getCurrency_() {
        return currency_;
    }

    /**
     * @param currency_ the currency_ to set
     */
    public void setCurrency_(String currency_) {
        this.currency_ = currency_;
    }

    /**
     * @return the charges_
     */
    public String getCharges_() {
        return charges_;
    }

    /**
     * @param charges_ the charges_ to set
     */
    public void setCharges_(String charges_) {
        this.charges_ = charges_;
    }

    /**
     * @return the booking_id_
     */
    public String getBooking_id_() {
        return booking_id_;
    }

    /**
     * @param booking_id_ the booking_id_ to set
     */
    public void setBooking_id_(String booking_id_) {
        this.booking_id_ = booking_id_;
    }

    /**
     * @return the booking_date_
     */
    public String getBooking_date_() {
        return booking_date_;
    }

    /**
     * @param booking_date_ the booking_date_ to set
     */
    public void setBooking_date_(String booking_date_) {
        this.booking_date_ = booking_date_;
    }

    /**
     * @return the status_
     */
    public String getStatus_() {
        return status_;
    }

    /**
     * @param status_ the status_ to set
     */
    public void setStatus_(String status_) {
        this.status_ = status_;
    }

    /**
     * @return the auth_status_
     */
    public String getAuth_status_() {
        return auth_status_;
    }

    /**
     * @param auth_status_ the auth_status_ to set
     */
    public void setAuth_status_(String auth_status_) {
        this.auth_status_ = auth_status_;
    }

    /**
     * @return the user_id_
     */
    public String getUser_id_() {
        return user_id_;
    }

    /**
     * @param user_id_ the user_id_ to set
     */
    public void setUser_id_(String user_id_) {
        this.user_id_ = user_id_;
    }

    /**
     * @return the corp_id_
     */
    public String getCorp_id_() {
        return corp_id_;
    }

    /**
     * @param corp_id_ the corp_id_ to set
     */
    public void setCorp_id_(String corp_id_) {
        this.corp_id_ = corp_id_;
    }

    /**
     * @return the auth_desc_
     */
    public String getAuth_desc_() {
        return auth_desc_;
    }

    /**
     * @param auth_desc_ the auth_desc_ to set
     */
    public void setAuth_desc_(String auth_desc_) {
        this.auth_desc_ = auth_desc_;
    }

    /**
     * @return the reject_reason_
     */
    public String getReject_reason_() {
        return reject_reason_;
    }

    /**
     * @param reject_reason_ the reject_reason_ to set
     */
    public void setReject_reason_(String reject_reason_) {
        this.reject_reason_ = reject_reason_;
    }

}
