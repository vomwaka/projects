/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author SAM
 */
public class AddCorpSelfReg {
   private String app_id;
   private  String user_pwd;

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public void setUser_pwd(String user_pwd) {
        this.user_pwd = user_pwd;
    }

    public String getApp_id() {
        return app_id;
    }

    public String getUser_pwd() {
        return user_pwd;
    }    
}
