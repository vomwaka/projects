/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.services;

/**
 *
 * @author User
 */
public class Security {
    
    
    public static String performSecurity (String request) {
        
        return "Security Stuff";
    }
    
}
