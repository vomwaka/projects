/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.endpoint;

/**
 *
 * @author Sam Kyalo
 */
public class CorporateEndPoint {
   public static final String CORPORATE_ENDPOINT = "https://212.22.175.13:9083/eapps_core";
    // public static final String CORPORATE_ENDPOINT = "http://54.165.85.125:8181/eapps_core";
    
}
