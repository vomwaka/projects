/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.servlets.retail.web;

import com.dtb.eapps.endpoint.CorporateEndPoint;
import com.dtb.eapps.utilities.RequestDecoder;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import com.dtb.eapps.servlets.corporate.web.JsonObjectParser;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import org.json.simple.JSONArray;

/**
 *
 * @author Sam Kyalo
 */
public class BusinessLogicOmwaks {

    JsonObjectParser jsonObjectParser;//=new JsonObjectParser();

    /**
     * 1
     */
    /*Post to INITIATE SESSION Request*/
    //initiateSessionRequest
    protected void is(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "initiate_session";
        String application_id = request.getParameter("application_id").trim();
        String channel_type = request.getParameter("channel_type").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();

        JSONObject application_info = new JSONObject();
        application_info.put("application_id", application_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();

        finalJsonObj.put("application_info", application_info);
        finalJsonObj.put("device_info", device_info);
        finalJsonObj.put("req_info", req_info);

        System.out.println("INITIATE SESSION 3435 - Gson Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());

            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");
            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");
            String session_id = (String) response_info.get("session_id");

            HttpSession session = request.getSession();
            session.setAttribute("session_id", session_id);

            System.out.println("Response Code: " + response_code);

            if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")) {
                response.sendRedirect("/Eapps/Retail/dashboard.jsp");
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
            }

            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            System.out.println("Response JSON: " + resp);
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 2
     */
    /*Post to GET RELATIONSHIP LIST Request*/
    //getRelationshipListRequest
    protected void grl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "get_rel_list";
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject user_info = new JSONObject();
        user_info.put("user_info", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject rel_info = new JSONObject();
        rel_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("rel_info", rel_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET RELATIONSHIP LIST - Gson Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {

            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    String inst_id_,
                            rel_id_,
                            rel_desc_,
                            rec_id_,
                            auth_status_,
                            maker_name_,
                            auth_desc_,
                            status_,
                            reject_reason_,
                            auth_name_,
                            maker_role_;
                    jsonObjectParser = new JsonObjectParser();
                    JSONArray arr = jsonObjectParser.parseJsonArray2(resp, "rel_list");

                    inst_id_ = (String) ((JSONObject) arr.get(0)).get("inst_id");
                    rel_id_ = (String) ((JSONObject) arr.get(0)).get("rel_id");
                    rel_desc_ = (String) ((JSONObject) arr.get(0)).get("rel_desc");
                    rec_id_ = (String) ((JSONObject) arr.get(0)).get("rec_id");
                    auth_status_ = (String) ((JSONObject) arr.get(0)).get("auth_status");
                    maker_name_ = (String) ((JSONObject) arr.get(0)).get("maker_name");
                    auth_desc_ = (String) ((JSONObject) arr.get(0)).get("auth_desc");
                    status_ = (String) ((JSONObject) arr.get(0)).get("status");
                    reject_reason_ = (String) ((JSONObject) arr.get(0)).get("reject_reason");
                    auth_name_ = (String) ((JSONObject) arr.get(0)).get("auth_name");
                    maker_role_ = (String) ((JSONObject) arr.get(0)).get("maker_role");

                    GetRelationshipList2 get_rel_list = new GetRelationshipList2();

                    get_rel_list.setAuth_desc_(auth_desc_);
                    get_rel_list.setAuth_name_(auth_name_);
                    get_rel_list.setAuth_status_(auth_status_);
                    get_rel_list.setInst_id_(inst_id_);
                    get_rel_list.setMaker_name_(maker_name_);
                    get_rel_list.setMaker_role_(maker_role_);
                    get_rel_list.setRec_id_(rec_id_);
                    get_rel_list.setReject_reason_(reject_reason_);
                    get_rel_list.setRel_desc_(rel_desc_);
                    get_rel_list.setRel_id_(rel_id_);
                    get_rel_list.setStatus_(status_);

                    request.setAttribute("get_rel_list", get_rel_list);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Eapps/Retail/dash_board.jsp");
                    view.forward(request, response);

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
//                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 3
     */
    /*Post to RELATIONSHIP CHECK Request*/
//        /relationshipCheckRequest
    protected void rc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "relationship_check";
        String channel_type = request.getParameter("channel_type").trim();
        String captch_value = request.getParameter("captch_value").trim();
        String captch_id = request.getParameter("captch_id").trim();
        String rel_desc = request.getParameter("rel_desc").trim();
        String rel_id = request.getParameter("rel_id").trim();
        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("rel_id", rel_id);
        req_info.put("rel_desc", rel_desc);
        req_info.put("captch_id", captch_id);
        req_info.put("captch_value", captch_value);
        req_info.put("inst_id", inst_id);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("RELATIONSHIP CHECK - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 4
     */
    /*Post to GET BRANCH NO USER LIST Request*/
    //getBranchNoUserListRequest
    protected void gbnul(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "get_branch_list_no_user";
        String channel_type = request.getParameter("channel_type").trim();
        String inst_id = request.getParameter("channel_type").trim();
        String session_id = request.getParameter("channel_type").trim();
        String device_sub_type = request.getParameter("channel_type").trim();
        String device_type = request.getParameter("channel_type").trim();
        String device_address = request.getParameter("channel_type").trim();
        String device_model = request.getParameter("channel_type").trim();

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject branch_info = new JSONObject();
        branch_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("branch_info", branch_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("GET BRANCH NO USER LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    jsonObjectParser = new JsonObjectParser();
                    JSONArray arr = jsonObjectParser.parseJsonArray2(resp, "branch_list");

                    String branch_code_,
                            branch_desc_,
                            maker_name_,
                            auth_name_,
                            status_,
                            rej_reason_,
                            auth_desc_,
                            inst_id_,
                            auth_status_,
                            rec_id_;

                    List<String> list = null;
                    GetBranchNoUserList5 getBranchNoUserList5 = new GetBranchNoUserList5();

                    int k = (Integer) ((JSONObject) arr.get(0)).size();
                    for (int t = 0; t < arr.size(); t++) {
                        list = new ArrayList<>();
                        branch_code_ = (String) ((JSONObject) arr.get(0)).get("branch_code");
                        branch_desc_ = (String) ((JSONObject) arr.get(0)).get("branch_desc");
                        maker_name_ = (String) ((JSONObject) arr.get(0)).get("maker_name");
                        auth_name_ = (String) ((JSONObject) arr.get(0)).get("auth_name");
                        status_ = (String) ((JSONObject) arr.get(0)).get("status");
                        rej_reason_ = (String) ((JSONObject) arr.get(0)).get("rej_reason");
                        auth_desc_ = (String) ((JSONObject) arr.get(0)).get("auth_desc");
                        inst_id_ = (String) ((JSONObject) arr.get(0)).get("inst_id");
                        auth_status_ = (String) ((JSONObject) arr.get(0)).get("auth_status");
                        rec_id_ = (String) ((JSONObject) arr.get(0)).get("rec_id");

                        getBranchNoUserList5.setAuth_desc_(auth_desc_, list, k);
                        getBranchNoUserList5.setAuth_name_(auth_name_, list, k);
                        getBranchNoUserList5.setAuth_status_(auth_status_, list, k);
                        getBranchNoUserList5.setBranch_code_(branch_code_, list, k);
                        getBranchNoUserList5.setBranch_desc_(branch_desc_, list, k);
                        getBranchNoUserList5.setInst_id_(inst_id_, list, k);
                        getBranchNoUserList5.setMaker_name_(maker_name_, list, k);
                        getBranchNoUserList5.setRec_id_(rec_id_, list, k);
                        getBranchNoUserList5.setRej_reason_(rej_reason_, list, k);
                        getBranchNoUserList5.setStatus_(status_, list, k);

                    }

                    request.setAttribute("get_branch_list_no_user", getBranchNoUserList5);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Eapps/Retail/dash_board.jsp");
                    view.forward(request, response);

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
//                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }
    }

    /**
     * 5
     */
    /*Post to CAPTCH NO USER Request*/
    //capthNoUserRequest
    protected void cnu(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "captcha_no_user";
        String channel_type = request.getParameter("channel_type").trim();
        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("inst_id", inst_id);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("CAPTCH NO USER - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    String captcha_info = (String) response_info.get("captcha_info");

                    request.setAttribute("captcha_no_user", captcha_info);
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Eapps/Retail/dash_board.jsp");
                    view.forward(request, response);

                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 6
     */
    /*Post to ADD CUST SELF REG Request*/
    //addCustSelfRegRequest
    protected void acsr(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "self_reg_cust";
        String channel_type = request.getParameter("channel_type").trim();
        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_role = request.getParameter("user_role").trim();
        String user_type = request.getParameter("user_type").trim();
        String first_name = request.getParameter("first_name").trim();
        String last_name = request.getParameter("last_name").trim();
        String other_name = request.getParameter("other_name").trim();
        String official_mob_number_1 = request.getParameter("official_mob_number_1").trim();
        String official_mob_number_2 = request.getParameter("official_mob_number_2").trim();
        String official_mail_1 = request.getParameter("official_mail_1").trim();
        String official_mail_2 = request.getParameter("official_mail_2").trim();
        String id_doc_1 = request.getParameter("id_doc_1").trim();
        String id_doc_1_desc = request.getParameter("id_doc_1_desc").trim();
        String id_doc_2 = request.getParameter("id_doc_2").trim();
        String id_doc_2_desc = request.getParameter("id_doc_2_desc").trim();
        String module_name = request.getParameter("module_name").trim();

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject kyc_info = new JSONObject();
        kyc_info.put("user_role", user_role);
        kyc_info.put("user_type", user_type);
        kyc_info.put("first_name", first_name);
        kyc_info.put("last_name", last_name);
        kyc_info.put("other_name", other_name);
        kyc_info.put("official_mob_number_1", official_mob_number_1);
        kyc_info.put("official_mob_number_2", official_mob_number_2);
        kyc_info.put("official_mail_1", official_mail_1);
        kyc_info.put("official_mail_2", official_mail_2);
        kyc_info.put("id_doc_1", id_doc_1);
        kyc_info.put("id_doc_1_desc", id_doc_1_desc);
        kyc_info.put("id_doc_2", id_doc_2);
        kyc_info.put("inst_id", inst_id);
        kyc_info.put("id_doc_2_desc", id_doc_2_desc);
        kyc_info.put("module_name", module_name);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("kyc_info", kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("ADD CUST SELF REG - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    String user_name = (String) response_info.get("user_name");
                    String user_pwd = (String) response_info.get("user_pwd");

                    String[] vals = {user_name, user_pwd};

                    request.setAttribute("self_reg_cust", vals);
                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Eapps/Retail/dash_board.jsp");
                    view.forward(request, response);

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
//                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }
    }

    /**
     * 7
     */
    /*Post to AUTH SELF REG USER Request*/
    //authSelfRegUserRequest
    protected void ausru(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "auth_user_checker";
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String user_id = request.getParameter("user_id").trim();
        String auth_status = request.getParameter("auth_status").trim();
        String auth_desc = request.getParameter("auth_desc").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("user_id", user_id);
        req_info.put("auth_status", auth_status);
        req_info.put("auth_desc", auth_desc);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("AUTH SELF REG USER - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 8
     */
    /*Post to OTP Request*/
    //otpRequest
    protected void otp(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "otp_req";
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String inst_id = request.getParameter("inst_id").trim();
        String otp_type = request.getParameter("otp_type").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject otp_info = new JSONObject();
        otp_info.put("inst_id", inst_id);
        otp_info.put("otp_type", otp_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("otp_info", otp_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("OTP - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }
    }

    /**
     * 9
     */
    /*Post to FIRST TIME LOGIN Request*/
    //firstTimeLoginRequest
    protected void ftl(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "cust_login";
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("FIRST TIME LOGIN - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }
    }

    /**
     * 10
     */
    /*Post to FORCE PASSWORD CHANGE Request*/
    //forcepasswordChangeRequest
    protected void fpc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "self_sec_reg";
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String user_role = request.getParameter("user_role").trim();
        String user_type = request.getParameter("user_type").trim();
        String sec_qes_1 = request.getParameter("sec_qes_1").trim();
        String sec_ans_1 = request.getParameter("sec_ans_1").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject kyc_info = new JSONObject();
        kyc_info.put("user_role", user_role);
        kyc_info.put("user_type", user_type);
        kyc_info.put("sec_qes_1", sec_qes_1);
        kyc_info.put("sec_ans_1", sec_ans_1);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("kyc_info", kyc_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("FORCE PASSWORD CHANGE - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }
    }

    /**
     * 11
     */
    /*Post to SELF REG CUSTOMER LOGIN Request*/
    //addCorporateContactKYCRequest
    protected void acckyc(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "cust_login";
        String channel_type = request.getParameter("channel_type").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_name = request.getParameter("user_name").trim();
        String user_pwd = request.getParameter("user_pwd").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("SELF REG CUSTOMER LOGIN - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    jsonObjectParser = new JsonObjectParser();
                    JSONArray arr = jsonObjectParser.parseJsonArray2(resp, "menu_list");

                    request.setAttribute("cust_login", arr);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Eapps/Retail/dash_board.jsp");
                    view.forward(request, response);

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
//                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }
    }

    /**
     * 12
     */
    /*Post to SECURITY QUSTION LIST Request*/
    //securityQuestionListRequest
    protected void sql(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = request.getParameter("user_pwd").trim();
        String channel_type = request.getParameter("user_pwd").trim();
        String user_name = request.getParameter("user_pwd").trim();
        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();
        String app_id = request.getParameter("app_id").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

        JSONObject security_info = new JSONObject();
        security_info.put("inst_id", inst_id);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("security_info", security_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("SECURITY QUSTION LIST - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    jsonObjectParser = new JsonObjectParser();
                    JSONArray arr = jsonObjectParser.parseJsonArray2(resp, "sec_list");

                    request.setAttribute("get_sec_list", arr);

                    RequestDispatcher view = request.getServletContext().getRequestDispatcher("/Eapps/Retail/dash_board.jsp");
                    view.forward(request, response);

                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {
                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 13
     */
    /*Post to MY ACCOUNT Request*/
    //myAccountRequest
    protected void ma(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "myaccounts";
        String channel_type = request.getParameter("app_id").trim();
        String user_name = request.getParameter("app_id").trim();
        String user_pwd = request.getParameter("app_id").trim();
        String session_id = request.getParameter("app_id").trim();
        String device_sub_type = request.getParameter("app_id").trim();
        String device_type = request.getParameter("app_id").trim();
        String device_address = request.getParameter("app_id").trim();
        String device_model = request.getParameter("app_id").trim();
        String br_code = request.getParameter("br_code").trim();
        String acct_no = request.getParameter("acct_no").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);
        req_info.put("br_code", br_code);
        req_info.put("acct_no", acct_no);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println("MY ACCOUNT - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(resp);
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject response_info = (JSONObject) jsonObject.get("resp_info");

            String response_code = (String) response_info.get("resp_code");
            String response_sub_code = (String) response_info.get("resp_subcode");

            System.out.println("Response Code: " + response_code);

            HttpSession session = request.getSession(false);
            if (session != null) {

                String SESSION_ID = (String) session.getAttribute("session_id");

                if (response_code.equalsIgnoreCase("000") && response_sub_code.equalsIgnoreCase("000")
                        && SESSION_ID.equals(session_id)) {

                    // response.sendRedirect("/Eapps/Retail/dashboard_dummy.jsp");
                    response.sendRedirect("/Eapps/Retail/dash_board.jsp");
                } else {

                    response.sendRedirect("/Eapps/Retail/index.jsp");
                }
            } else {

                response.sendRedirect("/Eapps/Retail/index.jsp");
                //request.getRequestDispatcher("/Eapps/Retail/index.jsp").include(request, response);  
            }
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }
    }

    /**
     * 14
     */
    /*Post to Myaccount list retail Request*/
    //myAccountListRequest
    protected void mal(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String req_type = "myaccounts_list";
        String channel_type = request.getParameter("channel_type").trim();
        String user_name = request.getParameter("user_name").trim();
        String inst_id = request.getParameter("inst_id").trim();
        String session_id = request.getParameter("session_id").trim();
        String device_sub_type = request.getParameter("device_sub_type").trim();
        String device_type = request.getParameter("device_type").trim();
        String device_address = request.getParameter("device_address").trim();
        String device_model = request.getParameter("device_model").trim();
        String user_pwd = request.getParameter("user_pwd").trim();

        JSONObject user_info = new JSONObject();
        user_info.put("user_name", user_name);
        user_info.put("user_pwd", user_pwd);

        JSONObject req_info = new JSONObject();
        req_info.put("req_type", req_type);
        req_info.put("channel_type", channel_type);

//        JSONObject corp_kyc_prod_info = new JSONObject();
//        corp_kyc_prod_info.put("inst_id", inst_id);
//        corp_kyc_prod_info.put("entity_type", entity_type);
//        corp_kyc_prod_info.put("rel_id", rel_id);
//        corp_kyc_prod_info.put("rel_id_desc", rel_id_desc);
//        corp_kyc_prod_info.put("rel_type", rel_type);
//        corp_kyc_prod_info.put("rel_sub_type", rel_sub_type);
//        corp_kyc_prod_info.put("rel_branch_code", rel_branch_code);

        JSONObject session_info = new JSONObject();
        session_info.put("session_id", session_id);

        JSONObject device_info = new JSONObject();
        device_info.put("device_sub_type", device_sub_type);
        device_info.put("device_type", device_type);
        device_info.put("device_address", device_address);
        device_info.put("device_model", device_model);

        JSONObject finalJsonObj = new JSONObject();
        finalJsonObj.put("user_info", user_info);
        finalJsonObj.put("req_info", req_info);
//        finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
        finalJsonObj.put("session_info", session_info);
        finalJsonObj.put("device_info", device_info);

        System.out.println(" Myaccount list retail - Json Data : " + finalJsonObj.toJSONString());
        //Send the request to EappsCore for Response
        try {
            String resp = sendRequest(finalJsonObj.toJSONString());
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println(resp);

        } catch (Exception e) {
            System.out.println("Send Request Error: " + e.getMessage().toString());

        }

    }

    /**
     * 15
     */
    /*Post to FUND_TRANSFER Request*/
    //fundTransferRequest
    protected void ft(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String staff_number = decodedString[11].trim();
            String passport_number = decodedString[12].trim();
            String official_phone_no = decodedString[13].trim();
            String official_mob_no = decodedString[14].trim();
            String official_email_id = decodedString[15].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject corp_kyc_role_info = new JSONObject();
            corp_kyc_role_info.put("inst_id", inst_id);
            corp_kyc_role_info.put("user_name", user_name);
            corp_kyc_role_info.put("staff_number", staff_number);
            corp_kyc_role_info.put("passport_number", passport_number);
            corp_kyc_role_info.put("official_phone_no", official_phone_no);
            corp_kyc_role_info.put("official_mob_no", official_mob_no);
            corp_kyc_role_info.put("official_email_id", official_email_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("corp_kyc_role_info", corp_kyc_role_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("FUND_TRANSFER - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 16
     */
    /*Post to Swift Code  Request*/
    //swiftCodeRequest 
    protected void sc(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String module_name = decodedString[11].trim();
            String corp_name = decodedString[12].trim();
            String corp_reg_no = decodedString[13].trim();
            String corp_addr = decodedString[14].trim();
            String corp_branch = decodedString[15].trim();
            String corp_reg = decodedString[16].trim();
            String industry = decodedString[17].trim();
            String corp_logo = decodedString[18].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject corp_kyc_prod_info = new JSONObject();
            corp_kyc_prod_info.put("inst_id", inst_id);
            corp_kyc_prod_info.put("module_name", module_name);
            corp_kyc_prod_info.put("corp_name", corp_name);
            corp_kyc_prod_info.put("corp_reg_no", corp_reg_no);
            corp_kyc_prod_info.put("corp_addr", corp_addr);
            corp_kyc_prod_info.put("corp_branch", corp_branch);
            corp_kyc_prod_info.put("corp_reg", corp_reg);
            corp_kyc_prod_info.put("industry", industry);
            corp_kyc_prod_info.put("corp_logo", corp_logo);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("Swift Code - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 17
     */
    /*Post to SWIFT_CODE_INTERNATIONAL_TRANSFER Request*/
    //swiftCodeInternationalTransferRequest
    protected void scit(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {
        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String session_id = decodedString[4].trim();
            String device_sub_type = decodedString[5].trim();
            String device_type = decodedString[6].trim();
            String device_address = decodedString[7].trim();
            String device_model = decodedString[8].trim();
            String user_pwd = decodedString[9].trim();
            String app_id = decodedString[10].trim();
            String auth_status = decodedString[11].trim();
            String auth_desc = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject app_info = new JSONObject();
            app_info.put("app_id", app_id);
            app_info.put("auth_status", auth_status);
            app_info.put("auth_desc", auth_desc);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("app_info", app_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("SWIFT_CODE_INTERNATIONAL_TRANSFER - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 18
     */
    /*Post to MINI_STATEMENT Request*/
    //miniStatementRequest
    protected void ms(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String app_id = decodedString[11].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject corp_info = new JSONObject();
            corp_info.put("inst_id", inst_id);
            corp_info.put("app_id", app_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("corp_kyc_info", corp_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("MINI_STATEMENT - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 19
     */
    /*Post to MYACCOUNT_RETAIL Request*/
    //myAccountRetailRequest
    protected void mar(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String user_role = decodedString[11].trim();
            String user_type = decodedString[12].trim();
            String user_id = decodedString[13].trim();
            String first_name = decodedString[14].trim();
            String last_name = decodedString[15].trim();
            String other_name = decodedString[16].trim();
            String staff_number = decodedString[17].trim();
            String official_mob_number_1 = decodedString[18].trim();
            String official_mob_number_2 = decodedString[19].trim();
            String official_mail_1 = decodedString[20].trim();
            String official_mail_2 = decodedString[21].trim();
            String id_doc_1 = decodedString[22].trim();
            String id_doc_1_desc = decodedString[23].trim();
            String id_doc_2 = decodedString[24].trim();
            String id_doc_2_desc = decodedString[25].trim();
            String id_doc_3 = decodedString[26].trim();
            String id_doc_3_desc = decodedString[27].trim();
            String id_doc_4 = decodedString[28].trim();
            String id_doc_4_desc = decodedString[29].trim();
            String id_doc_5 = decodedString[30].trim();
            String id_doc_5_desc = decodedString[31].trim();
            String phy_address = decodedString[32].trim();
            String postal_code = decodedString[33].trim();
            String gender = decodedString[34].trim();
            String dob = decodedString[35].trim();
            String country = decodedString[36].trim();
            String postal_address = decodedString[37].trim();
            String pwd_retry_count = decodedString[38].trim();
            String kin_first_name = decodedString[39].trim();
            String kin_last_name = decodedString[40].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject kyc_info = new JSONObject();
            kyc_info.put("user_role", user_role);
            kyc_info.put("user_type", user_type);
            kyc_info.put("user_id", user_id);
            kyc_info.put("first_name", first_name);
            kyc_info.put("last_name", last_name);
            kyc_info.put("other_name", other_name);
            kyc_info.put("staff_number", staff_number);
            kyc_info.put("official_mob_number_1", official_mob_number_1);
            kyc_info.put("official_mob_number_2", official_mob_number_2);
            kyc_info.put("official_mail_1", official_mail_1);
            kyc_info.put("official_mail_2", official_mail_2);
            kyc_info.put("id_doc_1", id_doc_1);
            kyc_info.put("id_doc_1_desc", id_doc_1_desc);
            kyc_info.put("id_doc_2", id_doc_2);
            kyc_info.put("id_doc_2_desc", id_doc_2_desc);
            kyc_info.put("id_doc_3", id_doc_3);
            kyc_info.put("id_doc_3_desc", id_doc_3_desc);
            kyc_info.put("id_doc_4", id_doc_4);
            kyc_info.put("id_doc_4_desc", id_doc_4_desc);
            kyc_info.put("id_doc_5", id_doc_5);
            kyc_info.put("id_doc_5_desc", id_doc_5_desc);
            kyc_info.put("phy_address", phy_address);
            kyc_info.put("postal_code", postal_code);
            kyc_info.put("gender", gender);
            kyc_info.put("dob", dob);
            kyc_info.put("country", country);
            kyc_info.put("postal_address", postal_address);
            kyc_info.put("pwd_retry_count", pwd_retry_count);
            kyc_info.put("inst_id", inst_id);
            kyc_info.put("kin_first_name", kin_first_name);
            kyc_info.put("kin_last_name", kin_last_name);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("kyc_info", kyc_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("MYACCOUNT_RETAIL - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 20
     */
    /*Post to ADD_GROUP_DETAIL Request*/
    //addGroupDetailRequest
    protected void agd(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String session_id = decodedString[4].trim();
            String device_sub_type = decodedString[5].trim();
            String device_type = decodedString[6].trim();
            String device_address = decodedString[7].trim();
            String device_model = decodedString[8].trim();
            String user_pwd = decodedString[9].trim();
            String user_id = decodedString[10].trim();
            String auth_status = decodedString[11].trim();
            String auth_desc = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("user_id", user_id);
            req_info.put("auth_status", auth_status);
            req_info.put("auth_desc", auth_desc);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD_GROUP_DETAIL - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 21
     */
    /*Post to ADD_CARD Request*/
//        /addCardRequest
    protected void ac(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD_CARD - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 22
     */
    /*Post to GET_CARD Request*/
    //getCardRequest
    protected void gc(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String eapps_corp_id = decodedString[11].trim();
            String entity_id = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject corp_kyc_prod_info = new JSONObject();
            corp_kyc_prod_info.put("inst_id", inst_id);
            corp_kyc_prod_info.put("eapps_corp_id", eapps_corp_id);
            corp_kyc_prod_info.put("entity_id", entity_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_CARD - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 23
     */
    /*Post to ADD_MAIL_SERV Request*/
    //addMailServRequest
    protected void ams(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject corp_kyc_prod_info = new JSONObject();
            corp_kyc_prod_info.put("inst_id", inst_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD_MAIL_SERV - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 24
     */
    /*Post to GET_MAIL_SERV Request*/
    //getMailServRequest
    protected void gms(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject corp_kyc_prod_info = new JSONObject();
            corp_kyc_prod_info.put("inst_id", inst_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("corp_kyc_prod_info", corp_kyc_prod_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_MAIL_SERV - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 25
     */
    /*Post to ADD_GROUP Request*/
    //addGroupRequest
    protected void ag(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String transfer_name = decodedString[11].trim();
            String transfer_type = decodedString[12].trim();
            String transfer_code = decodedString[13].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject tran_type_info = new JSONObject();
            tran_type_info.put("transfer_name", transfer_name);
            tran_type_info.put("transfer_type", transfer_type);
            tran_type_info.put("transfer_code", transfer_code);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("tran_type_info", tran_type_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD_GROUP - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 26
     */
    /*Post to ADD_INSURANCE Request*/
    //addInsuranceRequest
    protected void ai(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String transfer_name = decodedString[11].trim();
            String transfer_type = decodedString[12].trim();
            String transfer_code = decodedString[13].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject tran_type_info = new JSONObject();
            tran_type_info.put("transfer_name", transfer_name);
            tran_type_info.put("transfer_type", transfer_type);
            tran_type_info.put("transfer_code", transfer_code);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("tran_type_info", tran_type_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD_INSURANCE - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 27
     */
    /*Post to GET_INSURANCE Request*/
    //getInsuranceRequest
    protected void gi(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String transfer_name = decodedString[11].trim();
            String transfer_type = decodedString[12].trim();
            String transfer_code = decodedString[13].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject tran_type_info = new JSONObject();
            tran_type_info.put("transfer_name", transfer_name);
            tran_type_info.put("transfer_type", transfer_type);
            tran_type_info.put("transfer_code", transfer_code);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("tran_type_info", tran_type_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_INSURANCE - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 28
     */
    /*Post to ADD_STANDIN Request*/
    protected void as(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String transfer_name = decodedString[11].trim();
            String transfer_type = decodedString[12].trim();
            String transfer_code = decodedString[13].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject tran_type_info = new JSONObject();
            tran_type_info.put("transfer_name", transfer_name);
            tran_type_info.put("transfer_type", transfer_type);
            tran_type_info.put("transfer_code", transfer_code);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("tran_type_info", tran_type_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD_STANDIN - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 29
     */
    /*Post to EDIT_STANDIN Request*/
    //editStandinRequest
    protected void es(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String rec_id = decodedString[11].trim();
            String auth_status = decodedString[12].trim();
            String auth_desc = decodedString[13].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject tran_type_info = new JSONObject();
            tran_type_info.put("rec_id", rec_id);
            tran_type_info.put("auth_status", auth_status);
            tran_type_info.put("auth_desc", auth_desc);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("corp_kyc_info", tran_type_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("EDIT_STANDIN - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 30
     */
    /*Post to GET_STANDIN_LIST Request*/
    //getStandinListRequest
    protected void gsl(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String rec_id = decodedString[11].trim();
            String auth_status = decodedString[12].trim();
            String auth_desc = decodedString[13].trim();
            String rej_reason = decodedString[14].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject tran_type_info = new JSONObject();
            tran_type_info.put("rec_id", rec_id);
            tran_type_info.put("auth_status", auth_status);
            tran_type_info.put("auth_desc", auth_desc);
            tran_type_info.put("rej_reason", rej_reason);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("tran_type_info", tran_type_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_STANDIN_LIST - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 31
     */
    /*Post to ADD BENIFICIARY (FOR RETAIL)  Request*/
    //addBeneficiaryRequest
    protected void ab(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD BENIFICIARY (FOR RETAIL) - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 32
     */
    /*Post to GET BENIFICIARY LIST (FOR RETAIL) Request*/
    //getBenificiaryListRequest
    protected void gbl(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String rec_id = decodedString[11].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject tran_type_info = new JSONObject();
            tran_type_info.put("rec_id", rec_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("tran_type_info", tran_type_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET BENIFICIARY LIST (FOR RETAIL) - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 33
     */
    /*Post to BOOK FOREX Request*/
    protected void bookForexRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String txf_currency = decodedString[12].trim();
            String txf_amount = decodedString[13].trim();
            String txf_date = decodedString[14].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("corp_id", corp_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("inst_id", inst_id);
            req_info.put("txf_currency", txf_currency);
            req_info.put("txf_amount", txf_amount);
            req_info.put("txf_date", txf_date);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("BOOK FOREX - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 34
     */
    /*Post to GET FOREX  Request*/
    protected void getForexRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String forex_booking_id = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("corp_id", corp_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("inst_id", inst_id);

            JSONObject forex_info = new JSONObject();
            forex_info.put("forex_booking_id", forex_booking_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("forex_info", forex_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET FOREX - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 35
     */
    /*Post to GET FOREX LIST Request*/
    protected void getForexListRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("corp_id", corp_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("inst_id", inst_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET FOREX LIST - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 36
     */
    /*Post to GET_APPLICATION_DETAILS Request*/
    protected void getApplicationDetailsRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String session_id = decodedString[4].trim();
            String device_sub_type = decodedString[5].trim();
            String device_type = decodedString[6].trim();
            String device_address = decodedString[7].trim();
            String device_model = decodedString[8].trim();
            String user_pwd = decodedString[9].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_APPLICATION_DETAILS - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 37
     */
    /*Post to GET_INDUSTRY_LIST Request*/
    protected void getIndustryListRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String session_id = decodedString[4].trim();
            String device_sub_type = decodedString[5].trim();
            String device_type = decodedString[6].trim();
            String device_address = decodedString[7].trim();
            String device_model = decodedString[8].trim();
            String user_pwd = decodedString[9].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_INDUSTRY_LIST - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 38
     */
    /*Post to MY_ACCOUNT_CORPORATE Request*/
    protected void myAccountCorporateRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String br_code = decodedString[11].trim();
            String acct_no = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("br_code", br_code);
            req_info.put("acct_no", acct_no);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("MY_ACCOUNT_CORPORATE - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 39
     */
    /*Post to CORP_MY_ACCOUNTS Request*/
    protected void corpMyAccountsRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String session_id = decodedString[4].trim();
            String device_sub_type = decodedString[5].trim();
            String device_type = decodedString[6].trim();
            String device_address = decodedString[7].trim();
            String device_model = decodedString[8].trim();
            String user_pwd = decodedString[9].trim();
            String corp_id = decodedString[10].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("corp_id", corp_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("br_code", channel_type);
            req_info.put("acct_no", channel_type);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("CORP_MY_ACCOUNTS - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 40
     */
    /*Post to CORP_BALANCE Request*/
    protected void corpBalanceRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String session_id = decodedString[4].trim();
            String device_sub_type = decodedString[5].trim();
            String device_type = decodedString[6].trim();
            String device_address = decodedString[7].trim();
            String device_model = decodedString[8].trim();
            String user_pwd = decodedString[9].trim();
            String corp_id = decodedString[10].trim();
            String account_no = decodedString[11].trim();
            String branch_code = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("corp_id", corp_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject txn_info = new JSONObject();
            txn_info.put("account_no", account_no);
            txn_info.put("branch_code", branch_code);
            txn_info.put("channel_type", channel_type);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("txn_info", txn_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("CORP_BALANCE - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 41
     */
    /*Post to CORP_MY_ACCOUNTS_LIST Request*/
    protected void corpMyAccountsListRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String session_id = decodedString[4].trim();
            String device_sub_type = decodedString[5].trim();
            String device_type = decodedString[6].trim();
            String device_address = decodedString[7].trim();
            String device_model = decodedString[8].trim();
            String user_pwd = decodedString[9].trim();
            String corp_id = decodedString[10].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("corp_id", corp_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("CORP_MY_ACCOUNTS_LIST - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 42
     */
    /*Post to CORPORATE OTP Request*/
    protected void corporateOTPRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String module_name = decodedString[11].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject otp_info = new JSONObject();
            otp_info.put("inst_id", inst_id);
            otp_info.put("otp_type", module_name);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("otp_info", otp_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("CORPORATE OTP - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 43
     */
    /*Post to ADD_CARD Request*/
    protected void addCardRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String card_number = decodedString[12].trim();
            String cvv = decodedString[13].trim();
            String date_of_expiry = decodedString[14].trim();
            String card_type = decodedString[15].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject card_info = new JSONObject();
            card_info.put("inst_id", inst_id);
            card_info.put("card_number", card_number);
            card_info.put("cvv", cvv);
            card_info.put("date_of_expiry", date_of_expiry);
            card_info.put("card_number", card_number);
            card_info.put("card_type", card_type);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("card_info", card_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD_CARD - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 44
     */
    /*Post to GET_CARD Request*/
    protected void getCardRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String card_number = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject card_info = new JSONObject();
            card_info.put("card_number", card_number);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("card_info", card_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_CARD - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 45
     */
    /*Post to ADD_MAIL_SERV Request*/
    protected void addMailServRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String pickup_location = decodedString[11].trim();
            String parcel_description = decodedString[12].trim();
            String destination = decodedString[13].trim();
            String destination_branch = decodedString[14].trim();
            String date_of_pickup = decodedString[15].trim();
            String corp_id = decodedString[16].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject mail_info = new JSONObject();
            mail_info.put("pickup_location", pickup_location);
            mail_info.put("parcel_description", parcel_description);
            mail_info.put("destination", destination);
            mail_info.put("destination_branch", destination_branch);
            mail_info.put("date_of_pickup", date_of_pickup);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("mail_info", mail_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 46
     */
    /*Post to GET_MAIL_SERV Request*/
    protected void getMailServRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String app_id = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject mail_info = new JSONObject();
            mail_info.put("app_id", app_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("mail_info", mail_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_MAIL_SERV - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 47
     */
    /*Post to ADD_GROUP_CORP Request*/
    protected void addGroupCorpRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String group_name = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject group_info = new JSONObject();
            group_info.put("inst_id", inst_id);
            group_info.put("group_name", group_name);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("group_info", group_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD_GROUP_CORP - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 48
     */
    /*Post to ADD_INSURANCE Request*/
    /**
     * protected void addInsuranceRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * try { * RequestDecoder decoder = new RequestDecoder(requestBody); String
     * [] decodedString = decoder.getDecodedString(); String req_type =
     * decodedString[1].trim(); String channel_type = decodedString[2].trim();
     * String user_name = decodedString[3].trim(); * String inst_id =
     * decodedString[4].trim(); String session_id = decodedString[5].trim();
     * String device_sub_type = decodedString[6].trim(); String device_type =
     * decodedString[7].trim(); String device_address = decodedString[8].trim();
     * String device_model = decodedString[9].trim(); String user_pwd =
     * decodedString[10].trim(); String module_name = decodedString[11].trim();
     * String corp_name = decodedString[12].trim(); String corp_reg_no =
     * decodedString[13].trim(); String corp_addr = decodedString[14].trim();
     * String corp_branch = decodedString[15].trim(); String corp_reg =
     * decodedString[16].trim(); String industry = decodedString[17].trim();
     * String corp_logo = decodedString[18].trim();
     *
     *
     *
     *
     *
     * JSONObject user_info = new JSONObject(); user_info.put("user_name",
     * user_name); user_info.put("user_pwd", user_pwd);
     *
     * JSONObject req_info = new JSONObject(); req_info.put("req_type",
     * req_type); req_info.put("channel_type", channel_type);
     *
     * JSONObject corp_kyc_info = new JSONObject(); corp_kyc_info.put("inst_id",
     * inst_id); corp_kyc_info.put("module_name", module_name);
     * corp_kyc_info.put("corp_name", corp_name);
     * corp_kyc_info.put("corp_reg_no", corp_reg_no);
     * corp_kyc_info.put("corp_addr",corp_addr);
     * corp_kyc_info.put("corp_branch", corp_branch);
     * corp_kyc_info.put("corp_reg", corp_reg); corp_kyc_info.put("industry",
     * industry); corp_kyc_info.put("corp_logo", corp_logo);
     *
     *
     *
     *
     * JSONObject session_info = new JSONObject();
     * session_info.put("session_id", session_id);
     *
     * JSONObject device_info = new JSONObject();
     * device_info.put("device_sub_type", device_sub_type);
     * device_info.put("device_type", device_type);
     * device_info.put("device_address", device_address);
     * device_info.put("device_model", device_model);
     *
     * JSONObject finalJsonObj = new JSONObject();
     * finalJsonObj.put("user_info",user_info); finalJsonObj.put("req_info",
     * req_info); finalJsonObj.put("corp_kyc_info",corp_kyc_info);
     * finalJsonObj.put("session_info",session_info);
     * finalJsonObj.put("device_info", device_info);
     *
     *
     * System.out.println("ADD CORPORATE KYC - Json Data : " +
     * finalJsonObj.toJSONString()); //Send the request to EappsCore for
     * Response try{ String resp=sendRequest(finalJsonObj.toJSONString());
     * PrintWriter out = response.getWriter(); /* TODO output your page here.
     * You may use following sample code.
     */
    /**
     * out.println(resp);
     *
     *
     * }catch(Exception e){ System.out.println("Send Request Error: " +
     * e.getMessage().toString());
     *
     * }
     *
     * }
     * catch (ArrayIndexOutOfBoundsException e) { System.out.println("Request
     * Parameter Error: Array is out of Bounds"+e); }
     *
     *
     * }
     *
     *
     *
     * /**49
     */
    /*Post to GET_INSURANCE Request*/
    /**
     * protected void getInsuranceRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * try { * RequestDecoder decoder = new RequestDecoder(requestBody); String
     * [] decodedString = decoder.getDecodedString(); String req_type =
     * decodedString[1].trim(); String channel_type = decodedString[2].trim();
     * String user_name = decodedString[3].trim(); * String inst_id =
     * decodedString[4].trim(); String session_id = decodedString[5].trim();
     * String device_sub_type = decodedString[6].trim(); String device_type =
     * decodedString[7].trim(); String device_address = decodedString[8].trim();
     * String device_model = decodedString[9].trim(); String user_pwd =
     * decodedString[10].trim(); String module_name = decodedString[11].trim();
     * String corp_name = decodedString[12].trim(); String corp_reg_no =
     * decodedString[13].trim(); String corp_addr = decodedString[14].trim();
     * String corp_branch = decodedString[15].trim(); String corp_reg =
     * decodedString[16].trim(); String industry = decodedString[17].trim();
     * String corp_logo = decodedString[18].trim();
     *
     *
     *
     *
     *
     * JSONObject user_info = new JSONObject(); user_info.put("user_name",
     * user_name); user_info.put("user_pwd", user_pwd);
     *
     * JSONObject req_info = new JSONObject(); req_info.put("req_type",
     * req_type); req_info.put("channel_type", channel_type);
     *
     * JSONObject corp_kyc_info = new JSONObject(); corp_kyc_info.put("inst_id",
     * inst_id); corp_kyc_info.put("module_name", module_name);
     * corp_kyc_info.put("corp_name", corp_name);
     * corp_kyc_info.put("corp_reg_no", corp_reg_no);
     * corp_kyc_info.put("corp_addr",corp_addr);
     * corp_kyc_info.put("corp_branch", corp_branch);
     * corp_kyc_info.put("corp_reg", corp_reg); corp_kyc_info.put("industry",
     * industry); corp_kyc_info.put("corp_logo", corp_logo);
     *
     *
     *
     *
     * JSONObject session_info = new JSONObject();
     * session_info.put("session_id", session_id);
     *
     * JSONObject device_info = new JSONObject();
     * device_info.put("device_sub_type", device_sub_type);
     * device_info.put("device_type", device_type);
     * device_info.put("device_address", device_address);
     * device_info.put("device_model", device_model);
     *
     * JSONObject finalJsonObj = new JSONObject();
     * finalJsonObj.put("user_info",user_info); finalJsonObj.put("req_info",
     * req_info); finalJsonObj.put("corp_kyc_info",corp_kyc_info);
     * finalJsonObj.put("session_info",session_info);
     * finalJsonObj.put("device_info", device_info);
     *
     *
     * System.out.println("ADD CORPORATE KYC - Json Data : " +
     * finalJsonObj.toJSONString()); //Send the request to EappsCore for
     * Response try{ String resp=sendRequest(finalJsonObj.toJSONString());
     * PrintWriter out = response.getWriter(); /* TODO output your page here.
     * You may use following sample code.
     */
    /**
     * out.println(resp);
     *
     *
     * }catch(Exception e){ System.out.println("Send Request Error: " +
     * e.getMessage().toString());
     *
     * }
     *
     * }
     * catch (ArrayIndexOutOfBoundsException e) { System.out.println("Request
     * Parameter Error: Array is out of Bounds"+e); }
     *
     *
     * }
     *
     *
     * /**50
     */
    /*Post to ADD TERM DEPOSITE Request*/
    protected void addTermDepositeRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String amount = decodedString[12].trim();
            String rate = decodedString[13].trim();
            String deposite = decodedString[14].trim();
            String term_dep_type = decodedString[15].trim();
            String maturity_period = decodedString[16].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject term_dep_info = new JSONObject();
            term_dep_info.put("amount", amount);
            term_dep_info.put("rate", rate);
            term_dep_info.put("deposite", deposite);
            term_dep_info.put("term_dep_type", term_dep_type);
            term_dep_info.put("maturity_period", maturity_period);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("term_dep_info", term_dep_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD TERM DEPOSITE - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 51
     */
    /*Post to AUTH TERM DEPOSITE Request*/
    protected void authTermDepositeRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String app_id = decodedString[12].trim();
            String auth_status = decodedString[13].trim();
            String auth_desc = decodedString[14].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject term_dep_info = new JSONObject();
            term_dep_info.put("inst_id", inst_id);
            term_dep_info.put("corp_id", corp_id);
            term_dep_info.put("app_id", app_id);
            term_dep_info.put("auth_status", auth_status);
            term_dep_info.put("auth_desc", auth_desc);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("term_dep_info", term_dep_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("AUTH TERM DEPOSITE - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 52
     */
    /*Post to GET TERM DEPOSITE LIST Request*/
    protected void getTermDepositeListRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 53
     */
    /*Post to GET TERM DEPOSITE BASED CORP ID Request*/
    protected void getTermDepositeBasedCorpIDRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET TERM DEPOSITE BASED CORP ID - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 54
     */
    /*Post to GET TERM DEPOSITE  Request*/
    protected void getTermDepositeRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String app_id = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);
            req_info.put("app_id", app_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET TERM DEPOSITE  - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 55
     */
    /*Post to ADD BENIFICIARY  Request*/
    protected void addBenificiaryRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String entity_type = decodedString[12].trim();
            String rel_type = decodedString[13].trim();
            String priority = decodedString[14].trim();
            String rel_sub_id = decodedString[15].trim();
            String rel_sub_type = decodedString[16].trim();
            String rel_id_desc = decodedString[17].trim();
            String inst_desc = decodedString[18].trim();
            String group_id = decodedString[19].trim();
            String nick_name = decodedString[20].trim();
            String acc_no = decodedString[21].trim();
            String rel_branch = decodedString[22].trim();
            String visibility = decodedString[23].trim();
            String branch = decodedString[24].trim();
            String name = decodedString[25].trim();
            String benifi_bank_name = decodedString[26].trim();
            String branch_code = decodedString[27].trim();
            String swift_code = decodedString[28].trim();
            String email_add = decodedString[29].trim();
            String phone_no = decodedString[30].trim();
            String group_name = decodedString[31].trim();
            String staff_number = decodedString[32].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject corp_benifi_info = new JSONObject();
            corp_benifi_info.put("inst_id", inst_id);
            corp_benifi_info.put("corp_id", corp_id);
            corp_benifi_info.put("entity_type", entity_type);
            corp_benifi_info.put("rel_type", rel_type);
            corp_benifi_info.put("priority", priority);
            corp_benifi_info.put("rel_sub_id", rel_sub_id);
            corp_benifi_info.put("rel_sub_type", rel_sub_type);
            corp_benifi_info.put("rel_id_desc", rel_id_desc);
            corp_benifi_info.put("group_name", group_name);
            corp_benifi_info.put("inst_desc", inst_desc);
            corp_benifi_info.put("group_id", group_id);
            corp_benifi_info.put("nick_name", nick_name);
            corp_benifi_info.put("acc_no", acc_no);
            corp_benifi_info.put("rel_branch", rel_branch);
            corp_benifi_info.put("visibility", visibility);
            corp_benifi_info.put("nick_name", nick_name);
            corp_benifi_info.put("acc_no", acc_no);
            corp_benifi_info.put("branch", branch);
            corp_benifi_info.put("visibility", visibility);
            corp_benifi_info.put("name", name);
            corp_benifi_info.put("benifi_bank_name", benifi_bank_name);
            corp_benifi_info.put("branch_code", branch_code);
            corp_benifi_info.put("swift_code", swift_code);
            corp_benifi_info.put("email_add", email_add);
            corp_benifi_info.put("phone_no", phone_no);
            corp_benifi_info.put("staff_number", staff_number);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("corp_benifi_info", corp_benifi_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD BENIFICIARY - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 56
     */
    /*Post to GET BENIFICIARY LIST  Request*/
    protected void getBenificiaryListRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String rel_type = decodedString[11].trim();
            String corp_id = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject corp_benifi_info = new JSONObject();
            corp_benifi_info.put("inst_id", inst_id);
            corp_benifi_info.put("rel_type", rel_type);
            corp_benifi_info.put("corp_id", corp_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("corp_kyc_info", corp_benifi_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET BENIFICIARY LIST - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 57
     */
    /*Post to ADD_LOAN_INFO_MAKER Request*/
    /**
     * protected void addLoanInfoMakerRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     * /**58
     */
    /*Post to GET_LOAN_INFO Request*/
    /**
     * protected void getLoanInfoRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     *
     * /**59
     */
    /*Post to GET_LOAN_INFO_LIST Request*/
    /**
     * protected void getLoanInfoListRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     *
     * /**60
     */
    /*Post to AUTH_LOAN_CHECKER Request*/
    /**
     * protected void authLoanCheckerRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     *
     * /**61
     */
    /*Post to ADD TRADE FINANCE MAKER Request*/
    protected void addTradeFinanceMakerRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String branch_name = decodedString[12].trim();
            String trade_date = decodedString[13].trim();
            String cust_name = decodedString[14].trim();
            String cust_address = decodedString[15].trim();
            String cust_com_ident_no = decodedString[16].trim();
            String currency = decodedString[17].trim();
            String commencement_date = decodedString[18].trim();
            String pro_forma_invoice = decodedString[19].trim();
            String evi_contract_sale_doc = decodedString[20].trim();
            String purchase_order_doc = decodedString[21].trim();
            String commercial_invoice_doc = decodedString[22].trim();
            String transport_doc = decodedString[23].trim();
            String from_country = decodedString[24].trim();
            String to_country = decodedString[25].trim();
            String buyer_seller = decodedString[26].trim();
            String date_shipped = decodedString[27].trim();
            String goods_desc = decodedString[28].trim();
            String carrier_name = decodedString[29].trim();
            String vessel_name = decodedString[30].trim();
            String benefi_name = decodedString[31].trim();
            String benefi_bank = decodedString[32].trim();
            String benefi_refer_details = decodedString[33].trim();
            String benefi_acc_no = decodedString[34].trim();
            String charges = decodedString[35].trim();
            String debit_acc_no = decodedString[36].trim();
            String acc_no = decodedString[37].trim();
            String exchange_rate = decodedString[38].trim();
            String intrest = decodedString[39].trim();
            String maturity_date = decodedString[40].trim();
            String reference_no = decodedString[41].trim();
            String term = decodedString[42].trim();
            String supporting_doc = decodedString[43].trim();
            String file_upload = decodedString[44].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject trade_info = new JSONObject();
            trade_info.put("branch_name", branch_name);
            trade_info.put("trade_date", trade_date);
            trade_info.put("cust_name", cust_name);
            trade_info.put("cust_address", cust_address);
            trade_info.put("cust_com_ident_no", cust_com_ident_no);
            trade_info.put("currency", currency);
            trade_info.put("term", term);
            trade_info.put("commencement_date", commencement_date);
            trade_info.put("pro_forma_invoice", pro_forma_invoice);
            trade_info.put("evi_contract_sale_doc", evi_contract_sale_doc);
            trade_info.put("purchase_order_doc", purchase_order_doc);
            trade_info.put("commercial_invoice_doc", commercial_invoice_doc);
            trade_info.put("transport_doc", transport_doc);
            trade_info.put("from_country", from_country);
            trade_info.put("to_country", to_country);
            trade_info.put("buyer_seller", buyer_seller);
            trade_info.put("date_shipped", date_shipped);
            trade_info.put("goods_desc", goods_desc);
            trade_info.put("carrier_name", carrier_name);
            trade_info.put("vessel_name", vessel_name);
            trade_info.put("benefi_name", benefi_name);
            trade_info.put("benefi_bank", benefi_bank);
            trade_info.put("benefi_refer_details", benefi_refer_details);
            trade_info.put("benefi_acc_no", benefi_acc_no);
            trade_info.put("charges", charges);
            trade_info.put("debit_acc_no", debit_acc_no);
            trade_info.put("acc_no", acc_no);
            trade_info.put("exchange_rate", exchange_rate);
            trade_info.put("intrest", intrest);
            trade_info.put("maturity_date", maturity_date);
            trade_info.put("reference_no", reference_no);
            trade_info.put("supporting_doc", supporting_doc);
            trade_info.put("file_upload", file_upload);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("trade_info", trade_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("ADD CORPORATE KYC - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 62
     */
    /*Post to GET_TRADE_LIST Request*/
    protected void getTradeListRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject trade_info = new JSONObject();
            trade_info.put("inst_id", inst_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("trade_info", trade_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_TRADE_LIST - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 63
     */
    /*Post to GET_TRADE Request*/
    protected void getTradeRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();

            String inst_id = decodedString[4].trim();
            String session_id = decodedString[5].trim();
            String device_sub_type = decodedString[6].trim();
            String device_type = decodedString[7].trim();
            String device_address = decodedString[8].trim();
            String device_model = decodedString[9].trim();
            String user_pwd = decodedString[10].trim();
            String corp_id = decodedString[11].trim();
            String app_id = decodedString[12].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("inst_id", inst_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);
            req_info.put("corp_id", corp_id);

            JSONObject trade_info = new JSONObject();
            trade_info.put("app_id", app_id);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("trade_info", trade_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("GET_TRADE - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 63
     */
    /*Post to ADD TRADE FINANCE MAKER Request*/
    /**
     * protected void addTradeFinanceMakerRequest (String requestBody,
     * HttpServletResponse response) throws ServletException, IOException {
     *
     * }
     *
     *
     * /**64
     */
    /*Post to CORPORATE TRANSFER MAKER Request*/
    protected void corporateTransferMakerRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String session_id = decodedString[4].trim();
            String device_sub_type = decodedString[5].trim();
            String device_type = decodedString[6].trim();
            String device_address = decodedString[7].trim();
            String device_model = decodedString[8].trim();
            String user_pwd = decodedString[9].trim();
            String corp_id = decodedString[10].trim();
            String txn_amount = decodedString[11].trim();
            String debit_acct = decodedString[12].trim();
            String crd_acct = decodedString[13].trim();
            String cr_br_code = decodedString[14].trim();
            String remarks = decodedString[15].trim();
            String txn_cur = decodedString[16].trim();
            String txf_req_type = decodedString[17].trim();
            String dr_acc_name = decodedString[18].trim();
            String cr_acc_name = decodedString[19].trim();
            String cr_txn_cur = decodedString[20].trim();
            String cr_bnk_name = decodedString[21].trim();
            String cr_br_name = decodedString[22].trim();
            String bnk_addr = decodedString[23].trim();
            String txf_type = decodedString[24].trim();
            String cr_name = decodedString[25].trim();
            String txf_doc1 = decodedString[26].trim();
            String txf_doc2 = decodedString[27].trim();
            String debit_date = decodedString[28].trim();
            String cr_address = decodedString[29].trim();
            String rec_country = decodedString[30].trim();
            String txf_code = decodedString[31].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("corp_id", corp_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject txn_info = new JSONObject();
            txn_info.put("txn_amount", txn_amount);
            txn_info.put("debit_acct", debit_acct);
            txn_info.put("crd_acct", crd_acct);
            txn_info.put("cr_br_code", cr_br_code);
            txn_info.put("remarks", remarks);
            txn_info.put("txn_cur", txn_cur);
            txn_info.put("txf_type", txf_type);
            txn_info.put("txf_req_type", txf_req_type);
            txn_info.put("dr_acc_name", dr_acc_name);
            txn_info.put("cr_acc_name", cr_acc_name);
            txn_info.put("cr_txn_cur", cr_txn_cur);
            txn_info.put("cr_bnk_name", cr_bnk_name);
            txn_info.put("cr_br_name", cr_br_name);
            txn_info.put("bnk_addr", bnk_addr);
            txn_info.put("cr_name", cr_name);
            txn_info.put("txf_doc1", txf_doc1);
            txn_info.put("txf_doc2", txf_doc2);
            txn_info.put("debit_date", debit_date);
            txn_info.put("cr_address", cr_address);
            txn_info.put("rec_country", rec_country);
            txn_info.put("txf_code", txf_code);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("txn_info", txn_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("CORPORATE TRANSFER MAKER - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /**
     * 65
     */
    /*Post to CORPORATE TRANSFER CHECKER Request*/
    protected void corporateTransferCheckerRequest(String requestBody, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            RequestDecoder decoder = new RequestDecoder(requestBody);
            String[] decodedString = decoder.getDecodedString();
            String req_type = decodedString[1].trim();
            String channel_type = decodedString[2].trim();
            String user_name = decodedString[3].trim();
            String session_id = decodedString[4].trim();
            String device_sub_type = decodedString[5].trim();
            String device_type = decodedString[6].trim();
            String device_address = decodedString[7].trim();
            String device_model = decodedString[8].trim();
            String user_pwd = decodedString[9].trim();
            String corp_id = decodedString[10].trim();
            String txn_amount = decodedString[11].trim();
            String txn_id = decodedString[12].trim();
            String debit_acct = decodedString[13].trim();
            String crd_acct = decodedString[14].trim();
            String cr_br_code = decodedString[15].trim();
            String remarks = decodedString[16].trim();
            String txf_type = decodedString[17].trim();
            String txf_req_type = decodedString[18].trim();
            String dr_acc_name = decodedString[19].trim();
            String cr_acc_name = decodedString[20].trim();
            String cr_txn_cur = decodedString[21].trim();
            String txn_cur = decodedString[22].trim();
            String cr_br_name = decodedString[23].trim();
            String bnk_addr = decodedString[24].trim();
            String cr_name = decodedString[25].trim();
            String cr_bnk_name = decodedString[26].trim();
            String txf_doc1 = decodedString[27].trim();
            String txf_doc2 = decodedString[28].trim();
            String debit_date = decodedString[29].trim();
            String cr_address = decodedString[30].trim();
            String rec_country = decodedString[31].trim();
            String txf_code = decodedString[32].trim();

            JSONObject user_info = new JSONObject();
            user_info.put("user_name", user_name);
            user_info.put("user_pwd", user_pwd);
            user_info.put("corp_id", corp_id);

            JSONObject req_info = new JSONObject();
            req_info.put("req_type", req_type);
            req_info.put("channel_type", channel_type);

            JSONObject txn_info = new JSONObject();
            txn_info.put("txn_amount", txn_amount);
            txn_info.put("txn_id", txn_id);
            txn_info.put("debit_acct", debit_acct);
            txn_info.put("crd_acct", crd_acct);
            txn_info.put("cr_br_code", cr_br_code);
            txn_info.put("remarks", remarks);
            txn_info.put("txn_cur", txn_cur);
            txn_info.put("txf_type", txf_type);
            txn_info.put("txf_req_type", txf_req_type);
            txn_info.put("dr_acc_name", dr_acc_name);
            txn_info.put("cr_acc_name", cr_acc_name);
            txn_info.put("cr_txn_cur", cr_txn_cur);
            txn_info.put("cr_bnk_name", cr_bnk_name);
            txn_info.put("cr_br_name", cr_br_name);
            txn_info.put("bnk_addr", bnk_addr);
            txn_info.put("cr_name", cr_name);
            txn_info.put("txf_doc1", txf_doc1);
            txn_info.put("txf_doc2", txf_doc2);
            txn_info.put("debit_date", debit_date);
            txn_info.put("cr_address", cr_address);
            txn_info.put("rec_country", rec_country);
            txn_info.put("txf_code", txf_code);

            JSONObject session_info = new JSONObject();
            session_info.put("session_id", session_id);

            JSONObject device_info = new JSONObject();
            device_info.put("device_sub_type", device_sub_type);
            device_info.put("device_type", device_type);
            device_info.put("device_address", device_address);
            device_info.put("device_model", device_model);

            JSONObject finalJsonObj = new JSONObject();
            finalJsonObj.put("user_info", user_info);
            finalJsonObj.put("req_info", req_info);
            finalJsonObj.put("txn_info", txn_info);
            finalJsonObj.put("session_info", session_info);
            finalJsonObj.put("device_info", device_info);

            System.out.println("CORPORATE TRANSFER CHECKER - Json Data : " + finalJsonObj.toJSONString());
            //Send the request to EappsCore for Response
            try {
                String resp = sendRequest(finalJsonObj.toJSONString());
                PrintWriter out = response.getWriter();
                /* TODO output your page here. You may use following sample code. */
                out.println(resp);

            } catch (Exception e) {
                System.out.println("Send Request Error: " + e.getMessage().toString());

            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Request Parameter Error: Array is out of Bounds" + e);
        }

    }

    /*Method to Send Request to server*/
    public String sendRequest(String req) throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        CloseableHttpResponse response = null;
        String EappsResponse = null;
        try {

            SSLContextBuilder builder = new SSLContextBuilder();
            builder.loadTrustMaterial(null, new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                    return true;
                }

            });

            SSLConnectionSocketFactory sslSF = new SSLConnectionSocketFactory(builder.build(),
                    SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

            CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslSF).build();

            HttpPost httpPost = new HttpPost(CorporateEndPoint.CORPORATE_ENDPOINT);

            StringEntity entity = new StringEntity(req);
            httpPost.setEntity(entity);

            response = httpclient.execute(httpPost);
            int code = response.getStatusLine().getStatusCode();

            EappsResponse = EntityUtils.toString(response.getEntity());

            System.out.println("EappsCore Response Status Code: " + code);

        } catch (UnsupportedEncodingException ex) {
            // Logger.getLogger(ProcessMpesaCheckout .class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            // Logger.getLogger(ProcessMpesaCheckout .class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException ex) {
                    //   Logger.getLogger(ProcessMpesaCheckout .class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return EappsResponse;
    }

}
