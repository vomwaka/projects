/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.servlets.retail.web;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nzangi
 */
public class GetBranchNoUserList5 {

    private String branch_code_,
            branch_desc_,
            maker_name_,
            auth_name_,
            status_,
            rej_reason_,
            auth_desc_,
            inst_id_,
            auth_status_,
            rec_id_;
    List<List> listMain = new ArrayList<>();

    /**
     * @return the branch_code_
     */
    public String getBranch_code_() {
        return branch_code_;
    }

    /**
     * @param branch_code_ the branch_code_ to set
     */
    public void setBranch_code_(String branch_code_, List<String> list, int len) {
        this.branch_code_ = branch_code_;
        list.add(this.branch_code_);
        if(list.size()==len){
            addToListMain(list);
        }
    }

    /**
     * @return the branch_desc_
     */
    public String getBranch_desc_() {
        return branch_desc_;
    }

    /**
     * @param branch_desc_ the branch_desc_ to set
     */
    public void setBranch_desc_(String branch_desc_, List<String> list, int len) {
        this.branch_desc_ = branch_desc_;
    }

    /**
     * @return the maker_name_
     */
    public String getMaker_name_() {
        return maker_name_;
    }

    /**
     * @param maker_name_ the maker_name_ to set
     */
    public void setMaker_name_(String maker_name_, List<String> list, int len) {
        this.maker_name_ = maker_name_;
    }

    /**
     * @return the auth_name_
     */
    public String getAuth_name_() {
        return auth_name_;
    }

    /**
     * @param auth_name_ the auth_name_ to set
     */
    public void setAuth_name_(String auth_name_, List<String> list, int len) {
        this.auth_name_ = auth_name_;
    }

    /**
     * @return the status_
     */
    public String getStatus_() {
        return status_;
    }

    /**
     * @param status_ the status_ to set
     */
    public void setStatus_(String status_, List<String> list, int len) {
        this.status_ = status_;
    }

    /**
     * @return the rej_reason_
     */
    public String getRej_reason_() {
        return rej_reason_;
    }

    /**
     * @param rej_reason_ the rej_reason_ to set
     */
    public void setRej_reason_(String rej_reason_, List<String> list, int len) {
        this.rej_reason_ = rej_reason_;
    }

    /**
     * @return the auth_desc_
     */
    public String getAuth_desc_() {
        return auth_desc_;
    }

    /**
     * @param auth_desc_ the auth_desc_ to set
     */
    public void setAuth_desc_(String auth_desc_, List<String> list, int len) {
        this.auth_desc_ = auth_desc_;
    }

    /**
     * @return the inst_id_
     */
    public String getInst_id_() {
        return inst_id_;
    }

    /**
     * @param inst_id_ the inst_id_ to set
     */
    public void setInst_id_(String inst_id_, List<String> list, int len) {
        this.inst_id_ = inst_id_;
    }

    /**
     * @return the auth_status_
     */
    public String getAuth_status_() {
        return auth_status_;
    }

    /**
     * @param auth_status_ the auth_status_ to set
     */
    public void setAuth_status_(String auth_status_, List<String> list, int len) {
        this.auth_status_ = auth_status_;
    }

    /**
     * @return the rec_id_
     */
    public String getRec_id_() {
        return rec_id_;
    }

    /**
     * @param rec_id_ the rec_id_ to set
     */
    public void setRec_id_(String rec_id_, List<String> list, int len) {
        this.rec_id_ = rec_id_;
    }

    public List addToListMain(List<String> list) {
        listMain.add(list);
        return listMain;
    }

}
