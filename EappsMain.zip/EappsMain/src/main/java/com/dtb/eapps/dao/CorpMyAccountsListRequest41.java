/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nzangi
 */
public class CorpMyAccountsListRequest41 {

    private String resp_code_,
            resp_subcode_,
            session_id_,
            resp_desc_,
            rel_type_,
            rel_id_,
            rel_sub_type_,
            br_id_;
    List<List> lHolder = new ArrayList();

    /**
     * @return the resp_code_
     */
    public String getResp_code_() {
        return resp_code_;
    }

    /**
     * @param resp_code_ the resp_code_ to set
     */
    public void setResp_code_(String resp_code_) {
        this.resp_code_ = resp_code_;
    }

    /**
     * @return the resp_subcode_
     */
    public String getResp_subcode_() {
        return resp_subcode_;
    }

    /**
     * @param resp_subcode_ the resp_subcode_ to set
     */
    public void setResp_subcode_(String resp_subcode_) {
        this.resp_subcode_ = resp_subcode_;
    }

    /**
     * @return the session_id_
     */
    public String getSession_id_() {
        return session_id_;
    }

    /**
     * @param session_id_ the session_id_ to set
     */
    public void setSession_id_(String session_id_) {
        this.session_id_ = session_id_;
    }

    /**
     * @return the resp_desc_
     */
    public String getResp_desc_() {
        return resp_desc_;
    }

    /**
     * @param resp_desc_ the resp_desc_ to set
     */
    public void setResp_desc_(String resp_desc_) {
        this.resp_desc_ = resp_desc_;
    }

    /**
     * @return the rel_type_
     */
    public String getRel_type_() {
        return rel_type_;
    }

    /**
     * @param rel_type_ the rel_type_ to set
     */
    public void setRel_type_(String rel_type_, List<String> list, int t) {
        this.rel_type_ = rel_type_;
        list.add(this.rel_id_);
        if (list.size() == t) {
            holderList(list);
        }
    }

    /**
     * @return the rel_id_
     */
    public String getRel_id_() {
        return rel_id_;
    }

    /**
     * @param rel_id_ the rel_id_ to set
     */
    public void setRel_id_(String rel_id_, List<String> list, int t) {
        this.rel_id_ = rel_id_;
        list.add(this.rel_id_);
        if (list.size() == t) {
            holderList(list);
        }
    }

    /**
     * @return the rel_sub_type_
     */
    public String getRel_sub_type_() {
        return rel_sub_type_;
    }

    /**
     * @param rel_sub_type_ the rel_sub_type_ to set
     */
    public void setRel_sub_type_(String rel_sub_type_, List<String> list, int t) {
        this.rel_sub_type_ = rel_sub_type_;
        list.add(this.rel_sub_type_);
        if (list.size() == t) {
            holderList(list);
        }
    }

    /**
     * @return the br_id_
     */
    public String getBr_id_() {
        return br_id_;
    }

    /**
     * @param br_id_ the br_id_ to set
     */
    public void setBr_id_(String br_id_, List<String> list, int t) {
        this.br_id_ = br_id_;
        list.add(this.br_id_);
        if (list.size() == t) {
            holderList(list);
        }
    }

    public List<List> holderList(List<String> list) {
        lHolder.add(list);
        return lHolder;
    }

    public List<List> getMainlst() {
        return lHolder;
    }

}
