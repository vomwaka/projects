/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author Nzangi
 */
public class CorpMyAccountsRequest39 {

    private String resp_code_,
            resp_subcode_,
            session_id_,
            resp_desc_,
            consolidated_balance_,
            tran_date_,
            tran_time_,
            acct_type_,
            acct_number_,
            acct_desc_,
            total_balance_,
            last_mon_stmt_,
            opening_balance_,
            las_dr_act_,
            las_cr_act_,
            cr_turn_over_,
            dr_turn_over_,
            branch_,
            sweep_amt_;

    /**
     * @return the resp_code_
     */
    public String getResp_code_() {
        return resp_code_;
    }

    /**
     * @param resp_code_ the resp_code_ to set
     */
    public void setResp_code_(String resp_code_) {
        this.resp_code_ = resp_code_;
    }

    /**
     * @return the resp_subcode_
     */
    public String getResp_subcode_() {
        return resp_subcode_;
    }

    /**
     * @param resp_subcode_ the resp_subcode_ to set
     */
    public void setResp_subcode_(String resp_subcode_) {
        this.resp_subcode_ = resp_subcode_;
    }

    /**
     * @return the session_id_
     */
    public String getSession_id_() {
        return session_id_;
    }

    /**
     * @param session_id_ the session_id_ to set
     */
    public void setSession_id_(String session_id_) {
        this.session_id_ = session_id_;
    }

    /**
     * @return the resp_desc_
     */
    public String getResp_desc_() {
        return resp_desc_;
    }

    /**
     * @param resp_desc_ the resp_desc_ to set
     */
    public void setResp_desc_(String resp_desc_) {
        this.resp_desc_ = resp_desc_;
    }

    /**
     * @return the consolidated_balance_
     */
    public String getConsolidated_balance_() {
        return consolidated_balance_;
    }

    /**
     * @param consolidated_balance_ the consolidated_balance_ to set
     */
    public void setConsolidated_balance_(String consolidated_balance_) {
        this.consolidated_balance_ = consolidated_balance_;
    }

    /**
     * @return the tran_date_
     */
    public String getTran_date_() {
        return tran_date_;
    }

    /**
     * @param tran_date_ the tran_date_ to set
     */
    public void setTran_date_(String tran_date_) {
        this.tran_date_ = tran_date_;
    }

    /**
     * @return the tran_time_
     */
    public String getTran_time_() {
        return tran_time_;
    }

    /**
     * @param tran_time_ the tran_time_ to set
     */
    public void setTran_time_(String tran_time_) {
        this.tran_time_ = tran_time_;
    }

    /**
     * @return the acct_type_
     */
    public String getAcct_type_() {
        return acct_type_;
    }

    /**
     * @param acct_type_ the acct_type_ to set
     */
    public void setAcct_type_(String acct_type_) {
        this.acct_type_ = acct_type_;
    }

    /**
     * @return the acct_number_
     */
    public String getAcct_number_() {
        return acct_number_;
    }

    /**
     * @param acct_number_ the acct_number_ to set
     */
    public void setAcct_number_(String acct_number_) {
        this.acct_number_ = acct_number_;
    }

    /**
     * @return the acct_desc_
     */
    public String getAcct_desc_() {
        return acct_desc_;
    }

    /**
     * @param acct_desc_ the acct_desc_ to set
     */
    public void setAcct_desc_(String acct_desc_) {
        this.acct_desc_ = acct_desc_;
    }

    /**
     * @return the total_balance_
     */
    public String getTotal_balance_() {
        return total_balance_;
    }

    /**
     * @param total_balance_ the total_balance_ to set
     */
    public void setTotal_balance_(String total_balance_) {
        this.total_balance_ = total_balance_;
    }

    /**
     * @return the last_mon_stmt_
     */
    public String getLast_mon_stmt_() {
        return last_mon_stmt_;
    }

    /**
     * @param last_mon_stmt_ the last_mon_stmt_ to set
     */
    public void setLast_mon_stmt_(String last_mon_stmt_) {
        this.last_mon_stmt_ = last_mon_stmt_;
    }

    /**
     * @return the opening_balance_
     */
    public String getOpening_balance_() {
        return opening_balance_;
    }

    /**
     * @param opening_balance_ the opening_balance_ to set
     */
    public void setOpening_balance_(String opening_balance_) {
        this.opening_balance_ = opening_balance_;
    }

    /**
     * @return the las_dr_act_
     */
    public String getLas_dr_act_() {
        return las_dr_act_;
    }

    /**
     * @param las_dr_act_ the las_dr_act_ to set
     */
    public void setLas_dr_act_(String las_dr_act_) {
        this.las_dr_act_ = las_dr_act_;
    }

    /**
     * @return the las_cr_act_
     */
    public String getLas_cr_act_() {
        return las_cr_act_;
    }

    /**
     * @param las_cr_act_ the las_cr_act_ to set
     */
    public void setLas_cr_act_(String las_cr_act_) {
        this.las_cr_act_ = las_cr_act_;
    }

    /**
     * @return the cr_turn_over_
     */
    public String getCr_turn_over_() {
        return cr_turn_over_;
    }

    /**
     * @param cr_turn_over_ the cr_turn_over_ to set
     */
    public void setCr_turn_over_(String cr_turn_over_) {
        this.cr_turn_over_ = cr_turn_over_;
    }

    /**
     * @return the dr_turn_over_
     */
    public String getDr_turn_over_() {
        return dr_turn_over_;
    }

    /**
     * @param dr_turn_over_ the dr_turn_over_ to set
     */
    public void setDr_turn_over_(String dr_turn_over_) {
        this.dr_turn_over_ = dr_turn_over_;
    }

    /**
     * @return the branch_
     */
    public String getBranch_() {
        return branch_;
    }

    /**
     * @param branch_ the branch_ to set
     */
    public void setBranch_(String branch_) {
        this.branch_ = branch_;
    }

    /**
     * @return the sweep_amt_
     */
    public String getSweep_amt_() {
        return sweep_amt_;
    }

    /**
     * @param sweep_amt_ the sweep_amt_ to set
     */
    public void setSweep_amt_(String sweep_amt_) {
        this.sweep_amt_ = sweep_amt_;
    }

}
