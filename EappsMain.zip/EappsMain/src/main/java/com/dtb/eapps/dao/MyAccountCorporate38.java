/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author Nzangi
 */
public class MyAccountCorporate38 {

    private String resp_code_,
            resp_subcode_,
            session_id_,
            resp_desc_,
            consolidated_balance_,
            tran_date_,
            tran_time_,
            acct_type_,
            acct_number,
            acct_desc,
            total_balance,
            last_mon_stmt,
            opening_balance,
            las_dr_act,
            las_cr_act,
            cr_turn_over,
            dr_turn_over,
            branch,
            sweep_amt,
            chq_flag,
            sig_name,
            sig_limit,
            sig_type;

    /**
     * @return the resp_code_
     */
    public String getResp_code_() {
        return resp_code_;
    }

    /**
     * @param resp_code_ the resp_code_ to set
     */
    public void setResp_code_(String resp_code_) {
        this.resp_code_ = resp_code_;
    }

    /**
     * @return the resp_subcode_
     */
    public String getResp_subcode_() {
        return resp_subcode_;
    }

    /**
     * @param resp_subcode_ the resp_subcode_ to set
     */
    public void setResp_subcode_(String resp_subcode_) {
        this.resp_subcode_ = resp_subcode_;
    }

    /**
     * @return the session_id_
     */
    public String getSession_id_() {
        return session_id_;
    }

    /**
     * @param session_id_ the session_id_ to set
     */
    public void setSession_id_(String session_id_) {
        this.session_id_ = session_id_;
    }

    /**
     * @return the resp_desc_
     */
    public String getResp_desc_() {
        return resp_desc_;
    }

    /**
     * @param resp_desc_ the resp_desc_ to set
     */
    public void setResp_desc_(String resp_desc_) {
        this.resp_desc_ = resp_desc_;
    }

    /**
     * @return the consolidated_balance_
     */
    public String getConsolidated_balance_() {
        return consolidated_balance_;
    }

    /**
     * @param consolidated_balance_ the consolidated_balance_ to set
     */
    public void setConsolidated_balance_(String consolidated_balance_) {
        this.consolidated_balance_ = consolidated_balance_;
    }

    /**
     * @return the tran_date_
     */
    public String getTran_date_() {
        return tran_date_;
    }

    /**
     * @param tran_date_ the tran_date_ to set
     */
    public void setTran_date_(String tran_date_) {
        this.tran_date_ = tran_date_;
    }

    /**
     * @return the tran_time_
     */
    public String getTran_time_() {
        return tran_time_;
    }

    /**
     * @param tran_time_ the tran_time_ to set
     */
    public void setTran_time_(String tran_time_) {
        this.tran_time_ = tran_time_;
    }

    /**
     * @return the acct_type_
     */
    public String getAcct_type_() {
        return acct_type_;
    }

    /**
     * @param acct_type_ the acct_type_ to set
     */
    public void setAcct_type_(String acct_type_) {
        this.acct_type_ = acct_type_;
    }

    /**
     * @return the acct_number
     */
    public String getAcct_number() {
        return acct_number;
    }

    /**
     * @param acct_number the acct_number to set
     */
    public void setAcct_number(String acct_number) {
        this.acct_number = acct_number;
    }

    /**
     * @return the acct_desc
     */
    public String getAcct_desc() {
        return acct_desc;
    }

    /**
     * @param acct_desc the acct_desc to set
     */
    public void setAcct_desc(String acct_desc) {
        this.acct_desc = acct_desc;
    }

    /**
     * @return the total_balance
     */
    public String getTotal_balance() {
        return total_balance;
    }

    /**
     * @param total_balance the total_balance to set
     */
    public void setTotal_balance(String total_balance) {
        this.total_balance = total_balance;
    }

    /**
     * @return the last_mon_stmt
     */
    public String getLast_mon_stmt() {
        return last_mon_stmt;
    }

    /**
     * @param last_mon_stmt the last_mon_stmt to set
     */
    public void setLast_mon_stmt(String last_mon_stmt) {
        this.last_mon_stmt = last_mon_stmt;
    }

    /**
     * @return the opening_balance
     */
    public String getOpening_balance() {
        return opening_balance;
    }

    /**
     * @param opening_balance the opening_balance to set
     */
    public void setOpening_balance(String opening_balance) {
        this.opening_balance = opening_balance;
    }

    /**
     * @return the las_dr_act
     */
    public String getLas_dr_act() {
        return las_dr_act;
    }

    /**
     * @param las_dr_act the las_dr_act to set
     */
    public void setLas_dr_act(String las_dr_act) {
        this.las_dr_act = las_dr_act;
    }

    /**
     * @return the las_cr_act
     */
    public String getLas_cr_act() {
        return las_cr_act;
    }

    /**
     * @param las_cr_act the las_cr_act to set
     */
    public void setLas_cr_act(String las_cr_act) {
        this.las_cr_act = las_cr_act;
    }

    /**
     * @return the cr_turn_over
     */
    public String getCr_turn_over() {
        return cr_turn_over;
    }

    /**
     * @param cr_turn_over the cr_turn_over to set
     */
    public void setCr_turn_over(String cr_turn_over) {
        this.cr_turn_over = cr_turn_over;
    }

    /**
     * @return the dr_turn_over
     */
    public String getDr_turn_over() {
        return dr_turn_over;
    }

    /**
     * @param dr_turn_over the dr_turn_over to set
     */
    public void setDr_turn_over(String dr_turn_over) {
        this.dr_turn_over = dr_turn_over;
    }

    /**
     * @return the branch
     */
    public String getBranch() {
        return branch;
    }

    /**
     * @param branch the branch to set
     */
    public void setBranch(String branch) {
        this.branch = branch;
    }

    /**
     * @return the sweep_amt
     */
    public String getSweep_amt() {
        return sweep_amt;
    }

    /**
     * @param sweep_amt the sweep_amt to set
     */
    public void setSweep_amt(String sweep_amt) {
        this.sweep_amt = sweep_amt;
    }

    /**
     * @return the chq_flag
     */
    public String getChq_flag() {
        return chq_flag;
    }

    /**
     * @param chq_flag the chq_flag to set
     */
    public void setChq_flag(String chq_flag) {
        this.chq_flag = chq_flag;
    }

    /**
     * @return the sig_name
     */
    public String getSig_name() {
        return sig_name;
    }

    /**
     * @param sig_name the sig_name to set
     */
    public void setSig_name(String sig_name) {
        this.sig_name = sig_name;
    }

    /**
     * @return the sig_limit
     */
    public String getSig_limit() {
        return sig_limit;
    }

    /**
     * @param sig_limit the sig_limit to set
     */
    public void setSig_limit(String sig_limit) {
        this.sig_limit = sig_limit;
    }

    /**
     * @return the sig_type
     */
    public String getSig_type() {
        return sig_type;
    }

    /**
     * @param sig_type the sig_type to set
     */
    public void setSig_type(String sig_type) {
        this.sig_type = sig_type;
    }

}
