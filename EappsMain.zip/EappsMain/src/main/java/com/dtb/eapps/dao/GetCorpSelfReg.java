/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author SAM
 */
public class GetCorpSelfReg {
    private String inst_id;
    private String app_id;
    private String module_name;
    private String user_name;
    private String user_pwd;
    private String email_id;
    private String mob_no;
    private String status;
    private String auth_desc;
    private String rej_reason;
    private String user_id;
    private String auth_status;
    private String uniq_id;

    public void setInst_id(String inst_id) {
        this.inst_id = inst_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public void setModule_name(String module_name) {
        this.module_name = module_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public void setUser_pwd(String user_pwd) {
        this.user_pwd = user_pwd;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public void setMob_no(String mob_no) {
        this.mob_no = mob_no;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setAuth_desc(String auth_desc) {
        this.auth_desc = auth_desc;
    }

    public void setRej_reason(String rej_reason) {
        this.rej_reason = rej_reason;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public void setAuth_status(String auth_status) {
        this.auth_status = auth_status;
    }

    public String getInst_id() {
        return inst_id;
    }

    public String getApp_id() {
        return app_id;
    }

    public String getModule_name() {
        return module_name;
    }

    public String getUser_name() {
        return user_name;
    }

    public String getUser_pwd() {
        return user_pwd;
    }

    public String getEmail_id() {
        return email_id;
    }

    public String getMob_no() {
        return mob_no;
    }

    public String getStatus() {
        return status;
    }

    public String getAuth_desc() {
        return auth_desc;
    }

    public String getRej_reason() {
        return rej_reason;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getAuth_status() {
        return auth_status;
    }

    /**
     * @return the uniq_id
     */
    public String getUniq_id() {
        return uniq_id;
    }

    /**
     * @param uniq_id the uniq_id to set
     */
    public void setUniq_id(String uniq_id) {
        this.uniq_id = uniq_id;
    }
    
}   
