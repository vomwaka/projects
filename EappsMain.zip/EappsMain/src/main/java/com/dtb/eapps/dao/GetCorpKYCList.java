/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dtb.eapps.dao;

/**
 *
 * @author SAM
 */
public class GetCorpKYCList {
    private String inst_id;
    private String application_id;
    private String module_name;
    private String corp_name;
    private String corp_reg_no;
    private String corp_addr;
    private String corp_branch;
    private String corp_reg;
    private String industry;
    private String corp_logo;
    private String phy_addr;
    private String postal_addr;
    private String postal_code;
    private String official_mob_no;
    private String official_phone_no;
    private String official_email_id;
    private String auth_status;
    private String auth_desc;
    private String reject_reason;
    private String status;

    /**
     * @return the inst_id
     */
    public String getInst_id() {
        return inst_id;
    }

    /**
     * @param inst_id the inst_id to set
     */
    public void setInst_id(String inst_id) {
        this.inst_id = inst_id;
    }

    /**
     * @return the application_id
     */
    public String getApplication_id() {
        return application_id;
    }

    /**
     * @param application_id the application_id to set
     */
    public void setApplication_id(String application_id) {
        this.application_id = application_id;
    }

    /**
     * @return the module_name
     */
    public String getModule_name() {
        return module_name;
    }

    /**
     * @param module_name the module_name to set
     */
    public void setModule_name(String module_name) {
        this.module_name = module_name;
    }

    /**
     * @return the corp_name
     */
    public String getCorp_name() {
        return corp_name;
    }

    /**
     * @param corp_name the corp_name to set
     */
    public void setCorp_name(String corp_name) {
        this.corp_name = corp_name;
    }

    /**
     * @return the corp_reg_no
     */
    public String getCorp_reg_no() {
        return corp_reg_no;
    }

    /**
     * @param corp_reg_no the corp_reg_no to set
     */
    public void setCorp_reg_no(String corp_reg_no) {
        this.corp_reg_no = corp_reg_no;
    }

    /**
     * @return the corp_addr
     */
    public String getCorp_addr() {
        return corp_addr;
    }

    /**
     * @param corp_addr the corp_addr to set
     */
    public void setCorp_addr(String corp_addr) {
        this.corp_addr = corp_addr;
    }

    /**
     * @return the corp_branch
     */
    public String getCorp_branch() {
        return corp_branch;
    }

    /**
     * @param corp_branch the corp_branch to set
     */
    public void setCorp_branch(String corp_branch) {
        this.corp_branch = corp_branch;
    }

    /**
     * @return the corp_reg
     */
    public String getCorp_reg() {
        return corp_reg;
    }

    /**
     * @param corp_reg the corp_reg to set
     */
    public void setCorp_reg(String corp_reg) {
        this.corp_reg = corp_reg;
    }

    /**
     * @return the industry
     */
    public String getIndustry() {
        return industry;
    }

    /**
     * @param industry the industry to set
     */
    public void setIndustry(String industry) {
        this.industry = industry;
    }

    /**
     * @return the corp_logo
     */
    public String getCorp_logo() {
        return corp_logo;
    }

    /**
     * @param corp_logo the corp_logo to set
     */
    public void setCorp_logo(String corp_logo) {
        this.corp_logo = corp_logo;
    }

    /**
     * @return the phy_addr
     */
    public String getPhy_addr() {
        return phy_addr;
    }

    /**
     * @param phy_addr the phy_addr to set
     */
    public void setPhy_addr(String phy_addr) {
        this.phy_addr = phy_addr;
    }

    /**
     * @return the postal_addr
     */
    public String getPostal_addr() {
        return postal_addr;
    }

    /**
     * @param postal_addr the postal_addr to set
     */
    public void setPostal_addr(String postal_addr) {
        this.postal_addr = postal_addr;
    }

    /**
     * @return the postal_code
     */
    public String getPostal_code() {
        return postal_code;
    }

    /**
     * @param postal_code the postal_code to set
     */
    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code;
    }

    /**
     * @return the official_mob_no
     */
    public String getOfficial_mob_no() {
        return official_mob_no;
    }

    /**
     * @param official_mob_no the official_mob_no to set
     */
    public void setOfficial_mob_no(String official_mob_no) {
        this.official_mob_no = official_mob_no;
    }

    /**
     * @return the official_phone_no
     */
    public String getOfficial_phone_no() {
        return official_phone_no;
    }

    /**
     * @param official_phone_no the official_phone_no to set
     */
    public void setOfficial_phone_no(String official_phone_no) {
        this.official_phone_no = official_phone_no;
    }

    /**
     * @return the official_email_id
     */
    public String getOfficial_email_id() {
        return official_email_id;
    }

    /**
     * @param official_email_id the official_email_id to set
     */
    public void setOfficial_email_id(String official_email_id) {
        this.official_email_id = official_email_id;
    }

    /**
     * @return the auth_status
     */
    public String getAuth_status() {
        return auth_status;
    }

    /**
     * @param auth_status the auth_status to set
     */
    public void setAuth_status(String auth_status) {
        this.auth_status = auth_status;
    }

    /**
     * @return the auth_desc
     */
    public String getAuth_desc() {
        return auth_desc;
    }

    /**
     * @param auth_desc the auth_desc to set
     */
    public void setAuth_desc(String auth_desc) {
        this.auth_desc = auth_desc;
    }

    /**
     * @return the reject_reason
     */
    public String getReject_reason() {
        return reject_reason;
    }

    /**
     * @param reject_reason the reject_reason to set
     */
    public void setReject_reason(String reject_reason) {
        this.reject_reason = reject_reason;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    
}
