
//var BASE_URL = 'http://ibank.sbsafrica.com:8080/eapps_core_test';

//var BASE_URL = 'https://212.22.175.13:9082/eapps_uat';

//var BASE_URL = 'http://ibank.sbsafrica.com:8080/eapps_core_test';

var BASE_URL = 'http://ibank.sbsafrica.com:8080/eapps_core_test_dev';


//


	function getdata (request) {
        var dfd = $.Deferred();
		$.ajax({
			  method: "POST", 
			  url: BASE_URL,
			  headers: {
                'Content-Type':'application/json'
             },
             dataType: 'json',
             data: JSON.stringify(request),
			  success: function( data ) {
		           dfd.resolve(handlesuccess(data));
			  },
			  error: function( req, status, err ) {

			     dfd.resolve(handleError(err));
			  }
			});
        return dfd.promise();  
	};






	function getip () {
		console.log('Searching ip');
        var dfd = $.Deferred();
		$.ajax({
			   method: "GET",
			  url: 'https://api.ipify.org?format=json',
			  headers: {
                'Content-Type':'application/json'
            },
			  success: function( data ) {
			  	  var response={};
			  	      response.status=true;
			  	      response.data=data;
		           dfd.resolve(response);
			  },
			  error: function( req, status, err ) {
			  	      var response={};
			  	      response.status=false;
			  	      response.message=err;
			     dfd.resolve(response);
			  }
			});
        return dfd.promise();  
	}



	function initiatesession () {
		  var dfd = $.Deferred(); 
           getdata (initiateSessionRequest()).then(function (data) {
   	           console.log(data);
                dfd.resolve(data);
               });

         return dfd.promise(); 
	}


 var Storage = {
    set: function (item, value) {
        sessionStorage.setItem(item, value);
    },
    get: function (item) {
        var value = sessionStorage.getItem(item);
        return value;
    },
    count: function () {
        var len = sessionStorage.length;
        return len;
    },
    remove: function (item) {
        sessionStorage.removeItem(item);
    },
    empty: function () {
        sessionStorage.clear();
    },
    saveObject: function (item, obj) {
        if (typeof obj === 'object') {
            this.set(item, JSON.stringify(obj));
        } else {
            this.set(item, 'Could not convert to JSON string');
        }
    },
    getObject: function (item) {
        var json = this.get(item);
        var obj = JSON.parse(json);
        return obj;
    }
};



function handlesuccess (response){
         // possibility that there is a response from Server but not Valid Response

       var resp = {};
        if (response.resp_info.resp_code==='000')
        {
          resp.status=true;
          resp.data=response;
          return resp;
        }else {
          
          resp.status=false;
          resp.message=response.resp_info.resp_desc;
          resp.developerMessage="Sorry Kindly Contact Admin";

          return resp;
        }

      

    }

function handleError (error){
       // can be Http Error ..No Connecion ..etc 
      //check here
         var resp = {};
          resp.status=false;
          resp.message="Sorry Kindly Contact Admin";
          resp.developerMessage='Connection Errors';


      return resp;

    };   

