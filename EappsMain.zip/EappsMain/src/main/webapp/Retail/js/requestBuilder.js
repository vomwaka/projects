
var APPID  ='eapps_core';

    function initiateSessionRequest () {
     var sessionReq = {};
        sessionReq.application_info={};
        sessionReq.application_info.application_id=APPID;  
        sessionReq.req_info={};
        sessionReq.req_info.req_type='initiate_session';
		sessionReq.req_info.channel_type='retail';
        sessionReq.device_info={};
        sessionReq.device_info.device_type='web';
        sessionReq.device_info.device_address=Storage.get('ip');
        sessionReq.device_info.device_model='pc'; 
        sessionReq.device_sub_type='mozilla';

        return sessionReq;
    };

    function ministatement (acct) {
         var accountsList = {};
            accountsList.user_info={};
            accountsList.user_info.user_name=Storage.get('username');
            accountsList.user_info.user_pwd=Storage.get('password');
            accountsList.txn_info={};
            accountsList.txn_info.account_no=acct.rel_id;
            accountsList.txn_info.br_code=acct.br_id;
            accountsList.req_info={};
            accountsList.req_info.req_type='mini_stmt';
            accountsList.req_info.channel_type='retail';
            accountsList.req_info.stmt_count='10';
            accountsList.session_info={};
            accountsList.session_info.session_id=Storage.get('session_id');
            accountsList.device_info={};
            accountsList.device_info.device_type='web';
            accountsList.device_info.device_address=Storage.get('ip');
            accountsList.device_info.device_model='pc';
            accountsList.device_info.device_sub_type='web';
           // console.log(accountsList);
            return accountsList;
      };

       function getcust_info () {
         var user = {};
            user.user_info={};
            user.user_info.user_name=Storage.get('username');
            user.user_info.user_pwd=Storage.get('password');
            user.req_info={};
            user.req_info.req_type='get_cust';
            user.req_info.channel_type='retail';
            user.session_info={};
            user.session_info.session_id=Storage.get('session_id');
            user.device_info={};
            user.device_info.device_type='web';
            user.device_info.device_address=Storage.get('ip');
            user.device_info.device_model='pc';
            user.device_info.device_sub_type='web';
           // console.log(accountsList);
            return user;
      };

       function getpaybill_types () {
         var paybill = {};
            paybill.user_info={};
            paybill.user_info.user_name=Storage.get('username');
            paybill.user_info.user_pwd=Storage.get('password');
            paybill.req_info={};
            paybill.req_info.req_type='get_paybill_type_list';
            paybill.req_info.channel_type='retail';
            paybill.session_info={};
            paybill.session_info.session_id=Storage.get('session_id');
            paybill.device_info={};
            paybill.device_info.device_type='web';
           paybill.device_info.device_address=Storage.get('ip');
            paybill.device_info.device_model='pc';
            paybill.device_info.device_sub_type='web';
           // console.log(accountsList);
            return paybill;
      };

     function loanstatement (acct) {
         var accountsList = {};
            accountsList.user_info={};
            accountsList.user_info.user_name=Storage.get('username');
            accountsList.user_info.user_pwd=Storage.get('password');
            accountsList.txn_info={};
            accountsList.txn_info.account_no=acct.rel_id;
            accountsList.txn_info.br_code=acct.br_id;
            accountsList.req_info={};
            accountsList.req_info.req_type='loan_stmt';
            accountsList.req_info.channel_type='retail';
            accountsList.req_info.stmt_count='10';
            accountsList.session_info={};
            accountsList.session_info.session_id=Storage.get('session_id');
            accountsList.device_info={};
            accountsList.device_info.device_type='web';
            accountsList.device_info.device_address=Storage.get('ip');
            accountsList.device_info.device_model='pc';
            accountsList.device_info.device_sub_type='web';
           // console.log(accountsList);
            return accountsList;
      };

    function loginRequest (uname,pwd) {
     
        var login = {};
            login.user_info={};
            login.user_info.user_name=uname;
            login.user_info.user_pwd=pwd; 
            login.req_info={};    
            login.req_info.req_type="cust_login";        
            login.req_info.channel_type="retail";
            login.session_info={};
            login.session_info.session_id=Storage.get('session_id');
            login.device_info={};
            login.device_info.device_type='web';
            login.device_info.channel_type='retail';
            login.device_info.device_address=Storage.get('ip');
            login.device_info.device_model='pc';
            login.device_info.device_sub_type='mozilla';

        return login;    

   };


  function AccountBalanceRequest (br_code,acct_no) {
        var accountsList = {};
            accountsList.user_info={};
            accountsList.user_info.user_name=Storage.get('username');
            accountsList.user_info.user_pwd=Storage.get('password');
            accountsList.req_info={};
            accountsList.req_info.req_type='myaccounts_retail';
            accountsList.req_info.br_code=br_code;
            accountsList.req_info.acct_no=acct_no;
            accountsList.req_info.channel_type='retail';
            accountsList.session_info={};
            accountsList.session_info.session_id=Storage.get('session_id');
            accountsList.device_info={};
            accountsList.device_info.device_type='web';
            accountsList.device_info.device_address=Storage.get('ip');
            accountsList.device_info.device_model='pc';
            accountsList.device_info.device_sub_type='web';


            return accountsList;
    };

   function myAcctList (){
    	var accountsList = {};
    	    accountsList.user_info={};
    	    accountsList.user_info.user_name=Storage.get('username');
    	    accountsList.user_info.user_pwd=Storage.get('password');
    	    accountsList.req_info={};
    	    accountsList.req_info.req_type='myaccounts_list';
    	    accountsList.req_info.channel_type='retail';
    	    accountsList.session_info={};
            accountsList.session_info.session_id=Storage.get('session_id');
            accountsList.device_info={};
            accountsList.device_info.device_type='web';
            accountsList.device_info.device_address=Storage.get('ip');
            accountsList.device_info.device_model='browser';
            accountsList.device_info.device_sub_type='web';
            return accountsList;
    };

       function myLoanList (){
        var accountsList = {};
            accountsList.user_info={};
            accountsList.user_info.user_name=Storage.get('username');
            accountsList.user_info.user_pwd=Storage.get('password');
            accountsList.req_info={};
            accountsList.req_info.req_type='myloans_list';
            accountsList.req_info.channel_type='retail';
            accountsList.session_info={};
            accountsList.session_info.session_id=Storage.get('session_id');
            accountsList.device_info={};
            accountsList.device_info.device_type='web';
            accountsList.device_info.device_address=Storage.get('ip');
            accountsList.device_info.device_model='browser';
            accountsList.device_info.device_sub_type='web';
            return accountsList;
    };



     function OtpRequest () {

        //+254723594312
       var otp = {};
            otp.user_info={};
            otp.user_info.user_name=Storage.get('username');
             otp.user_info.user_pwd=Storage.get('password');
             otp.req_info={};
            otp.req_info.req_type='sendsms';
            otp.req_info.number='+254723594312';  
            otp.req_info.message='RETAIL OTP PIN 5209';
            otp.session_info={};
            otp.session_info.session_id=Storage.get('session_id');
            otp.device_info={};
            otp.device_info.device_type='web';
            otp.device_info.device_address=Storage.get('ip');
            otp.device_info.device_model='browser';
            otp.device_info.device_sub_type='web';
            return otp ;
           
    }


    function OtpRequest2 () {

        //+254723594312
        //var newnum = '+254'+num.substring(1);
       var otp = {};
            otp.user_info={};
            otp.user_info.user_name=Storage.get('username');
             otp.user_info.user_pwd=Storage.get('password');
             otp.req_info={};
            otp.req_info.req_type='sendsms';
            otp.req_info.number=Storage.get('custdetails').official_mob_number_1;  
            otp.req_info.message=' username :' + Storage.get('username') + " Password: "  + Storage.get('password');
            otp.session_info={};
            otp.session_info.session_id=Storage.get('session_id');
            otp.device_info={};
            otp.device_info.device_type='web';
            otp.device_info.device_address=Storage.get('ip');
            otp.device_info.device_model='browser';
            otp.device_info.device_sub_type='web';
            return otp ;
           
    }

     function getRelationshipList (){

        var relList ={} ;
        relList.user_info={};
        relList.user_info.user_name=Storage.get('username');
        relList.user_info.user_pwd=Storage.get('password');
        relList.req_info={};
        relList.req_info.req_type="get_rel_list";
        relList.rel_info={};//"rel_info":{"inst_id":"DTB"},
        relList.rel_info.inst_id="DTB";
        relList.session_info={};//"session_info":{"session_id":"1234"},
        relList.session_info.session_id=Storage.get('session_id');
        relList.device_info={};  
        relList.device_info.device_type='web';
        relList.device_info.device_address=Storage.get('ip');
        relList.device_info.device_model='browser';
        relList.device_info.device_sub_type='web';


        return relList;
    };

    function getCard () {

         var carddet ={} ;
        carddet.user_info={};
        carddet.user_info.user_name=Storage.get('username');
        carddet.user_info.user_pwd=Storage.get('password');
        carddet.user_info.inst_id='DTB'
        carddet.req_info={};
        carddet.req_info.req_type="get_customer_cards";
        carddet.req_info.channel_type="retail";
        carddet.rel_info={};//"rel_info":{"inst_id":"DTB"},
        carddet.rel_info.inst_id="DTB";
        carddet.session_info={};//"session_info":{"session_id":"1234"},
        carddet.session_info.session_id=Storage.get('session_id');
        carddet.device_info={};  
        carddet.device_info.device_type='web';
        carddet.device_info.device_address=Storage.get('ip');
        carddet.device_info.device_model='browser';
        carddet.device_info.device_sub_type='web';


        return carddet;


    };
     function getSwifcodes () {

         var swiftcode ={} ;
        swiftcode.user_info={};
        swiftcode.user_info.user_name=Storage.get('username');
        swiftcode.user_info.user_pwd=Storage.get('password');
        swiftcode.user_info.inst_id='DTB'
        swiftcode.req_info={};
        swiftcode.req_info.req_type="get_swift_code_list";
        swiftcode.req_info.channel_type="retail";
        swiftcode.rel_info={};//"rel_info":{"inst_id":"DTB"},
        swiftcode.rel_info.inst_id="DTB";
        swiftcode.session_info={};//"session_info":{"session_id":"1234"},
        swiftcode.session_info.session_id=Storage.get('session_id');
        swiftcode.device_info={};  
        swiftcode.device_info.device_type='web';
        swiftcode.device_info.device_address=Storage.get('ip');
        swiftcode.device_info.device_model='browser';
        swiftcode.device_info.device_sub_type='web';


        return swiftcode;


    };

   






