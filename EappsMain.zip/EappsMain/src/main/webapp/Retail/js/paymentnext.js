$(document).ready(function() {  




  if (jQuery.when.all===undefined) {
    jQuery.when.all = function(deferreds) {
        var deferred = new jQuery.Deferred();
        $.when.apply(jQuery, deferreds).then(
            function() {
                deferred.resolve(Array.prototype.slice.call(arguments));
            },
            function() {
                deferred.fail(Array.prototype.slice.call(arguments));
            });

        return deferred;
    }
}

getdata (getpaybill_types()).then(function (data) {
     if (data.status){
        console.log(data);
        showpaybils(data.data.get_paybill_list);
     }
  });



var dt = JSON.parse(Storage.get('payments'));
showselectedpaybill(dt.tfrto);



    if (dt.tfrfrom === 'current') {
         
          getacccounts('CRRNT');
          Highlightlass('curr');
       
    }
    else if (dt.tfrfrom === 'savings') {
           getacccounts('SAVNG');
            Highlightlass('sav');
    }

     else if (dt.tfrfrom === 'cards') {
           getcustomercards();
            Highlightlass('card');
    }

     $('.transtrigger').click(function () {
    selectedAccts();
      $(".newstdorder").fadeOut('fast');
      $(".transhow").fadeIn('slow');

    });

    function Highlightlass(type){
      var inp ="#i"+type;
      var lbl = "#l"+type;
      var ptag ="#p"+type;
      console.log(inp);
         $(inp).addClass('highlitedchk');
          $(lbl).addClass('highlitedchk');
           $(ptag).addClass('highlitedchk');
     
    }

  function  getacccounts(accttype){

          getdata (myAcctList()).then(function (data) {
                if (data.status){
                        var accts = SeparateAccountTypes(data.data.realtionship_list,accttype);   
                         if (accts.customerAccts.length !== 0 ){
                
                               getConsolidatedAccountBalance(accts.customerAccts);    

                         }
                         
                        
                         

                }
                else {
                 /// alert(data.message);
                  console.log(data.message);
                }
               });

    }

     function  SeparateAccountTypes (accts,accttype){
   
            var Accts ={};
                var customerAccts = [];
           if ($.isArray(accts) ){

             for ( var i = 0, _len = accts.length; i < _len; i++ ) {
              if (accts[i].rel_type === accttype){
                customerAccts.push(accts[i]);

              }
            }
              Accts.customerAccts=customerAccts;
      

            return Accts;

           

           }   else {
             return accts;
           }  

         
        } 

  function getConsolidatedAccountBalance (acctlist) {

    var AccountWithBalance=[];

    if ($.isArray(acctlist) ){
        $.each(acctlist, function (i, value) {
          AccountWithBalance.push(getdata(AccountBalanceRequest(value.br_id,value.rel_id)) );       
        });       
      }   
    else {    
      AccountWithBalance.push( getdata(AccountBalanceRequest(acctlist.br_id,acctlist.rel_id)));
    }
  
    $.when.all(AccountWithBalance).then(function(results) {
              var response={};
               // response.bal=calculateTotalBal(results);
               response.accts=buildAcctAgain(results);
               addAccountToSelect (response.accts);
                response.error=false;
              //  showConsolidatedbalance (response.bal,accttype,response.accts);
      }, function(e) {
            var response={};
                 response.error=false;
                 response.message=e;
                 
      });


  }

   function addAccountToSelect (acct) {
      $.each(acct, function(key, val) {   
        console.log(val);
        $('#acctselect')
          .append($('<option>', { value : val.acctnumber +'|' + val.acctname + '|' + val.balance })
          .text(val.acctnumber)); 
           });

    }

    function buildAcctAgain (current){
    // this function used to build customer account after getting customer account balance
 
    var acctData=[];
    var acct ={};

     if ($.isArray(current) ){

        for ( var i = 0, _len = current.length; i < _len; i++ ) {

             if (current[i].status){
                  acct.branch=current[i].data.resp_info.acct_status_list[0].branch;
                  acct.acctnumber=current[i].data.resp_info.acct_status_list[0].acct_number;
                  acct.acctname=current[i].data.resp_info.acct_status_list[0].acct_desc;
                  acct.balance=current[i].data.resp_info.acct_status_list[0].total_balance;
             }
             else {
                  
                  acct.branch="Unknown";
                  acct.acctnumber="Unknown";
                  acct.acctname="Unknown";
                  acct.balance="Unknown";
                  

             }

             acctData.push(acct);


         }

         return acctData;
      }
      else {

                  acct.branch=current.data.resp_info.acct_status_list[0].branch;
                  acct.acctnumber=current.data.resp_info.acct_status_list[0].acct_number;
                  acct.acctname=current.data.resp_info.acct_status_list[0].acct_desc;
                  acct.balance=current.data.resp_info.acct_status_list[0].total_balance;

                  return acct
      }

    }


 function   getcustomercards(){

    getdata (getCard()).then(function (data) {
 
                if (data.status){
                  console.log(data.data);
                        addCardToSelect(data.data.card_list);
                }
                else {
                   // alert(data.message);
                }
               });

    }

    function addCardToSelect (acct) {
      $.each(acct, function(key, val) {   
        $('#acctselect')
          .append($('<option>', { value : val.cardaccount +'|' + val.cardname + '|' + val.cardnumber })
          .text(val.cardnumber)); 
           });

    }

     function addAccountToSelect (acct) {
      $.each(acct, function(key, val) {   
        console.log(val);
        $('#acctselect')
          .append($('<option>', { value : val.acctnumber +'|' + val.acctname + '|' + val.balance })
          .text(val.acctnumber)); 
           });

    }


  $('.transtrigger').click(function () {
   // selectedAccts();
      $(".newstdorder").fadeOut('fast');
      $(".transhow").fadeIn('slow');

    });


function showselectedpaybill(data) {

    console.log("Running data");
      console.log(data)

          $.each(data, function (i, v) {

                         $('#payments').append(   
                               '<div class="full payfrm righter">'+
                      '<span class="clearfix allpay lefter kplc" >'+
                       ' <span  id="span_'+i+'" >'+v.accounttname.charAt(0)+'</span>'+
                      '</span>'+
                      '<div class="quatro lefter">'+
                        '<span class="input input--akira">'+
                          '<input class="input__field input__field--akira" type="text" id="inputacct_'+i+'"   />'+
                          '<label class="input__label input__label--akira" for="inputacct_'+i+'">'+
                            '<span class="input__label-content input__label-content--akira">Account</span>'+
                          '</label>'+
                        '</span>'+
                          '</div>'+
                      '<div class="quatro lefter">'+
                        '<span class="input input--akira">'+
                          '<input class="input__field input__field--akira" type="text" id="inputamt_'+i+'" />'+
                          '<label class="input__label input__label--akira" for="inputamt_'+i+'">'+
                            '<span class="input__label-content input__label-content--akira">Amount</span>'+
                          '</label>'+
                        '</span>'+
                             '</div>'+
                    '<div class="quatro righter">    '+               
                              '<div class="filer file-cont clearfix">'+
                            '<span class="select-wrapper datr">'+
                              '<input placeholder="Date" type="text" class="datepick acother icon-calendar_icon" name="image_src" id="inputdate_'+i+'" />'+
                            '</span>'+
                       ' </div>'+
                            '  </div>'+
                             
                     ' </div>'

                               
                            )
                    var dt ="#inputdate_"+i;
                $(dt ).multiDatesPicker(
                  {
                    showButtonPanel: true,
                    showOn: "button",
                    buttonImage: "images/calender.svg",
                    buttonImageOnly: true,
                    buttonText: "Select date",
                    changeDay: true,
                    changeMonth: true,
                    changeYear: true
                  });


                     }

                     );

      [].slice.call( document.querySelectorAll( 'input.input__field, textarea.input__field' ) ).forEach( function( inputEl ) {
          // in case the input is already filled..
          if( inputEl.value.trim() !== '' ) {
            classie.add( inputEl.parentNode, 'input--filled' );
          }

          // events:
          inputEl.addEventListener( 'focus', onInputFocus );
          inputEl.addEventListener( 'blur', onInputBlur );
        } );

        function onInputFocus( ev ) {
          classie.add( ev.target.parentNode, 'input--filled' );
        }

        function onInputBlur( ev ) {
          if( ev.target.value.trim() === '' ) {
            classie.remove( ev.target.parentNode, 'input--filled' );
          }
        }


 

}


    function showpaybils(data){

    $.each(data, function (i, v) {

         $('#bhome').append(  

               '<li>'+
                '<span class="clearfix lefter dstv" >' +
                '<span>'+v.biller_name.charAt(0)+'</span>'+
                '<h6>'+v.biller_name+'</h6>'+
                '</span>'+
                '<span class="bigcheck check-box">'+
                '<label class="bigcheck">'+
                '<input type="checkbox" class="bigcheck" name="cheese" id="chk_'+i+'"  value="'+v.biller_name+'|'+v.biller_code+'"/>'+
                '<span class="bigcheck-target"></span>'+
                '</label>'+
                '</span>'+
                '</li>'

            )
       

         });


  }




    function addAccountToSelect (acct) {
      $.each(acct, function(key, val) {   
        console.log(val);
        $('#acctselect')
          .append($('<option>', { value : val.acctnumber +'|' + val.acctname + '|' + val.balance })
          .text(val.acctnumber)); 
           });

    }




      function selectedAccts () {
      var tfrdata={};

     var tfrto=[];
     var totalinputs = $("#payments").find("input").length;
     //3 numper of input in a row
     var  inputs = totalinputs/3;

                  for ( var i = 0, _len = inputs; i < _len; i++ ) {

              var inp={};
             
                 var span =    "#span_"+i + "  span"
                var inptname = "#inputacct_"+i
                var inptamt =  "#inputamt_"+i
                var inptdate = "#inputdate_"+i
                
                    inp.paybillname =  $(span).text();
                    inp.accounttname =  $(inptname).val();
                    inp.amount =  $(inptamt).val();
                    inp.paybilldate =  $(inptdate).val();
                   tfrto.push (inp);  
             };

      var acctdet=$( "#acctselect" ).val();
      console.log(acctdet);
      var tr=acctdet.split("|");
      var tfrfrom={};
          tfrfrom.accounttname =tr[1];
          tfrfrom.accountnumber =tr[0];
          tfrfrom.balance =tr[2];

  
      tfrdata.tfrfrom=tfrfrom;
      tfrdata.tfrto=tfrto;
      showPopup(tfrdata);
    
    }
 
    function showPopup (data)  {
             console.log(data);
             var totalamt=0;
       
                       $('#currentacct').append( '<li >'+
                            '<span class="icon-consolidated_investments"></span>'+
                            '<p> Account Balance</p>'+
                            '<h3><b >Ksh '+addCommas(data.tfrfrom.balance)+'</b></h3>'+
                          '</li>'+
                          '<li>'+
                            '<span class="icon-calendar"></span>'+
                            '<p>Last Account Activity</p>'+
                            '<h3>06/06/2016, 10:00pm</h3>'+
                          '</li>' );

       $.each(data.tfrto, function(key, val) { 

          $('#tfrtoactname').append( '<li> <b>'+val.accounttname+'</b></li>' );
           $('#tfrtoactname1').append( '<li> <b>'+val.accounttname+'</b></li>' );

           $('#tfrtoactnumber').append( '<li><b>'+val.paybilldate+'</b></li>' );
               $('#tfrtoactnumber1').append( '<li><b>'+val.paybilldate+'</b></li>' );

            $('#tfrtoaamt').append( '<li><b>KSH: '+addCommas(val.amount)+'</b></li>' );
              $('#tfrtoaamt1').append( '<li><b>KSH: '+addCommas(val.amount)+'</b></li>' );

              $('#tframtstr').append( '<p class="full usr">Transfer Ksh '+addCommas(val.amount)+' from my current account to the below current accounts</p>' );
               $('#tframtstr1').append( '<p class="full usr">Transfer Ksh '+addCommas(val.amount)+' from my current account to the below current accounts</p>' );

                  $('#progress').append( '<li><b>In Progress</b></li>' );
               
             
             totalamt  = totalamt  + parseFloat(val.amount);

       });
$('#totalamount').append( '<p>Total Amount: <b>Ksh '+ addCommas(totalamt)+'</b></p>' );
$('#tfrConfirmamount').append( '<p class="full usr">You have transfered Ksh '+ addCommas(totalamt)+' from my current account to the below current accounts</p>' );

      

    }

      function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}




});