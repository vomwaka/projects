$(document).ready(function() {  

 $("body").addClass("loading"); 


  if (jQuery.when.all===undefined) {
    jQuery.when.all = function(deferreds) {
        var deferred = new jQuery.Deferred();
        $.when.apply(jQuery, deferreds).then(
            function() {
                deferred.resolve(Array.prototype.slice.call(arguments));
            },
            function() {
                deferred.fail(Array.prototype.slice.call(arguments));
            });

        return deferred;
    }
}


  getdata (getpaybill_types()).then(function (data) {

    $("body").removeClass("loading");
     if (data.status){
        console.log(data);
        showpaybils(data.data.get_paybill_list);
     }
  });

/*
  we are not fetching accounts on first page we are just selecting the account type
    getdata (myAcctList()).then(function (data) {
               var statementfetched=false;    
                if (data.status){
                        var accts = SeparateAccountTypes(data.data.realtionship_list);   
                           console.log(accts);
                          if (accts.current.length !== 0){
                               
                                 
                                 getConsolidatedAccountBalance(accts.current ,'current');  
                          }
                        
                         

                }
                else {
                    alert(data.message);
                }
               });

*/

$("form").submit(function(e){

    //check if session already initiates
  e.preventDefault(e);
  selectedAccts ();

});

function selectedAccts () {
      var tfrdata={};

     var tfrto=[];
     var tfrfrom =  $("input[name='acctfrom']:checked").val();
      $("#bhome").find("input:checked").each(function (i, ob) { 
          var obj=$(ob).val();
           var inp={};
               inp.accounttname = obj.split("|")[0];
               inp.accountnumber= obj.split("|")[1];
               tfrto.push (inp);  
          });
    
      tfrdata.tfrto=tfrto;
      tfrdata.tfrfrom=tfrfrom;
      console.log(tfrdata);
       Storage.set('payments', JSON.stringify(tfrdata));
        document.location.href = 'paymentnext2.html'
    }


function getConsolidatedAccountBalance (acctlist ,accttype) {
  
    var AccountWithBalance=[];

    if ($.isArray(acctlist) ){
        $.each(acctlist, function (i, value) {
          AccountWithBalance.push(getdata(AccountBalanceRequest(value.br_id,value.rel_id)) );       
        });       
      }   
    else {    
      AccountWithBalance.push( getdata(AccountBalanceRequest(acctlist.br_id,acctlist.rel_id)));
    }
  
    $.when.all(AccountWithBalance).then(function(results) {
               customerAccts =buildAcctAgain(results);
                 addAccountToSelect(customerAccts);
      }, function(e) {
          //errrror listing accounts
                 
      });

  }

    function buildAcctAgain (current){
    // this function used to build customer account after getting customer account balance


 
    var acctData=[];
    var acct ={};

     if ($.isArray(current) ){

        for ( var i = 0, _len = current.length; i < _len; i++ ) {

             if (current[i].status){
                  acct.branch=current[i].data.resp_info.acct_status_list[0].branch;
                  acct.acctnumber=current[i].data.resp_info.acct_status_list[0].acct_number;
                  acct.acctname=current[i].data.resp_info.acct_status_list[0].acct_desc;
                  acct.balance=current[i].data.resp_info.acct_status_list[0].total_balance;
             }
             else {
                  
                  acct.branch="Unknown";
                  acct.acctnumber="Unknown";
                  acct.acctname="Unknown";
                  acct.balance="Unknown";
                  

             }

             acctData.push(acct);


         }

         return acctData;
      }
      else {

                  acct.branch=current.data.resp_info.acct_status_list[0].branch;
                  acct.acctnumber=current.data.resp_info.acct_status_list[0].acct_number;
                  acct.acctname=current.data.resp_info.acct_status_list[0].acct_desc;
                  acct.balance=current.data.resp_info.acct_status_list[0].total_balance;

                  return acct
      }

    }


    function addAccountToSelect (acct) {
      $.each(acct, function(key, val) {   
        console.log(val);
        $('#acctselect')
          .append($('<option>', { value : val.acctnumber +'|' + val.acctname + '|' + val.balance })
          .text(val.acctnumber)); 
           });

    }



   function  SeparateAccountTypes (accts){
   
            var Accts ={};
                var savingAccts = [];
                var currentAccts=[];
           if ($.isArray(accts) ){

             for ( var i = 0, _len = accts.length; i < _len; i++ ) {
              if (accts[i].rel_type === 'SAVNG'){
                savingAccts.push(accts[i]);

              }else if (accts[i].rel_type === 'CRRNT'){
                 currentAccts.push(accts[i]);
              }
            }
              Accts.savings=savingAccts;
              Accts.current=currentAccts;

        

            return Accts;

           

           }   else {
             return accts;
           }  

         
        }

  function showpaybils(data){

    $.each(data, function (i, v) {

         $('#bhome').append(  

               '<li>'+
                '<span class="clearfix lefter dstv" >' +
                '<span>'+v.biller_name.charAt(0)+'</span>'+
                '<h6>'+v.biller_name+'</h6>'+
                '</span>'+
                '<span class="bigcheck check-box">'+
                '<label class="bigcheck">'+
                '<input type="checkbox" class="bigcheck" name="cheese" id="chk_'+i+'"  value="'+v.biller_name+'|'+v.biller_code+'"/>'+
                '<span class="bigcheck-target"></span>'+
                '</label>'+
                '</span>'+
                '</li>'

            )
       

         });

    


  }





  });