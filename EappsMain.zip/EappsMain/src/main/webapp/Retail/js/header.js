$(document).ready(function() {  


var custdetails =JSON.parse(Storage.get('custdetails'));
console.log(custdetails);


$('#siteheader').append(    

'<div class="maxwidthy">'+
	   					'<div class="logo logo-right">'+
	   						'<div class="wrpsearch">'+		
								'<i class="icon-search_icon searchdrawer"></i>'+
								'<span class="bgsearch">'+
									'<input class="search" placeholder="search..." type="text" id="search" />'+
								'</span>'+
	   						'</div>'+
	   							'<span class="icon-menu3 togglemenu"></span>'+
	   						'<ul class="quickies menuprof">'+
	   							'<li><a class="" href="javascript:void(0);" onclick="javascript:introJs().setOption(showProgress, true).start();">Quick guide</a></li>'+
	   							'<li>Get Help</li>'+
	   						'</ul>'+
	   						'<img src="images/logo.png" alt="DTB logo">'+
	   					'</div>'+
	   					
		   						'<span class="lefter profile prodro clearfix">'+
		   							'<span class="prodrop">'+
			   							'<ul id="prodrop" class="redy">'+
											'<li class="current">Accounts Details'+
											'</li>'+
											'<li>'+
			                                   	'<i class="conso icon-consolidated_investments"></i>'+
												'<span class="trequatro">'+
					                                '<h3 class="full">Consolidated Balance</h3>'+
					                                '<h2 class="full">Ksh 880 000</h2>'+
					                            '</span>'+
											'</li>'+
											'<li>'+
			                                   	'<i class="conso icon-Logout"></i>'+
												'<span class="trequatro">Logout</span>'+
											'</li>'+
										'</ul>'+

												'<ul id="prodrop" class="righter twothird">'+
													'<li>'+
														'<div class="full liner">'+
									   						'<div class="halfy profile">'+
									   							'<img src="images/userprofpic.png">'+
									   							'<span class="">'+
										   							'<span class="profname">'+custdetails.first_name + ' '+custdetails.last_name+'</span>'+
									   							'</span>'+
									   						'</div>'+

															'<div class="halfy up">'+
																'<div class="full">'+
							                                    	'<i class="icon-edit"></i>'+
									                                '<h4>'+custdetails.official_mail_1+'</h4>'+
									                            '</div>'+
							                                    
																'<div class="full">'+
																	'<i class=" icon-Call"></i>'+
									                                '<h4>'+custdetails.official_mob_number_1+'</h4>'+
									                            '</div>	'+									
															'</div>'+
															
														'</div>'+
														'<div class="liner full">'+
															'<a href="profile.html" class="btnrnd">View profile</a>'+
														'</div>'+

														'<div class="full liner">'+
															'<div class="third">'+
																'<i class="icon-76"></i>'+
																'<a href="nortification.html" class="">Nortification</a>'+
															'</div>'+

															'<div class="third">'+
																'<i class=" icon-favourites "></i>'+
																'<a href="favourites.html" class="">Favourites</a>'+
															'</div>'+
															'<div class="third">'+
																'<i class="icon-Mailnservice_requests"></i>'+
																'<a href="support.html" class="">Mail</a>'+
															'</div>'+
														'</div>'+

													'</li>'+

												'</ul>'+
		   							'</span>'+
	   								'<a href="profile.html"></a>'+
		   						'</span>'+
	   					'<div class="headlefter">'+
		   						'<span class="userprofpic profile">'+
		   							'<img src="images/userprofpic.png">'+
		   							'<span class="expandprof">'+
			   							'<span class="profname">'+custdetails.first_name + ' '+custdetails.last_name+'</span>'+
			   							'<span class="icon-chevron-thin-down"></span>'+
		   							'</span>'+
		   						'</span>'+
	   					'</div>'+
	   				'</div>'
               );

});