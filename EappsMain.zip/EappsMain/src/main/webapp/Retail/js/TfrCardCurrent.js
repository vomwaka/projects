$(document).ready(function() {  

var customerAccts ;


  if (jQuery.when.all===undefined) {
    jQuery.when.all = function(deferreds) {
        var deferred = new jQuery.Deferred();
        $.when.apply(jQuery, deferreds).then(
            function() {
                deferred.resolve(Array.prototype.slice.call(arguments));
            },
            function() {
                deferred.fail(Array.prototype.slice.call(arguments));
            });

        return deferred;
    }
}


      getdata (myAcctList()).then(function (data) {
               var statementfetched=false;    
                if (data.status){
                        var accts = SeparateAccountTypes(data.data.realtionship_list);   
                           console.log(accts);
                          if (accts.current.length !== 0){             
                                 getConsolidatedAccountBalance(accts.current ,'current');  
                          }
                        
                }
                else {
                    alert(data.message);
                }
               });


      
          getdata (getCard()).then(function (data) {
 
                if (data.status){
                       console.log(data);
                        addCardToSelect(data.data.card_list);
                }
                else {
                    alert(data.message);
                }
               });


   $('.transtrigger').click(function () {
    selectedAccts();
      $(".newstdorder").fadeOut('fast');
      $(".transhow").fadeIn('slow');

    });

   $(".funga, .close, .closer").click(function(){
  window.location.replace('/transmodule1.html')

});



    $('.otpfilltrigger').click(function () {
     var otpval = $('input[name=otp]:checked').val();
        if (otpval==='sms') {
           getdata (OtpRequest2())
           .then(function (data) {
               $(".otpfill").fadeIn();
               $(".cheki").fadeOut();
           })

        }else {
               $(".otpfill").fadeIn();
               $(".cheki").fadeOut();
        }
   
    });

      function  SeparateAccountTypes (accts){
   
            var Accts ={};
                var savingAccts = [];
                var currentAccts=[];
           if ($.isArray(accts) ){

             for ( var i = 0, _len = accts.length; i < _len; i++ ) {
              if (accts[i].rel_type === 'SAVNG'){
                savingAccts.push(accts[i]);

              }else if (accts[i].rel_type === 'CRRNT'){
                 currentAccts.push(accts[i]);
              }
            }
              Accts.savings=savingAccts;
              Accts.current=currentAccts;

        

            return Accts;

           

           }   else {
             return accts;
           }  

         
        }




     
function getConsolidatedAccountBalance (acctlist ,accttype) {
  
    var AccountWithBalance=[];

    if ($.isArray(acctlist) ){
        $.each(acctlist, function (i, value) {
          AccountWithBalance.push(getdata(AccountBalanceRequest(value.br_id,value.rel_id)) );       
        });       
      }   
    else {    
      AccountWithBalance.push( getdata(AccountBalanceRequest(acctlist.br_id,acctlist.rel_id)));
    }
  
    $.when.all(AccountWithBalance).then(function(results) {
               customerAccts =buildAcctAgain(results);
                showAccts(customerAccts);
               //  addAccountToSelect(customerAccts);
      }, function(e) {
          //errrror listing accounts
                 
      });

  }



  function showAccts(acct) {                               

      $.each(acct, function (i, v) {
                         $('#listacct').append(                         
                           ' <li> '+
                                '<span class="bigcheck">'+
                                    '<label class="bigcheck">'+
                                        '<input type="checkbox" class="bigcheck" name="'+i+'" id="chk_'+i+'" value="'+v.acctnumber+'|'+v.acctname+'"/>'+

                                        '<span class="bigcheck-target"></span>'+
                                    '</label>'+
                                '</span>'+
                                 ' <p><b>'+v.acctname+'</b></p>'+
                                  '<p>Account number <b >'+v.acctnumber+'</b></p>'+
                                    '<div class="inptwrapp halfy">'+
                                        '<span class="input input--akira">'+
                                         ' <input class="input__field input__field--akira" type="number" id="'+i+'" />'+
                                          '<label class="input__label input__label--akira" for="'+i+'">'+
                                           ' <span class="input__label-content input__label-content--akira">Enter Amount</span>'+
                                          '</label>'+
                                        '</span>'+
                                      '</div>'+
                                '</li>'  
                               );
                    });


       


      [].slice.call( document.querySelectorAll( 'input.input__field, textarea.input__field' ) ).forEach( function( inputEl ) {
          // in case the input is already filled..
          if( inputEl.value.trim() !== '' ) {
            classie.add( inputEl.parentNode, 'input--filled' );
          }

          // events:
          inputEl.addEventListener( 'focus', onInputFocus );
          inputEl.addEventListener( 'blur', onInputBlur );
        } );

        function onInputFocus( ev ) {
          classie.add( ev.target.parentNode, 'input--filled' );
        }

        function onInputBlur( ev ) {
          if( ev.target.value.trim() === '' ) {
            classie.remove( ev.target.parentNode, 'input--filled' );
          }
        }

    
  }
  function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

    function buildAcctAgain (current){
    // this function used to build customer account after getting customer account balance


 
    var acctData=[];
    var acct ={};

     if ($.isArray(current) ){

        for ( var i = 0, _len = current.length; i < _len; i++ ) {

             if (current[i].status){
                  acct.branch=current[i].data.resp_info.acct_status_list[0].branch;
                  acct.acctnumber=current[i].data.resp_info.acct_status_list[0].acct_number;
                  acct.acctname=current[i].data.resp_info.acct_status_list[0].acct_desc;
                  acct.balance=current[i].data.resp_info.acct_status_list[0].total_balance;
             }
             else {
                  
                  acct.branch="Unknown";
                  acct.acctnumber="Unknown";
                  acct.acctname="Unknown";
                  acct.balance="Unknown";
                  

             }

             acctData.push(acct);


         }

         return acctData;
      }
      else {

                  acct.branch=current.data.resp_info.acct_status_list[0].branch;
                  acct.acctnumber=current.data.resp_info.acct_status_list[0].acct_number;
                  acct.acctname=current.data.resp_info.acct_status_list[0].acct_desc;
                  acct.balance=current.data.resp_info.acct_status_list[0].total_balance;

                  return acct
      }

    }


    function addCardToSelect (acct) {
      $.each(acct, function(key, val) {   
        $('#cards')
          .append($('<option>', { value : val.cardaccount +'|' + val.cardname + '|' + val.cardnumber })
          .text(val.cardnumber)); 
           });

    }




      function selectedAccts () {
      var tfrdata={};

     var tfrto=[];

      $("#listacct").find("input:checked").each(function (i, ob) { 
          var obj=$(ob).val();
        
           var inp={};
               inp.accounttname = obj.split("|")[0];
               inp.accountnumber= obj.split("|")[1];
               inp.amount = $('#'+$(ob).attr('name')).val();

                tfrto.push (inp);  
          });
      var acctdet=$( "#cards" ).val();
      var tr=acctdet.split("|");
      var tfrfrom={};
          tfrfrom.accounttname =tr[1];
          tfrfrom.accountnumber =tr[0];
          tfrfrom.balance =tr[2];

  
      tfrdata.tfrfrom=tfrfrom;
      tfrdata.tfrto=tfrto;
      showPopup(tfrdata);
    }

    function showPopup (data)  {
             console.log(data);
             var totalamt=0;
       
                       $('#currentacct').append( '<li >'+
                            '<span class="icon-consolidated_investments"></span>'+
                            '<p>Current Account Balance</p>'+
                            '<h3><b >Ksh '+addCommas(data.tfrfrom.balance)+'</b></h3>'+
                          '</li>'+
                          '<li>'+
                            '<span class="icon-calendar"></span>'+
                            '<p>Last Account Activity</p>'+
                            '<h3>06/06/2016, 10:00pm</h3>'+
                          '</li>' );

       $.each(data.tfrto, function(key, val) { 

          $('#tfrtoactname').append( '<li> <b>'+val.accounttname+'</b></li>' );
           $('#tfrtoactname1').append( '<li> <b>'+val.accounttname+'</b></li>' );

           $('#tfrtoactnumber').append( '<li><b>'+val.accountnumber+'</b></li>' );
               $('#tfrtoactnumber1').append( '<li><b>'+val.accountnumber+'</b></li>' );

            $('#tfrtoaamt').append( '<li><b>KSH: '+addCommas(val.amount)+'</b></li>' );
              $('#tfrtoaamt1').append( '<li><b>KSH: '+addCommas(val.amount)+'</b></li>' );

              $('#tframtstr').append( '<p class="full usr">Transfer Ksh '+addCommas(val.amount)+' from my Card </p>' );
               $('#tframtstr1').append( '<p class="full usr">Transfer Ksh '+addCommas(val.amount)+' from my Card</p>' );

                  $('#progress').append( '<li><b>In Progress</b></li>' );
               
             
             totalamt  = totalamt  + parseFloat(val.amount);

       });
$('#totalamount').append( '<p>Total Amount: <b>Ksh '+ addCommas(totalamt)+'</b></p>' );
$('#tfrConfirmamount').append( '<p class="full usr">You have transfered Ksh '+ addCommas(totalamt)+' from my Card</p>' );

      

    }



      })
