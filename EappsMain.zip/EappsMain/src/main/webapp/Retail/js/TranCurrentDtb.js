$(document).ready(function() {  

var customerAccts ;

var input1=0;
var input2=0;
var input3=0;


      var tfrdata={};
     var tfrto=[];

function increment(){
   input1++;
   input2++;
   input3++;
}



  if (jQuery.when.all===undefined) {
    jQuery.when.all = function(deferreds) {
        var deferred = new jQuery.Deferred();
        $.when.apply(jQuery, deferreds).then(
            function() {
                deferred.resolve(Array.prototype.slice.call(arguments));
            },
            function() {
                deferred.fail(Array.prototype.slice.call(arguments));
            });

        return deferred;
    }
}



$('#acctselect').on('change', function() {
  var val=this.value.split("|")[0];
var newAcctArray =customerAccts.slice();
for ( var i = 0, _len = newAcctArray.length; i < _len; i++ ) {
      if (newAcctArray[i].acctnumber==val) {
         newAcctArray.splice(i, 1);
         break;
      }
}
console.log(newAcctArray);
$('#listacct').html('')
showAccts(newAcctArray);

});

$(".funga, .close, .closer").click(function(){
  window.location.replace('/transmodule1.html')

});




 

  $('.transtrigger').click(function () {
    selectedAccts();
      $(".newstdorder").fadeOut('fast');
      $(".transhow").fadeIn('slow');

    });



  $('#addAccounts').click(function (){

                      var accname = $('#input-3').val();
                     var accnumber = $('#input-4').val();
                     var amount = $('#input-5').val();

                     var country =$('#country').val();
                      var branch =$('#branch').val();


                          var inp={};
                             inp.accounttname = accname;
                             inp.accountnumber= accnumber;
                             inp.amount = amount;
                             inp.country=country;
                             inp.branch=branch;


                             

                  $('#tfrtolistacct').append(  
                      '<span class="quatro" id="input1-'+input1+'">'+accname+'</span>'+
                      '<span class="quatro" id="input2-'+input2+'">'+accnumber+'</span>'+
                      '<span class="quatro" id="input3-'+input3+'">KES '+amount+'</span>'+
                      '<span class="quatro">'+ new Date()+'</span'+
                        '<span id="tooltip">'+
                                '<span class="btnedit" title="Remove" class="">'+
                                  '<span class="icon-circle-minus"></span>'+
                                '</span>'+
                              '</span>'+
                      '</span>'
                      )
           tfrto.push (inp);  
          increment();

 $("#input-3").val("");
 $("#input-4").val("");
  $("#input-5").val("");

       console.log(tfrto);



  });



    function selectedAccts () {
   


                var acctdet=$( "#acctselect" ).val();
                var tr=acctdet.split("|");
                var tfrfrom={};
                    tfrfrom.accounttname =tr[1];
                    tfrfrom.accountnumber =tr[0];
                    tfrfrom.balance =tr[2];

            
                tfrdata.tfrfrom=tfrfrom;
                tfrdata.tfrto=tfrto;

                console.log(tfrdata);
                showPopup(tfrdata);

    }

        function showPopup (data)  {
             console.log(data);
             var totalamt=0;
       
                       $('#currentacct').append( '<li >'+
                            '<span class="icon-consolidated_investments"></span>'+
                            '<p>Current Account Balance</p>'+
                            '<h3><b >Ksh '+addCommas(data.tfrfrom.balance)+'</b></h3>'+
                          '</li>'+
                          '<li>'+
                            '<span class="icon-calendar"></span>'+
                            '<p>Last Account Activity</p>'+
                            '<h3>'+ new Date()+'</h3>'+
                          '</li>' );

       $.each(data.tfrto, function(key, val) { 

          $('#tfrtoactname').append( '<li> <b>'+val.accounttname+'</b></li>' );
           $('#tfrtoactname1').append( '<li> <b>'+val.accounttname+'</b></li>' );

           $('#tfrtoactnumber').append( '<li><b>'+val.accountnumber+'</b></li>' );
               $('#tfrtoactnumber1').append( '<li><b>'+val.accountnumber+'</b></li>' );

            $('#tfrtoaamt').append( '<li><b>KSH: '+addCommas(val.amount)+'</b></li>' );
              $('#tfrtoaamt1').append( '<li><b>KSH: '+addCommas(val.amount)+'</b></li>' );

              $('#tframtstr').append( '<p class="full usr">Transfer Ksh '+addCommas(val.amount)+' from my current account to the below current accounts</p>' );
               $('#tframtstr1').append( '<p class="full usr">Transfer Ksh '+addCommas(val.amount)+' from my current account to the below current accounts</p>' );

                  $('#progress').append( '<li><b>In Progress</b></li>' );
               
             
             totalamt  = totalamt  + parseFloat(val.amount);

       });
$('#totalamount').append( '<p>Total Amount: <b>Ksh '+ addCommas(totalamt)+'</b></p>' );
$('#tfrConfirmamount').append( '<p class="full usr">You have transfered Ksh '+ addCommas(totalamt)+' from my current account to the below current accounts</p>' );

      

    }


 


    $('.otpfilltrigger').click(function () {
       //OtpRequest2();

     var otpval = $('input[name=otp]:checked').val();
        if (otpval==='sms') {
          //sms req
           getdata (OtpRequest2())
           .then(function (data) {
               $(".otpfill").fadeIn();
               $(".cheki").fadeOut();
           })

        }else {
          //email request 
               $(".otpfill").fadeIn();
               $(".cheki").fadeOut();

        }
 

   
    });


      getdata (myAcctList()).then(function (data) {
               var statementfetched=false;    
                if (data.status){
                        var accts = SeparateAccountTypes(data.data.realtionship_list);   
                           console.log(accts);
                          if (accts.current.length !== 0){
                               
                                 
                                 getConsolidatedAccountBalance(accts.current ,'current');  
                          }
                        
                         

                }
                else {
                    alert(data.message);
                }
               });

  function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}


function getConsolidatedAccountBalance (acctlist ,accttype) {
  
    var AccountWithBalance=[];

    if ($.isArray(acctlist) ){
        $.each(acctlist, function (i, value) {
          AccountWithBalance.push(getdata(AccountBalanceRequest(value.br_id,value.rel_id)) );       
        });       
      }   
    else {    
      AccountWithBalance.push( getdata(AccountBalanceRequest(acctlist.br_id,acctlist.rel_id)));
    }
  
    $.when.all(AccountWithBalance).then(function(results) {
               customerAccts =buildAcctAgain(results);
              //  showAccts(customerAccts);
                 addAccountToSelect(customerAccts);
      }, function(e) {
          //errrror listing accounts
                 
      });

  }

   function addAccountToSelect (acct) {
      $.each(acct, function(key, val) {   
        console.log(val);
        $('#acctselect')
          .append($('<option>', { value : val.acctnumber +'|' + val.acctname + '|' + val.balance })
          .text(val.acctnumber)); 
           });

    }


    function sendOtp () {

          OtpRequest();

        }


     function  SeparateAccountTypes (accts){
   
            var Accts ={};
                var savingAccts = [];
                var currentAccts=[];
           if ($.isArray(accts) ){

             for ( var i = 0, _len = accts.length; i < _len; i++ ) {
              if (accts[i].rel_type === 'SAVNG'){
                savingAccts.push(accts[i]);

              }else if (accts[i].rel_type === 'CRRNT'){
                 currentAccts.push(accts[i]);
              }
            }
              Accts.savings=savingAccts;
              Accts.current=currentAccts;

        

            return Accts;

           

           }   else {
             return accts;
           }  

         
        }
        
       function buildAcctAgain (current){
    // this function used to build customer account after getting customer account balance


 
    var acctData=[];
    var acct ={};

     if ($.isArray(current) ){

        for ( var i = 0, _len = current.length; i < _len; i++ ) {

             if (current[i].status){
                  acct.branch=current[i].data.resp_info.acct_status_list[0].branch;
                  acct.acctnumber=current[i].data.resp_info.acct_status_list[0].acct_number;
                  acct.acctname=current[i].data.resp_info.acct_status_list[0].acct_desc;
                  acct.balance=current[i].data.resp_info.acct_status_list[0].total_balance;
             }
             else {
                  
                  acct.branch="Unknown";
                  acct.acctnumber="Unknown";
                  acct.acctname="Unknown";
                  acct.balance="Unknown";
                  

             }

             acctData.push(acct);


         }

         return acctData;
      }
      else {

                  acct.branch=current.data.resp_info.acct_status_list[0].branch;
                  acct.acctnumber=current.data.resp_info.acct_status_list[0].acct_number;
                  acct.acctname=current.data.resp_info.acct_status_list[0].acct_desc;
                  acct.balance=current.data.resp_info.acct_status_list[0].total_balance;

                  return acct
      }

    }
     
   





   });