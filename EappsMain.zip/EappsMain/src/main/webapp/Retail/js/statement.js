$(document).ready(function() {  

   $("body").addClass("loading"); 


  if (jQuery.when.all===undefined) {
    jQuery.when.all = function(deferreds) {
        var deferred = new jQuery.Deferred();
        $.when.apply(jQuery, deferreds).then(
            function() {
                deferred.resolve(Array.prototype.slice.call(arguments));
            },
            function() {
                deferred.fail(Array.prototype.slice.call(arguments));
            });

        return deferred;
    }
}


  
            getdata (myAcctList()).then(function (data) {
               var statementfetched=false;    
                if (data.status){
                        var accts = data.data.realtionship_list;  
                           addAccountToSelect(accts);
                           getBankstatement(accts[0]);  
                          //  getBankstatement(accts.current[0]); 
                             $("body").removeClass("loading");
                                     
                }
                else {
                 // alert(data.message);
                }
               });

              getdata (myLoanList()).then(function (data) {
               var statementfetched=false;    
                if (data.status){
                        var accts = data.data.realtionship_list;  
                           addLoanToSelect(accts);
                           getLoanstatement(accts[0]);  
                         
                                     
                }
                else {
                 // alert(data.message);
                }
               });


            



function addAccountToSelect (acct) {
   console.log(acct);
      $.each(acct, function(key, value) {   
        $('#acctselect')
          .append($('<option>', { value : key })
          .text(value.rel_id)); 
           });

    }





function getBankstatement(acct) {
    $("body").addClass("loading"); 
 
  getdata (ministatement(acct)).then(function (data) {
       $("body").removeClass("loading");
       if (data.status){
        $('#acctsstmt').dataTable( {
            destroy: true,
            "aaData": data.data.resp_info.mini_stmt,
            "aoColumns": [
              { "mDataProp": "tran_date" },
              { "mDataProp": "acc_num" },
              { "mDataProp": "txn_type" },
              { "mDataProp": "mod_desc" },
              { "mDataProp": "tran_amount" }
          ]
          } );
       }

       else {
        //show error
       }
 
  });




   }

   function addLoanToSelect (acct) {

      $.each(acct, function(key, value) {   
        $('#loanselect')
          .append($('<option>', { value : key })
          .text(value.rel_id)); 
           });

    }

   function getLoanstatement(acct) {
      $("body").addClass("loading"); 
  getdata (loanstatement(acct)).then(function (data) {
       $("body").removeClass("loading");
       if (data.status){
        $('#loanTable').dataTable( {
            destroy: true,
            "aaData": data.data.resp_info.loan_stmt,
            "aoColumns": [
              { "mDataProp": "tran_date" },
              { "mDataProp": "acc_num" },
              { "mDataProp": "txn_desc" },
              { "mDataProp": "tran_amount" }
          ]
          } );
       }

       else {
        //show error
       }
 
  });
   }



    function getPaybilltatement(acct) {
      $("body").addClass("loading"); 
  getdata (ministatement(acct)).then(function (data) {
       $("body").removeClass("loading");
       if (data.status){
        $('#acctsstmt').dataTable( {
            destroy: true,
            "aaData": data.data.resp_info.mini_stmt,
            "aoColumns": [
              { "mDataProp": "tran_date" },
              { "mDataProp": "acc_num" },
              { "mDataProp": "txn_type" },
              { "mDataProp": "mod_desc" },
              { "mDataProp": "tran_amount" }
          ]
          } );
       }

       else {
        //show error
       }
 
  });
   }

 });