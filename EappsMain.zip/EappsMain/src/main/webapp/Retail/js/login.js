$(document).ready(function() {  


 $("form").submit(function(e){

 	//check if session already initiates
  e.preventDefault(e);
 	 var input_username = $("#input-23").val();
 	 var input_pwd = $("#input-24").val();
   var valid =true;

 	 if (input_username == null || input_username == "") {
       // alert("Name must be filled out");
        valid = false;
           e.preventDefault(e);
    }

     if (input_pwd == null || input_pwd == "") {
      //  alert("Password must be filled out");
        valid = false;
           e.preventDefault(e);
    }

return valid;

 });

    
   });